import { useState, useEffect } from 'react';
import axios from 'axios';
import Cookies from 'js-cookie';
import { ToastContainer, toast } from 'react-toastify';
import globalVar from '../../../global/globalVar';
import Loading from '../../../global/Loading';
import EditMaterial from './editMaterial';

/* This component renders the material list while also allowing users to update the material info. */

const ShowMaterial = () => {

    const [mList, setMList] = useState([]);

    axios.get(globalVar.serverlocation + '/api/admin/materials/', {
        headers: {
            'Authorization': Cookies.get('access_token')
        }
    }).then(res => {
        setMList(res.data);
        // console.log(res.data);

    }).catch(err => {
        console.log(err);
    });

        if (mList.length === 0) {
        return (
            <div>
                <Loading />
            </div>    
        );}

        return (
            <div className='materialList' style={{marginTop: "30px"}}>
                {mList.map((m) => ( 
                    <EditMaterial ID={m.id} materialID={m.material_id} nameEng={m.material_name_eng} nameChi={m.material_name_chi} image={m.material_img} />
                ))}
            </div>
        )
};
export default ShowMaterial;