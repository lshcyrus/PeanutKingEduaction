// import axios from "axios";
// import Cookies from "js-cookie";
// import React, { useState } from "react";
// import { ToastContainer, toast } from 'react-toastify';

// import globalVar from "../../../global/globalVar";
// import { OneItem } from "./editOneMaterial";

// import { useSSRSafeId } from "@react-aria/ssr";

// export class EditMaterial extends React.Component {
//     constructor(props) {
//         super(props);
//         this.state = {
//             mList: null,
//             appRoot: props.appRoot,
//             refreash: 1,
//             file: null,
//         };
//     }

//     getM() {
//         axios.get(globalVar.serverlocation + "/api/admin/materials/", {
//             headers: {
//                 'Authorization': Cookies.get('access_token'),
//             }
//         })
//             .then(res => {
//                 var list = res.data;
//                 list = list.map(item => (<OneItem item={item} getM={() => this.getM()}/>));
//                 this.setState({ mList: list });
//             })
//             .catch(err => {
//                 console.log(err);
//             })
//     }

//     componentDidMount() {
//         this.getM();
//     }

//     render() {
//         return (
//             <div className="my-3 bg-body shadow-sm">
//                 <div className="bg-pkDarkBlue2">
//                     <h3 className="p-3" style={{ color: "white" }}>Edit Items 編輯內容</h3>
//                 </div>
//                 {this.state.mList ?
//                     <div className="row g-3 stepContentText p-3 pt-0">
//                         <ToastContainer position="top-center" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnHover={false} />
//                         {this.state.mList}
//                     </div> :
//                     <div></div>}
//             </div>
//         );
//     }
// }

import axios from "axios";                                      // library for http request
import Cookies from "js-cookie";                                // library for handling cookies
import React, { useState } from "react";                        // library for adding react features
import { useNavigate } from "react-router-dom";                 // library for navigation
import { ToastContainer, toast } from 'react-toastify';         // library for notification pop-ups
import globalVar from "../../../global/globalVar";              // global variables
import { Form, Input, Button, Col, Row, Image } from 'antd';    // library for creating UI components (https://ant.design/components/overview/)
import styled from 'styled-components';                         // library for styling react components
import Compressor from "compressorjs";                          // library for compressing image files

// styling for the form in css format, better to place this class outside the component to act as embedded css style
const StyledForm = styled(Form)`
    
    padding: 25px;

    Input {
        font-size: 17px;
        width: 100%;
        border: 1px solid black;
        border-radius: 0;
    }

    label {
        font-size: 18px;
        font-weight: bold;
    }
`;


// props (properties) are the parameters passed from the parent component, React allow us to use props to pass data from one component to another
const EditMaterial = (props) => {

    const [materialID, setMaterialID] = useState(props.materialID);     // useState is a react hook, it is used to store the state of the component
    const [nameEng, setNameEng] = useState(props.nameEng);                  
    const [nameChi, setNameChi] = useState(props.nameChi);
    const [displayImg, setDisplayImg] = useState(props.image);
    const [newImg, setNewImg] = useState(null);

    const navigate = useNavigate();

    // function to update a specified material
    const updateMaterial = () => {              

        var textData = new FormData();
        textData.append('material_id', materialID);
        textData.append('material_name_eng', nameEng);
        textData.append('material_name_chi', nameChi);

        axios.patch(globalVar.serverlocation + '/api/admin/materials/' + props.ID + '/', textData, {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        })
            .then(res => {
                toast.success(`Material ${props.materialID} updated! 材料${props.materialID}已更新！`, { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
            })
            .catch(err => {
                toast.error(`Error: Material ${props.materialID}`, { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
            });

        if (newImg) {
            const image = newImg;

            const options = {
                maxWidth: 400,
                quality: 1.0,
                success(result) {

                    var data = new FormData();
                    data.append('material_img', result, result.name);

                    axios.patch(globalVar.serverlocation + '/api/admin/materials/' + props.ID + '/', data, {
                        headers: {
                            'Authorization': Cookies.get('access_token'),
                        }
                    })
                        .then(res => {
                            toast.success(`Material ${props.materialID} image updated! 材料${props.materialID}相片已更新！`, { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                        })
                        .catch(err => {
                            toast.error(`Error: Material ${props.materialID} image cannot be uploaded`, { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                        });
                },
                error(error) {
                    console.error(error.message);
                    toast.error("Error!", { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                }
            };

            new Compressor(image, options);    // create a new image compressor object
        }

    };

    // function to delete a specified material
    const deleteMaterial = () => {
        axios.delete(globalVar.serverlocation + "/api/admin/materials/" + props.ID + "/", {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        })
            .then(res => {
                toast.success(`Deleted ${props.ID}! 已刪除${props.ID}！`, { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
            })
            .catch(err => {
                //console.log(err);
                toast.error(`Error deleting ${props.ID}!`, { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
            })
    };

    return (
        <div style={{ marginTop: "20px", borderBottom: "2px solid black" }}>
            <StyledForm layout="vertical"> {/* Form is a component provided by antd library. We defined StyledForm on top of this page. */}
                <Row gutter={16}>
                    <Col span={8}>
                        <Form.Item>
                            <img src={displayImg} alt="material image" style={{ maxWidth: '100%' }} />
                        </Form.Item>
                    </Col>
                    <Col span={16}>
                        <Form.Item label={<label>Material ID</label>}>
                            <Input value={materialID} onChange={(e) => setMaterialID(e.target.value)} />
                        </Form.Item>
                        <Form.Item label={<label>Material Name</label>}>
                            <Input value={nameEng} onChange={(e) => setNameEng(e.target.value)} />
                        </Form.Item>
                        <Form.Item label={<label>材料名稱</label>}>
                            <Input value={nameChi} onChange={(e) => setNameChi(e.target.value)} />
                        </Form.Item>
                        <Form.Item>
                            <input style={{ border: "0" }} type="file" accept='image/*' onChange={(e) => { setDisplayImg(URL.createObjectURL(e.target.files[0])); setNewImg(e.target.files[0]); }} />
                        </Form.Item>
                        <Form.Item>
                            <button className="btn btn-delete float-end"
                                onClick={deleteMaterial}>DELETE 刪除</button>
                            <button className="btn btn-save float-end"
                                onClick={updateMaterial}>UPDATE 更新</button>
                        </Form.Item>

                    </Col>
                </Row>
            </StyledForm>
        </div>
    )
};
export default EditMaterial;