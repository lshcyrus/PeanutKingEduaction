import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../global/style.css";

export function AdminSideBarContainer(props) {
  const pageTitle = ["User Permissions 用戶權限", "All Accounts 所有賬戶", "Redemption Keys 兌換代碼", "User-to-Key Pairs 用戶兌換代碼"];
  const handleClick = index => props.jumpToPage(index);

  return (
    <ul className="col-md-3 col-lg-2 d-md-block bg-pkDarkBlue3 sidebar collapse mb-0">
      <nav className="bd-links">
        <ul className="btn-toggle-nav list-unstyled fw-normal pb-1 small">
          {pageTitle.map((title, index) => (
            <li
              type="button" key={"pageLink" + index} className="list-item"
              onClick={() => handleClick(index)}
              style={props.nowPage == index ? { backgroundColor: "#d9ebf9" } : {}}>
              <a className={"d-inline-flex text-decoration-none rounded align-items-center " + (props.nowPage == index ? "link-dark" : "link-white")}
                style={props.nowPage == index ? { fontSize: "1.2rem" } : {}}>
                {title}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </ul>
  );
}
