/* This JavaScript file loads all the redemption key and allow users to change the expiry date of a redemption key. */

import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import Cookies from 'js-cookie'
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import "../../../global/style.css";
import globalVar from "../../../global/globalVar";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export function ShowKey() {
    const [error, setError] = useState(null);
    const [isLoaded, setIsLoaded] = useState(false);
    const [items, setItems] = useState([]);
    const [courseList, setCourseList] = useState([]);
    const [selectedCourse, setSelectedCourse] = useState(null);

    function popToast(status, message) {
        if (status == "success") {
            return toast.success(message, {
                position: "top-center",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: false,
                progress: undefined,
            });
        }

        return toast.error(`Error: ${message}`, {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            progress: undefined,
        });

    }

    function handleActivate(info, isActivate) {
        axios
            .patch(`${globalVar.serverlocation}/api/admin/redemptionkeys/${info.id}/`, { active: isActivate }, {
                headers: {
                    'Authorization': Cookies.get('access_token')
                }
            })
            .then(res => {
                info.active = isActivate;
                setItems(items.slice(0, items.length + 1));
                popToast("success", `Key ${isActivate ? "activated" : "deactivated"}! 代碼已${isActivate ? "啟用" : "停用"}!`);
            })
            .catch(error => {
                setError(error);
            })
    }

    function handleGenerate(courseName) {
        setIsLoaded(false);
        axios
            .post(`${globalVar.serverlocation}/api/admin/redemptionkeys/`, { course: courseName }, {
                headers: {
                    'Authorization': Cookies.get('access_token')
                }
            })
            .then(res => {
                popToast("success", `Key generated successfully!`);
                axios
                    .get(`${globalVar.serverlocation}/api/admin/redemptionkeys/`, {
                        headers: {
                            'Authorization': Cookies.get('access_token')
                        }
                    })
                    .then(result => {
                        setIsLoaded(true);
                        setItems(result.data);
                    })
                    .catch(error => {
                        setIsLoaded(true);
                        setError(error);
                    })
            })
            .catch(error => {
                setError(error);
            })
    }

    const handleDateChange = (info, date) => {
        axios
            .patch(`${globalVar.serverlocation}/api/admin/redemptionkeys/${info.id}/`, { date_expired: date }, {
                headers: {
                    'Authorization': Cookies.get('access_token')
                }
            })
            .then(res => {
                info.date_expired = date;
                setItems(items.slice(0, items.length + 1));
                popToast("success", `Key Expiry Date changed successfully!`);
            })
            .catch(error => {
                setError(error);
            })
    }

    function formatTimeString(str) {
        return `${str.slice(5, 7)}/${str.slice(8, 10)}/${str.slice(0, 4)}`;
    }

    useEffect(() => {
        let endpoints = [
            "/api/admin/redemptionkeys/",
            "/api/admin/courses/"
        ];

        axios.all(endpoints.map((endpoint) =>
            axios.get(`${globalVar.serverlocation}${endpoint}`, {
                headers: {
                    'Authorization': Cookies.get('access_token')
                }
            })
        ))
            .then(
                result => {
                    setIsLoaded(true);
                    setItems(result[0].data);
                    setCourseList([...result[1].data.map(content => content.name), null]);
                }
            )
            .catch(error => {
                setIsLoaded(true);
                setError(error);
            });
    }, [])

    if (error) {
        popToast("error", error.message);
        return (
            <div>
                <ToastContainer
                    position="top-center"
                    autoClose={5000}
                    hideProgressBar={false}
                    newestOnTop={false}
                    closeOnClick rtl={false}
                    pauseOnFocusLoss
                    draggable
                    pauseOnHover
                />
                <div>Error: {error.message}</div>
            </div>
        );
    } else if (!isLoaded) {
        return <div>Loading...</div>;
    } else {
        var pageTitle = "Manage Redemption Keys 管理兌換代碼";
        var colName = ["#", "COURSE 課程", "KEY 代碼", "STATUS 狀態", "EXPIRY DATE 失效日期(MM/DD/YYYY)", "CREATION DATE 創造日期(MM/DD/YYYY)", "ACTION 動作"];

        var tableHead = colName.map((col, index) => <th scope="col" key={`col_${index}`}>{col}</th>);

        var filteredItems = selectedCourse ? items.filter(item => item.course.name === selectedCourse) : items;
        var tableBody = filteredItems.map((info, index) => (
            <tr key={"key_id_" + info.id}>
                <th scope="row">{index + 1}</th>
                <td>{info.course.name}</td>
                <td>{info.key}</td>
                <td>{info.active.toString()}</td>
                <td>
                    <DatePicker
                        selected={Date.parse(info.date_expired)}
                        onChange={(date) => handleDateChange(info, date)}
                        
                    />
                </td>
                <td>{formatTimeString(info.date_created)}</td>
                <td>
                    {info.active ?
                        <button type="button" className="btn btn-outline-danger" onClick={() => handleActivate(info, false)}>DEACTIVATE</button> :
                        <button type="button" className="btn btn-outline-success" onClick={() => handleActivate(info, true)}>ACTIVATE</button>}
                </td>
            </tr>
        ))

        return (
            <div>
                <ToastContainer
                    position="top-center"
                    autoClose={5000}
                    hideProgressBar={false}
                    newestOnTop={false}
                    closeOnClick rtl={false}
                    pauseOnFocusLoss
                    draggable
                    pauseOnHover
                />
                <h4 className="mb-3">{pageTitle}</h4>
                <div className="row" style={{ paddingBottom: "25px" }}>
                    <div className="dropdown col">
                        <div className="row">
                            <button className="btn btn-dark dropdown-toggle text-start" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                {selectedCourse ? ("Selected course: " + selectedCourse) : "CLICK TO SELECT COURSE 下拉選擇課程"}
                            </button>
                            <ul className="dropdown-menu">
                                {courseList.map(courseName => (
                                    <li key={`course_option_${courseName}`}>
                                        <a className="dropdown-item" onClick={() => setSelectedCourse(courseName)}>
                                            {courseName ? courseName : "Show all courses"}
                                        </a>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                    <div className="col-auto">
                        <button
                            type="button"
                            className={`btn btn-outline-success ${selectedCourse ? "" : "disabled"}`}
                            onClick={() => handleGenerate(selectedCourse)}
                        >GENERATE NEW KEY 獲取新課程代碼
                        </button>
                    </div>
                </div>
                <div className="row"></div>
                <div className="table-responsive">
                    <table className="table table-light table-striped table-hover align-middle text-center">
                        <thead><tr>{tableHead}</tr></thead>
                        <tbody>{tableBody}</tbody>
                    </table>
                </div>
            </div>
        );
    }
}