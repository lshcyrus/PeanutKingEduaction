import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import Cookies from 'js-cookie'
import { Collapse } from "bootstrap";

import "../../../global/style.css";
import globalVar from "../../../global/globalVar";
import { TopBar } from '../../../global/TopBar';
import { getCourseData } from "../../../global/getCourseData";
import { AdminSideBarContainer } from "./AdminSideBar";
import { ManageRole } from "./manageRole";
import { ShowKey } from "./showKey";
import { ManageKeyPair } from "./manageKeyPair";
import { ManageActiveness } from "./manageUserActiveness";

export class AdminSetting extends React.Component {
    constructor() {
        super();
        // globalVar.courseData = datad;
        // globalVar.courseList = list;
        globalVar.atFullContainer = this;
        this.state = {
            adminMode: -1000,
            isAdminPanel: true,
            gotData: false,//need to change to false in production
        }
    }

    componentDidMount() {
        // get all necessary data before renderring
        var self = this;

        axios.get(globalVar.serverlocation + "/api/get_userinfo/", {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        })
        .then(res => {
            globalVar.username = res.data.name_eng;
        })
        .catch(err => console.log(err))

        //get course list
        axios.get(globalVar.serverlocation + "/api/admin/courses/", {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        }).then(function (response) {
            //console.log(response.data);
            globalVar.courseList = response.data;
            //self.setState({gotData: 1});
            // console.log(111111111)
            // console.log(globalVar.courseList);

            getCourseData({ self: self });
        }).catch(function (error) {
            window.alert('error');
            console.log(error)
        })


    }

    onClick(props) {
        //console.log("clicked");
        this.setState({ adminMode: props.modeNum });
    }

    render() {
        //console.log("LabID: "+globalVar.labID+"TaskID: "+globalVar.taskID);
        if (this.state.gotData == true) {
            // console.log("render");
            // console.log(globalVar.courseData);
            // console.log("render end");
            // console.log(this.state.adminMode);
            return (
                <div className="body min-height100">
                    <header>
                        <TopBar switchAdminPanel={page => this.setState({ isAdminPanel: page, adminMode: 0 })} />
                    </header>
                    <div>
                        <div className="col-md-3 col-lg-2 d-md-block mb-0">
                            <div>
                                   <AdminSideBarContainer
                                        jumpToPage={page => { this.setState({ adminMode: page }) }}
                                        nowPage={this.state.adminMode}
                                    />
                            </div>
                        </div>
                        <div className="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-65">
                            <div>
                                {(this.state.isAdminPanel && this.state.adminMode == 0) ? <ManageRole /> : ""}
                                {(this.state.isAdminPanel && this.state.adminMode == 1) ? <ManageActiveness /> : ""}                                                                                                            
                                {(this.state.isAdminPanel && this.state.adminMode == 2) ? <ShowKey /> : ""}
                                {(this.state.isAdminPanel && this.state.adminMode == 3) ? <ManageKeyPair /> : ""}
                                {/* {(!this.state.isAdminPanel && this.state.adminMode == 0) ? <CourseEditor /> : ""}
                                {(!this.state.isAdminPanel && this.state.adminMode == 1) ? <LabEditor /> : ""}                                                                                                                         
                                {(!this.state.isAdminPanel && this.state.adminMode == 2) ? <TaskEditor courseName={globalVar.courseData.name} labNumber={globalVar.courseData.labs[globalVar.labID-1].lab_number} task={globalVar.courseData.labs[globalVar.labID-1].tasks[globalVar.taskID-1]} jumpToEditLab={() => { this.onClick({ modeNum: 1 }) }}/> : <div></div>}
                                {(!this.state.isAdminPanel && this.state.adminMode == 3) ? <AddTask appRoot={this} courseName={globalVar.courseData.name} labName={globalVar.courseData.labs[globalVar.labID-1].lab_title_eng}/> : <div></div>}
                                {(!this.state.isAdminPanel && this.state.adminMode == 4) ? <AddLab course={globalVar.courseData} /> : <div></div>}
                                {(!this.state.isAdminPanel && this.state.adminMode == 5) ? <CourseAdder /> : <div></div>}
                                {(!this.state.isAdminPanel && this.state.adminMode == 6) ? <AddMaterial /> : <div></div>}
                                {(!this.state.isAdminPanel && this.state.adminMode == 7) ? <EditMaterial appRoot={this}/> : <div></div>} */}

                                {/* <img src={"https://hacks.mozilla.org/files/2021/02/image-4-500x315.png"}></img> */}
                            </div>
                        </div>
                    </div>
                </div>
            );
        } else {
            return ("Loading, please wait.");
        }
    }
}