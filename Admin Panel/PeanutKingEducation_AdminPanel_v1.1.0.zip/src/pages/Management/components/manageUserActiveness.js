/*
    This component is used to change user type (ADMIN / STUDENT).
*/

import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import Cookies from 'js-cookie'
import "../../../global/style.css";
import globalVar from "../../../global/globalVar";
import Table from 'react-bootstrap/Table';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export function ManageActiveness() {
    const [error, setError] = useState(null);
    const [isLoaded, setIsLoaded] = useState(false);
    const [items, setItems] = useState([]);

    function popToast(status, message) {
        if (status === "success") {
            return toast.success(message, {
                position: "top-center",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: false,
                progress: undefined,
            });
        }

        return toast.error(`Error: ${message}`, {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            progress: undefined,
        });

    }

    function handleActivate(user, isActivate) {
        axios.patch(`${globalVar.serverlocation}/api/admin/deactivate_user/`, { id: user.id, is_active: isActivate }, {
            headers: {
                'Authorization': Cookies.get('access_token')
            }
        })
            .then(res => {
                user.is_active = isActivate;
                setItems(items.slice(0, items.length + 1));
                popToast("success", "User changes updated! 用戶已更新!");
            })
            .catch(error => {
                setError(error);
            })
    }

    useEffect(() => {
        axios.get(`${globalVar.serverlocation}/api/admin/users`, {
            headers: {
                'Authorization': Cookies.get('access_token')
            }
        })
            .then(
                result => {
                    setIsLoaded(true);
                    setItems(result.data);
                }
            )
            .catch(error => {
                setIsLoaded(true);
                setError(error);
            });

    }, [])

    if (error) {
        popToast("error", error.message);
        return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
        return <div>Loading...</div>;
    } else {
        var pageTitle = "Manage All Accounts 管理所有帳戶";
        var colName = [
            ["#", ""],
            ["EMAIL", "電郵"],
            ["ENG NAME", ""],
            ["中文姓名", ""],
            ["DOB", "出生日期"],
            ["GENDER", "性別"],
            ["USER TYPE", "用戶類型"],
            ["CONTACT", "聯絡電話"],
            ["PRO PIC", "檔案照片"],
            ["STATUS", "狀態"],
            ["CREATE ACC DATE", "開戶日期"],
            ["ACTION", "動作"]
        ];

        var tableHead = colName.map((col, index) => <th scope="col" key={`col_${index}`}>{col[0]}<br />{col[1]}</th>);
        var filteredItems = items.filter(item => item.groups.length);

        var genderMapping = {
            "o": "Others",
            "m": "Male",
            "f": "Female"
        };


        var tableBody = filteredItems.map((user, index) => (
            <tr key={`user_${user.id}`} >
                <th scope="row">{index + 1}</th>
                <td>{user.email}</td>
                <td>{user.name_eng}</td>
                <td>{user.name_chi}</td>
                <td>{user.birth}</td>
                <td>{genderMapping[user.sex.toLowerCase()]}</td>
                <td>{user.user_type}</td>
                <td>{user.phone}</td>
                <td><img src={globalVar.serverlocation + user.profile_pic} style={{ height: "2em", width: "auto" }} /></td>
                <td>{user.is_active.toString()}</td>
                <td>{user.date_joined.slice(0, 10)}</td>
                <td>
                    {user.is_active ?
                        <button type="button" className="btn btn-btn btn-outline-danger" onClick={() => handleActivate(user, false)}>DEACTIVATE</button> :
                        <button type="button" className="btn btn-outline-success" onClick={() => handleActivate(user, true)}>ACTIVATE</button>}
                </td>
            </tr>
        ))

        return (
            <div>
                <ToastContainer
                    position="top-center"
                    autoClose={5000}
                    hideProgressBar={false}
                    newestOnTop={false}
                    closeOnClick rtl={false}
                    pauseOnFocusLoss
                    draggable
                    pauseOnHover
                />
                <h4 className="mb-3">{pageTitle}</h4>
                <Table striped hover responsive className="table-light caption-top align-middle text-center">
                    <caption>Check frequently for abnormal logins or suspicious accounts. 恆常檢查有否不尋常登入或可疑賬號。</caption>
                    <thead><tr>{tableHead}</tr></thead>
                    <tbody>{tableBody}</tbody>
                </Table>
            </div>
        );
    }
}