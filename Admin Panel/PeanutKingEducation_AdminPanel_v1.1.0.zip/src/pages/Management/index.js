import { useNavigate } from "react-router-dom";
import React from "react";
import { Button } from "react-bootstrap";
// import { AdminSideBarContainer } from "./components/AdminSideBar";
import "../../global/style.css"         // global css style
import { AdminSetting } from "./components/AdminSetting";   // admin setting page

const Management = () => {

    const navigate = useNavigate();
    const [goToHome, setGoToHome] = React.useState(false);

    if (goToHome){
        navigate("/")
    }
    return ( 
        <div>
            <AdminSetting />
        </div>
    );
}

export default Management
 // <div>
            /* <h1>This is the management page.</h1>
                <Button onClick={() => {
                setGoToHome(true)}}>
                {" "}
                BACK TO HOME PAGE    
                </Button> */