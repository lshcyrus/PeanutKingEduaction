import React, { useState, useEffect } from 'react';
import axios from 'axios';
import globalVar from '../../../global/globalVar';
import Cookies from 'js-cookie';
import { useNavigate } from 'react-router-dom';

/* This React component renders the list of available courses. */

const CourseList = () => {
    const navigate = useNavigate();

    const [courseList, setCourseList] = useState([]);
    
    // this function is used to split the course name into two languages. ' | ' is used as the separator. The same is used in the student panel.
    const splitCourseName = (name, lang) => {
        if (name.split(' | ').length === 1 && lang === 'eng'){ 
            return name
        } else if (name.split(' | ').length === 1 && lang === 'chi') {
            return '/'
        }
        else {
            if (lang == 'eng') {
                return name.split(' | ')[0]
            } else {
                return name.split(' | ')[1]
            }
        }
    }

    useEffect(() => {
        axios.get(globalVar.serverlocation + "/api/admin/courses/", {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        }).then( response => setCourseList(response.data)).catch( error => { window.alert(error); navigate('/')})
    }, []);

    /* 
        <div dangerouslySetInnerHTML={{ __html: }} /> returns the string in specific format. 
        This is used to render the description of the course.
    */

    return (
        <div className='center'>
            <table className='list-table'>
                <thead>
                    <tr>
                        <th style={{ fontSize: '17px' }}>Course Name</th>
                        <th style={{ fontSize: '17px' }}>課程名稱</th>
                        <th style={{ fontSize: '17px' }}>Description</th>
                        <th style={{ fontSize: '17px' }}>課程簡介</th>
                    </tr>
                </thead>
                <tbody>
                    {courseList.map((course) => (
                        <tr key={course.id} onClick={() => {navigate(`/courses/${course.name}/lab/`)}}>
                            <td>{splitCourseName(course.name, 'eng')}</td>
                            <td>{splitCourseName(course.name, 'chi')}</td>
                            <td><div dangerouslySetInnerHTML={{ __html: course.description_eng }} /></td>
                            <td><div dangerouslySetInnerHTML={{ __html: course.description_chi }} /></td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )

}

export default CourseList