import { Button, Form, Input } from 'antd';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import axios from 'axios';
import Cookies from 'js-cookie';
import { toast } from 'react-toastify';
import globalVar from '../../../global/globalVar';

const StyledForm = styled(Form)`
    border: 3px solid black;
    background-color: #fff;
    padding: 25px;
    margin: 20px;
    width: 70%;
    display: flex-row;

    h3 {
        font-size: 28px;
        text-align: center;
        padding-bottom: 20px;
    }

    Input {
        font-size: 17px;
        width: 100%;
        border: 1px solid black;
        border-radius: 0;
    }
    
    label {
        font-size: 20px;
        
    }

    TextArea {
        font-size: 17px;
        width: 100%;
        border: 1px solid black;
        border-radius: 0;
    }

    .ant-form-item-explain-error {
        font-size: 16px;
    }

`;

// This component controls the submit button of the form, it validates the form and enables the button if the form is valid
const SubmitButton = ({ form }) => {
    const [submittable, setSubmittable] = useState(false);
    
    // Watch all values
    const values = Form.useWatch([], form);
    

  useEffect(() => {
    form.validateFields({ validateOnly: true }).then(
      () => {
        setSubmittable(true);
      },
      () => {
        setSubmittable(false);
      },
    );
  }, [values]);

  return (
    <Button className="btn btn-save float-end" type="primary" htmlType="submit" disabled={!submittable} 
    style={{width: "120px", height: "50px", border: "2px solid black", borderRadius: "0", padding: "5px"}}
    >
      SUBMIT 遞交
    </Button>
  );
};

      
const AddCourse = () => {
    const [form] = Form.useForm();          // This is the form used to add a course, useForm() is a hook provided by antd
    const { TextArea } = Input;             // This is the TextArea component from antd
    const [courseName_eng, setCourseName_eng] = useState('');
    const [courseName_chi, setCourseName_chi] = useState('');
    const [description_chi, setDescription_chi] = useState('');
    const [description_eng, setDescription_eng] = useState('');
    
    const navigate = useNavigate();

    function toCourseList() {
        navigate('/courses/list');
    }
    
    const onFinish = (values) => {

                var data = new FormData();
                if (values.name_chi != null){
                    data.append('name', values.name_eng + ' | ' + values.name_chi);
                } else {
                    data.append('name', values.name_eng);
                }
                data.append('description_eng', values.desc_eng);
                data.append('description_chi', values.desc_chi);
            
                axios.post(globalVar.serverlocation + '/api/admin/courses/', data, {
                    headers: {
                        'Authorization': Cookies.get('access_token'),
                    }
                })
                .then(res => {
                    toast.success('Saved and updated! 已儲存及更新！', {
                        position: "top-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        
                    });
                    toCourseList();
                })
                .catch(err => {
                    console.log(err);
                    toast.error('Error! 請檢查！', {
                        position: "top-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                });  
            }

    return (
    <StyledForm form={form} layout="vertical" onFinish={onFinish}>
        <h2>Add A New Course 新增課程</h2>
        <Form.Item name="name_eng" label={<label>Course Name</label>} rules={[{ required: true, message: "Course name should not be empty 課程英文名稱不能為空白" }]}>
                <Input type='text' value={courseName_eng} onChange={(e) => setCourseName_eng(e.target.value)}/>
        </Form.Item>
        <Form.Item name="name_chi" label={<label>課程名稱</label>}>
                <Input type='text' value={courseName_chi} onChange={(e) => setCourseName_chi(e.target.value)}/>
        </Form.Item>
        <Form.Item name="desc_eng" label={<label>Course Description</label> } rules={[{ required: true, message: 'Course description should not be empty', }]}>
                <TextArea rows={10} cols={70} value={description_eng} onChange={(e) => setDescription_eng(e.target.value)} />
        </Form.Item>
        <Form.Item name="desc_chi" label={<label>課程簡介</label>} rules={[{ required: true, message: '課程簡介不能為空白', }]}>
                <TextArea rows={10} cols={70} value={description_chi} onChange={(e) => setDescription_chi(e.target.value)} />
        </Form.Item>

        <Form.Item>
                <SubmitButton form={form} />
        </Form.Item>
    </StyledForm>
  );
};

export default AddCourse;