import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import globalVar from '../../../global/globalVar';
import { Form, Popover } from 'antd';
import styled from 'styled-components';
import axios from 'axios';
import Cookies from 'js-cookie';
import { toast } from 'react-toastify';
import { getData } from './getData';
import { Modal, Button } from "react-bootstrap";
import { EngDescEditor } from './EngDescEditor';
import { ChiDescEditor } from './ChiDescEditor';

const StyledForm = styled(Form)`
    border: 3px solid black;
    background: #fff;
    padding: 25px;
    margin: 20px;
    width: 100%;
    display: flex-row;

    label {
        font-size: 20px;
    }

    input {
        font-size: 17px;
        width: 100%;
    }

    textarea {
        font-size: 17px;
        width: 100%;
    }

    .ql-editor {
        font-size: 18px;
        font-weight: 500;
        color: inherit;
    }
`;



const EditCourse = () => {

    const params = useParams();
    const navigate = useNavigate();

    const splitName = (name, lang) => {
        if (name.split(' | ').length == 1 && lang == 'eng') {
            return name;
        } else if (name.split(' | ').length == 2 && lang == 'eng') {
            return name.split(' | ')[0];
        } else if (name.split(' | ').length == 2 && lang == 'chi') {
            return name.split(' | ')[1];
        } else {
            return '';
        }
    }

    const [courseID, setCourseID] = useState(globalVar.courseData.id);
    const [engName, setEngName] = useState(splitName(params.name, 'eng'));
    const [chiName, setChiName] = useState(splitName(params.name, 'chi'));
    const [engDesc, setEngDesc] = useState(globalVar.courseData.description_eng);
    const [chiDesc, setChiDesc] = useState(globalVar.courseData.description_chi);
    const [show, setShow] = useState(false);

    const redirectToCourseList = () => {            // redirecting to course list page
        navigate('/courses/list/');
        window.location.reload();
    }

    const redirectToLabList = () => {
        navigate(`/courses/${params.name}/lab/`);
    }

    const openModal = () => {
        setShow(true);
    }

    const closeModal = () => {
        setShow(false);
    }

    const getCourseEngDesc = (newEngDesc) => {
        setEngDesc(newEngDesc);
    }

    const getCourseChiDesc = (newChiDesc) => {
        setChiDesc(newChiDesc);
    }

    getData({ name: params.name });

    // function to delete a course, it is called after user clicking the confirm button in the modal
    function deleteCourse() {
        axios.delete(globalVar.serverlocation + "/api/admin/courses/" + courseID + '/', {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        })
            .then(res => {
                toast.success('Deleted!', { position: "top-center", autoClose: 3000, closeOnClick: true, pauseOnHover: false, progress: undefined, });
                axios.get(globalVar.serverlocation + "/api/admin/courses/", {
                    headers: {
                        'Authorization': Cookies.get('access_token'),
                    }
                })
                    .then(function (response) {
                        //console.log(response.data);
                        globalVar.courseList = response.data;
                        //self.setState({gotData: 1});
                        // console.log(111111111)
                        // console.log(globalVar.courseList);
                        // getData({ name: globalVar.courseList[0].name });
                    }).catch(function (error) {
                        window.alert('error');
                        console.log(error)
                    })
            })
            .catch(err => console.log(err))
    }

    // function to upload the data to the server, it is called after user clicking the save button
    function uploadData() {
        var data = new FormData();
        if (chiName != '') {
            data.append('name', engName + ' | ' + chiName);
        } else {
            data.append('name', engName);
        }
        data.append("description_eng", engDesc);
        data.append("description_chi", chiDesc);
        axios.patch(globalVar.serverlocation + "/api/admin/courses/" + courseID + "/", data, {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        })
            .then(res => {
                // console.log(res.request.status);
                // console.log(res.data);
                toast.success('Saved and updated! 已儲存及更新！', {
                    position: "top-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                redirectToCourseList();
            })
            .catch(err => {
                //console.log(err)
                console.log(err);
                toast.error('Unknown error!', {
                    position: "top-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            })
    }


    useEffect(() => {
        setCourseID(globalVar.courseData.id);
        setEngName(splitName(params.name, 'eng'));
        setChiName(splitName(params.name, 'chi'));
        setEngDesc(globalVar.courseData.description_eng);
        setChiDesc(globalVar.courseData.description_chi);
    }, [globalVar.courseData.id]);


    return (
        <div className='center'>
            <StyledForm layout='vertical'>
                <button style={{ display: 'grid', border: '2px solid black' }} className="btn btn-delete float-end" onClick={() => openModal()}>DELETE THIS COURSE 刪除整個課程</button>
                <h3>Edit Course Details 修改課程資料</h3>
                <div style={{ paddingTop: '10px' }}></div>
                <Form.Item label={<label>Course Name</label>}>
                    <input type="text" value={engName} onChange={(e) => setEngName(e.target.value)} />
                </Form.Item>
                <Form.Item label={<label>課程名稱</label>}>
                    <input type="text" value={chiName} onChange={(e) => setChiName(e.target.value)} />
                </Form.Item>
                <Form.Item label={<label>Course Description</label>} style={{ paddingTop: '15px' }}>
                    {/* <textarea rows={10} cols={100} value={engDesc} onChange={(e) => setEngDesc(e.target.value)} /> */}
                    <EngDescEditor CourseEngDesc={getCourseEngDesc} value={engDesc} id={params.name + 'engDesc'} />
                </Form.Item>
                <Form.Item label={<label>課程描述</label>} style={{ paddingTop: '50px' }}>
                    {/* <textarea rows={10} cols={100} value={chiDesc} onChange={(e) => setChiDesc(e.target.value)} /> */}
                    <ChiDescEditor CourseChiDesc={getCourseChiDesc} value={chiDesc} id={params.name + 'chiDesc'} />
                </Form.Item>
                <Form.Item style={{ paddingTop: '30px' }}>
                    <button className='btn btn-save float-end' style={{ width: "20%" }} onClick={() => uploadData()}>SAVE 儲存</button>
                </Form.Item>
            </StyledForm>
            <Modal show={show} onHide={() => closeModal()}>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Message 確認信息</Modal.Title>
                </Modal.Header>
                <Modal.Body>Do you want to delete this course? It cannot be recovered. 你想刪除整個課程嗎？動作不可復原。</Modal.Body>
                <Modal.Footer>
                    <Button variant="save" onClick={() => closeModal()}>CANCEL 取消</Button>
                    <Button variant="delete" onClick={() => { closeModal(); deleteCourse(); redirectToCourseList(); }}>CONFIRM 確認</Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
}

export default EditCourse;
