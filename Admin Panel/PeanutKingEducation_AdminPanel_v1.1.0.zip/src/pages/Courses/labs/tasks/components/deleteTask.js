
/* Delete task function by Lester. */

import globalVar from "../../../../../global/globalVar";
import axios from "axios";
import Cookies from "js-cookie";
import { toast } from "react-toastify";
import { getData } from "../../../../Courses/components/getData";
import { useNavigate } from "react-router-dom";

export function deleteTask(props) {

    // console.log("djdjdjd ",globalVar.courseData.labs[globalVar.labID])
    axios.delete(globalVar.serverlocation + "/api/admin/tasks/" + globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.taskID - 1].id + '/', {
        headers: {
            'Authorization': Cookies.get('access_token'),
        }
    })
        .then(res => {
            toast.success('Deleted! Please check the updated task list.', { position: "top-center", autoClose: 3000, closeOnClick: true, pauseOnHover: false, progress: undefined, });
            axios.get(globalVar.serverlocation + "/api/admin/courses/", {
                headers: {
                    'Authorization': Cookies.get('access_token'),
                }
            })
                .then(function (response) {
                    //console.log(response.data);
                    // globalVar.courseList = response.data;
                    //self.setState({gotData: 1});
                    // console.log(111111111)
                    // console.log(globalVar.courseList);
                    getData({ name: globalVar.courseData.name });
                    //props.jumpToLab();
                }).catch(function (error) {
                    window.alert('error task editor');
                    console.log(error);
                })
        })
        .catch(err => console.log(err))
    
}