import React, { useState } from 'react';
import styled from 'styled-components';
import { Form, Popover, Image } from 'antd';
import globalVar from '../../../../../global/globalVar';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import { getData } from '../../../../Courses/components/getData';
import { EngTaskEditor } from './EngTaskEditor';
import { ChiTaskEditor } from './ChiTaskEditor';
import axios from 'axios';
import Cookies from 'js-cookie';
import youtube from "../../../../../global/media/utube.png";


const StyledForm = styled(Form)`
    border: 3px solid black;
    background: #fff;
    padding: 25px;
    margin: 20px;
    width: 90%;
    display: flex-row;

    h2 {
        margin-bottom: 10px;
        text-align: center;
    }

    h3 {
        margin-bottom: 20px;
        text-align: center;
    }

    label {
        font-size: 20px;
    }

    input {
        font-size: 17px;
        width: 100%;
    }

    .ql-editor {
        font-size: 18px;
        font-weight: 500;
        color: inherit;
    }

`;

const AddNewTask = () => {

    const params = useParams();
    const navigate = useNavigate();
    const location = useLocation();
    const [taskTitle, setTaskTitle] = useState('');
    const [taskTitleChi, setTaskTitleChi] = useState('這個實驗沒有提供中文版名稱');
    const [engBrief, setEngBrief] = useState('');
    const [chiBrief, setChiBrief] = useState('這個實驗沒有提供中文版介紹');
    const [video, setVideo] = useState(null);

    var newTaskNumber = -1;
    var newTaskNumber = (globalVar.courseData.labs[globalVar.labID - 1].tasks.length > 0) ? (globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.courseData.labs[globalVar.labID - 1].tasks.length - 1].task_number + 1) : 1;

    const splitName = (name) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            return name.split(' | ')[0] + ' ' + name.split(' | ')[1]
        }
    }

    // popover content to display when users hover on the specified location
    const reminder = (
        <div>
            <p>Copy and paste the video code after "youtube.com/watch?v="</p>
            <p>複製並貼上"youtube.com/watch?v="之後的影片編碼</p>
            <p>Format 格式: https://www.youtube.com/embed/qvzCmV3_12c</p>
            <Image src={youtube} />
        </div>
    );

    const redirectToTask = () => {
        navigate('/courses/' + params.name + '/lab/' + params.lab_number + '/task/', { state: { lab_title_eng: location.state.lab_title_eng, lab_title_chi: location.state.lab_title_chi, lab_outcome_eng: location.state.lab_outcome_eng, lab_outcome_chi: location.state.lab_outcome_chi } });
    }

    const getEngTaskBrief = (newEngBrief) => {
        setEngBrief(newEngBrief);
    }

    const getChiTaskBrief = (newChiBrief) => {
        setChiBrief(newChiBrief);
    }

    return (
        <div className='center'>
            <StyledForm layout='vertical'>
                <h2>Add New Task for {splitName(params.name)}</h2>
                <h3>Lab Number 實驗編號:{params.lab_number}</h3>
                <h3>New Task Number 新任務編號: {newTaskNumber}</h3>
                <p>PLEASE DO NOT REFRESH BROWSER 請勿刷新瀏覽器</p>
                <Form.Item label={<label>Task Title</label>}>
                    <input type='text' value={taskTitle} onChange={(e) => setTaskTitle(e.target.value)} />
                </Form.Item>
                <Form.Item label={<label>任務名稱（中文）</label>}>
                    <input type='text' value={taskTitleChi} onChange={(e) => setTaskTitleChi(e.target.value)} />
                </Form.Item>
                <Form.Item label={<label>Task Introduction</label>}>
                    <EngTaskEditor EngTaskBrief={getEngTaskBrief} value={engBrief} id={params.name + params.lab_number + newTaskNumber + 'eng'} />
                </Form.Item>
                <Form.Item label={<label>任務介紹（中文）</label>} style={{ paddingTop: '30px' }}>
                    <ChiTaskEditor ChiTaskBrief={getChiTaskBrief} value={chiBrief} id={params.name + params.lab_number + newTaskNumber + 'chi'} />
                </Form.Item>
                <Form.Item label={<label><Popover content={reminder} title='How to add a new video 如何新增影片:'><h6 style={{ textDecoration: "underline", color: 'blue' }}>Video URL 影片網址</h6></Popover></label>} style={{ paddingTop: '30px' }}>
                    <input type='url' defaultValue={'https://youtube.com/embed/'} onChange={(e) => setVideo(e.target.value)} />
                </Form.Item>
                {video == null ? <div></div> : <iframe style={{ width: '100%', height: '800px', border: '2px dotted black' }} src={video} controls></iframe>}
                <Form.Item style={{ paddingTop: '30px' }}>
                    <button className="btn btn-save float-end" onClick={() => {
                        var data = new FormData();

                        data.append("task_number", newTaskNumber);
                        data.append("title_eng", taskTitle);
                        data.append("title_chi", taskTitleChi);
                        data.append("brief_eng", engBrief);
                        data.append("brief_chi", chiBrief);
                        data.append("course", globalVar.courseData.id);
                        data.append("lab", globalVar.courseData.labs[globalVar.labID - 1].id);
                        if (video != null)
                            data.append("video", video);

                        axios.post(globalVar.serverlocation + "/api/admin/tasks/", data, {
                            headers: {
                                'Authorization': Cookies.get('access_token'),
                            }
                        }).then((res) => {
                            if (res.status == 201) {
                                toast.success('Task added!', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, progress: undefined });
                                getData(params);
                                redirectToTask();
                            }
                        })
                            .catch((error) => {
                                toast.error('Failed to add task. Please try again later.', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, progress: undefined });
                            });
                    }}>SAVE 儲存</button>
                </Form.Item>
            </StyledForm>
        </div>
    );
}

export default AddNewTask;
