
/* 
    All the urls related to tasks will be redirected to this React component.
    location.state is used to indicate which action is the users performing 
*/


import React, { useState } from 'react'
import { useParams, useNavigate, useLocation } from 'react-router-dom'
import globalVar from '../../../../../global/globalVar'
import { getData } from '../../../components/getData'
import StepEditor from '../steps/component/stepEditor'
import AddStep from '../steps/component/addStep'
import TaskEditor from './TaskEditor'

const TaskDetail = (props) => {

    const params = useParams();
    const location = useLocation();
    const lab_number = params.lab_number;
    const task_number = params.task_number;
   

    /* For splitting chi name and eng name */
  
    const splitName = (name) => {
        if (name.split(' | ').length == 1){
            return name
        } else {
            return name.split(' | ')[0] + ' ' + name.split(' | ')[1]
        }    
    }

    const splitCourseName = (name, lang) => {
        if (name.split(' | ').length == 1){
            return name
        } else {
            if (lang == 'eng') {
                return name.split(' | ')[0]
            } else {
                return name.split(' | ')[1]
            }
        }
    }

    globalVar.labID = lab_number;
    globalVar.taskID = task_number;

    //console.log(globalVar.courseData);
    getData(params);

    if (location.state.mode === "edit"){
        return (
            <div>
                <TaskEditor courseName={location.state.data[0].name} labNumber={location.state.data[0].labs[0].lab_number} task={location.state.data[0].labs[0].tasks[globalVar.taskID - 1]} />
            </div>
        )
    }
    else if (location.state.mode === "steps"){
        return (
            <div className='center'>
                <h2> {splitName(params.name)} - Lab {params.lab_number} 實驗{params.lab_number}</h2>
                <h2> Task {params.task_number} 任務{params.task_number}</h2>
                <h3>Steps 步驟列表</h3> <StepEditor steps={location.state.stepData[0].labs[0].tasks[0].steps[location.state.step_number - 1]}/>
            </div>
        )
    }
    else if (location.state.mode === "Steps"){
        return (
            <div className='center'>
                <h1> {splitName(params.name)} - Lab {params.lab_number}</h1>
                <h2> Task {params.task_number} Step {params.step_number} </h2>
                <h3>Steps 步驟</h3> <StepEditor steps={location.state.fromStep.task.steps[location.state.step_number - 1]}/>
            </div>
        )
    }
    else if (location.state.mode === "addstep"){
        return(
            <div className='center'>
            <h2> {splitName(params.name)} - Lab {params.lab_number} 實驗{params.lab_number}</h2>
            <h2> Task {params.task_number} 任務{params.task_number}</h2>
            <h3>Steps 步驟列表</h3>
            <AddStep />
            </div>
        )
    }
}

export default TaskDetail