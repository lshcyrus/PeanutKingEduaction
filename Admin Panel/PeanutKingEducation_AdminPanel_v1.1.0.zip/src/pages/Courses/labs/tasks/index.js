/*
    This page is for displaying the task list in a chosen lab
*/

import React, { useState, useEffect } from 'react'
import axios from 'axios';
import globalVar from '../../../../global/globalVar';
import Cookies from 'js-cookie';
import { useParams } from 'react-router-dom';
import { useNavigate, useLocation } from 'react-router-dom';
import Loading from '../../../../global/Loading'
import Modal from 'react-modal';
import Steps from './steps';
import { TopBar } from '../../../../global/TopBar';
import { Button } from 'antd';
import { toast, ToastContainer } from 'react-toastify';

export function handleCloseStepModal() {
    document.body.style.overflow = 'auto';
}

export function scrollToTop() {
    window.scrollTo({
        top: 580,
        left: 0,
        behavior: "smooth"
    });
}

const Tasks = () => {

    const params = useParams();             // for getting the courses info from the url using params.
    const location = useLocation();         // for getting the courses info from the last url using location.state.
    const lab_number = params.lab_number;
    const navigate = useNavigate();
    const [TaskDetail, setTaskDetail] = useState([]);

    const [taskModal, setTaskModal] = useState(false);
    const [stepModal, setStepModal] = useState(false);

    /* For splitting chi name and eng name */
  
    const splitName = (name) => {
        if (name.split(' | ').length == 1){
            return name
        } else {
            return name.split(' | ')[0] + ' ' + name.split(' | ')[1]
        }    
    }

    const splitCourseName = (name, lang) => {
        if (name.split(' | ').length == 1){
            return name
        } else {
            if (lang == 'eng') {
                return name.split(' | ')[0]
            } else {
                return name.split(' | ')[1]
            }
        }
    }

    function scrollToTop() {
        window.scrollTo({
            top: 580,
            left: 0,
            behavior: "smooth"
        });
    }

    function handleOpenStepModal(labID, taskID) {
        globalVar.labID = labID;
        globalVar.taskID = taskID;
        setStepModal(true);
        scrollToTop();
        document.body.style.overflow = 'hidden';
    }

    function handleCloseStepModal() {
        setStepModal(false);
        document.body.style.overflow = 'auto';
    }

    useEffect(() => {
        axios.get(globalVar.serverlocation + "/api/courses/" + params.name, {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        }).then(res => setTaskDetail([res.data])).catch(error => { window.alert(error); navigate('/') })
    }, [])

    const filteredTask = TaskDetail.map(course => ({
        ...course,
        labs: course.labs.filter(lab => lab.lab_number == lab_number)
    }));

    //console.log(filteredTask);
    if (filteredTask.length == 0) {
        return (
            <Loading />
        )
    }

    if (globalVar.courseData.labs[lab_number - 1].tasks.length != 0) {
        return (
            <div className='center'>
                <h1>TASK LIST 任務清單</h1>
                {filteredTask.map((course) =>
                    <div key={course.id}>
                        {course.labs.map((lab) =>
                            <div key={lab.lab_number}>
                                {lab.tasks.map((task) =>
                                    <div key={task.id}>
                                        <div className='taskcontainer'>
                                            <div className='taskcard' onClick={() => { navigate(`/courses/${course.name}/lab/${lab.lab_number}/task/${task.task_number}/`, { state: { mode: 'edit', data: filteredTask } }); scrollToTop(); }}>
                                                <div>
                                                    <h2 style={{ display: "flex", justifyContent: "center", alignContent: "center" }}>TASK {task.task_number}</h2>
                                                    <h2 style={{ display: "flex", justifyContent: "center", alignContent: "center" }}>{task.title_eng}</h2>
                                                    <h2 style={{ display: "flex", justifyContent: "center", alignContent: "center" }}>{task.title_chi}</h2>
                                                    <hr></hr>
                                                    <p><div dangerouslySetInnerHTML={{ __html: task.brief_eng }} /></p>
                                                    <p><div dangerouslySetInnerHTML={{ __html: task.brief_chi }} /></p>
                                                </div>
                                            </div>
                                            <div className='vstep' onClick={() => handleOpenStepModal(lab.lab_number, task.task_number)}>
                                                <h5>View Steps</h5>
                                                <h5>查看任務步驟</h5>
                                            </div>
                                            <div className='vstep' onClick={() => { scrollToTop(); navigate(`/courses/${course.name}/lab/${lab.lab_number}/task/${task.task_number}/steps/add`, { state: { mode: "addstep" } }) }}>
                                                <h5>Add Steps</h5>
                                                <h5>新增任務步驟</h5>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                )}
                <div className='Tasks'>
                    <Modal isOpen={stepModal} className='key-modal' overlayClassName='key-modal-overlay'>
                        <div className='key-modal__header'>
                            <Button type='primary float-end' danger style={{ width: "12%", height: "40px", borderRadius: "0", border: "2px solid black", backgroundColor: "#c71e1e" }} onClick={() => handleCloseStepModal()}>CLOSE 關閉</Button>
                        </div>
                        <div className='key-modal__content'>
                            <Steps courseName={globalVar.courseData.name} labNumber={globalVar.courseData.labs[globalVar.labID - 1].lab_number} task={globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.taskID - 1]} />
                        </div>
                    </Modal>
                </div>
                <ToastContainer position="top-center" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnFocusLoss={false} pauseOnHover={false} />
            </div>
        )
    } else if (globalVar.courseData.labs[lab_number - 1].tasks.length == 0) {
        return (
            <div>
                <hr></hr>
                <div style={{ cursor: "pointer" }} onClick={() => { navigate(`/courses/${params.name}/lab/${params.lab_number}/add-task/`, { state: { lab_title_eng: location.state.lab_title_eng, lab_title_chi: location.state.lab_title_chi, lab_outcome_eng: location.state.lab_outcome_eng, lab_outcome_chi: location.state.lab_outcome_chi } }) }}>
                    <h5 style={{ display: "flex", justifyContent: "center", textAlign: "center" }}>
                        There are no tasks available for "{splitCourseName(params.name, 'eng')}" Lab {params.lab_number}.
                        Start adding task by clicking here or the "ADD NEW TASK" tab page.
                    </h5>
                    <h5 style={{ display: "flex", justifyContent: "center", textAlign: "center" }}>
                        "{splitCourseName(params.name, 'chi')}" 實驗 {params.lab_number} 沒有任何任務，
                        按這裏或"新增任務"開始為此實驗新增任務。
                    </h5>
                </div>
            </div>
        )
    }
}

export default Tasks;