
/* This React component renders the step list of the modal. */

import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Loading from '../../../../../global/Loading';
import { handleCloseStepModal } from '..';
import { useState } from 'react';
import { scrollToTop } from '..';
import globalVar from '../../../../../global/globalVar'
import { LazyLoadImage } from 'react-lazy-load-image-component';
import styled from 'styled-components';
import { Form, Row, Col } from 'antd';

//props.courseName
//props.labNumber
//props.task

const StyledForm = styled(Form)`
    display: flex;
    flex-wrap: nowrap;
    padding: 15px;
    background-color: #fff;
    border-radius: 0;
    border: 3px solid #000;
    width: 1000px;
    margin: 1rem auto;
    gap: 1rem;

    @media screen and (max-width: 1000px) {
        display: block;
        width: fit-content;
        padding: 25px;

        img {
            display: block;
        }

        label {
            display: block;
        }

    }

    @media screen and (max-width: 767px) {
        display: block;
        width: fit-content;
    }

    label {
        font-size: 18px;
        font-weight: bold;
    }
`;

const Steps = (props) => {

    const params = useParams();
    const navigate = useNavigate();

    /* For splitting chi name and eng name */

    const splitName = (name) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            return name.split(' | ')[0] + ' ' + name.split(' | ')[1]
        }
    }

    const splitCourseName = (name, lang) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            if (lang == 'eng') {
                return name.split(' | ')[0]
            } else {
                return name.split(' | ')[1]
            }
        }
    }

    const stepForm = props.task.steps.map(step =>
        <div className='materialList' style={{ marginTop: '30px' }}>
            <StyledForm layout='vertical' style={{ cursor: "pointer" }} onClick={() => { handleCloseStepModal(); scrollToTop(); navigate(`/courses/${props.courseName}/lab/${props.labNumber}/task/${props.task.task_number}/steps/${step.step_number}`, { state: { step_number: step.step_number, fromStep: props, mode: "Steps" } }) }}>
                <div key={step.id}>
                    <div style={{ paddingLeft: "10px" }}>
                        <Row gutter={16}>
                            <Col span={8}>
                                <Form.Item>
                                    <LazyLoadImage src={step.image} alt="no image" style={{ maxWidth: '100%' }} />
                                </Form.Item>
                            </Col>
                            <Col span={16}>
                                <Form.Item label={<label>Step Number</label>}>
                                    <h2>{step.step_number}</h2>
                                </Form.Item>
                                <Form.Item label={<label>Details:</label>}>
                                    {/* <h6>{step.instruction_eng}</h6> */}
                                    <div dangerouslySetInnerHTML={{ __html: step.instruction_eng }} />
                                </Form.Item>
                                <Form.Item label={<label>內容:</label>} name='insChi'>
                                    {/* <h6>{step.instruction_chi}</h6> */}
                                    <div dangerouslySetInnerHTML={{ __html: step.instruction_chi }} />
                                </Form.Item>
                            </Col>
                        </Row>
                    </div>
                </div>
            </StyledForm>
        </div>
    );

    if (props.courseName != params.name) {
        return (
            <div>
                <h1>Please reload from course list. 請從課程列表重新載入。</h1>
            </div>
        )
    }
    else if (stepForm.length == 0) {
        return (
            <div style={{ color: "GrayText", textAlign: "center" }}>
                <h5>There are no steps in {splitCourseName(params.name, 'eng')} Lab {params.lab_number} Task {props.task.task_number}</h5>
                <h5>{splitCourseName(params.name, 'chi')} 實驗 {params.lab_number} 任務 {props.task.task_number} 沒有任何步驟</h5>
                <button style={{ fontSize: "18px", color: "black", fontWeight: "bold", backgroundColor: "transparent", cursor: "pointer", border: "5px solid black", textAlign: "center", padding: "15px" }}
                    onClick={() => { handleCloseStepModal(); scrollToTop(); navigate(`/courses/${params.name}/lab/${params.lab_number}/task/${props.task.task_number}/steps/add`, { state: { mode: "addstep" } }) }}>ADD STEPS HERE 按此新增步驟</button>
            </div>
        )
    }
    else {
        return (
            <div className='center'>
                <h2>{splitCourseName(params.name, 'eng')} Lab {params.lab_number} Task {props.task.task_number} Steps</h2>
                <h2>{splitCourseName(params.name, 'chi')} 實驗 {params.lab_number} 任務 {props.task.task_number} 步驟</h2>
                <p style={{ color: "GrayText" }}>The image may take 10-15 seconds to load.</p>
                <h3>{props.task.title_eng}</h3>
                <h3>{props.task.title_chi}</h3>
                <div className='center'>
                    {stepForm}
                </div>
            </div>
        );
    }
}

export default Steps;
