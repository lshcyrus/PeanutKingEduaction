import axios from 'axios';
import React, { useState } from 'react';
import { useEffect } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import globalVar from '../../../../../../global/globalVar';
import Cookies from 'js-cookie';
import Loading from '../../../../../../global/Loading';

const FetchSteps = () => {
    const navigate = useNavigate();
    const params = useParams();

    const lab_number = params.lab_number;
    const task_number = params.task_number;

    globalVar.labID = lab_number;
    globalVar.taskID = task_number;

    const [data, setGetData] = useState([]);

    useEffect(() => {
        axios.get(globalVar.serverlocation + "/api/courses/" + params.name, {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        }).then(res => setGetData([res.data])).catch(error => { window.alert(error); navigate('/') })
    })

    // setup a filter to filter out the lab with the lab_number
    const filteredLab = data.map(course => ({
        ...course,
        labs: course.labs.filter(lab => lab.lab_number == lab_number),
    }));

    // setup a filter to filter out the filtered lab task with the task_number
    const filteredTask = filteredLab.map(course => {
        return {
            ...course,
            labs: course.labs.map(lab => {
                return {
                    ...lab,
                    tasks: lab.tasks.filter(task => task.task_number == task_number)
                }
            })
        }
    });

    if (filteredTask.length === 0) {
        return (<div><Loading /></div>);
    } else {
        return (
            <div>
                <div>
                    <table style={{ borderCollapse: "collapse" }}>
                        <tbody style={{ display: "flex", justifyContent: "center", justifyItems: "center" }}>
                            {filteredTask.map((course) =>
                                <div key={course.id}>
                                    {course.labs.map((lab) =>
                                        <div key={lab.id}>
                                            {lab.tasks.map((task) =>
                                                <div key={task.id}>
                                                    {task.steps.map((step) =>
                                                        <td style={{ color: "black", fontSize: "24px", fontWeight: "bold", width: "50px", height: "50px", backgroundColor: "ghostwhite", cursor: "pointer", padding: "10px", border: "3px solid black", textAlign: "center" }} key={step.id} onClick={() => navigate(`/courses/${params.name}/lab/${params.lab_number}/task/${params.task_number}/steps/${step.step_number}`, { state: { step_number: step.step_number, mode: "steps",  stepData: filteredTask } })}>{step.step_number}</td>
                                                    )}
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>
                            )}
                            <div>
                                <td style={{ color: "black", fontSize: "24px", fontWeight: "bold", width: "50px", height: "50px", padding: "10px", backgroundColor: "ghostwhite", cursor: "pointer", border: "3px solid black", textAlign: "center", justifyContent: "center", borderLeft: "0" }} onClick={() => navigate(`/courses/${params.name}/lab/${params.lab_number}/task/${params.task_number}/steps/add`, { state: { mode: "addstep" } })}>＋</td>
                            </div>
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }
}

export default FetchSteps;
