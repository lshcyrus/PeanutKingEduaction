import axios from 'axios';
import Cookies from 'js-cookie';
import React, { useEffect, useState, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getData } from '../../../../components/getData';
import globalVar from '../../../../../../global/globalVar';
import FetchSteps from './FetchSteps';
import { Form, Checkbox, Progress, Image } from 'antd';
import { InboxOutlined, UploadOutlined } from '@ant-design/icons';
import styled from 'styled-components';
import { ToastContainer, toast } from 'react-toastify';
import Compressor from 'compressorjs';
import CodeEditor from './CodeEditor';
import { ChiTextEditor } from './ChiTextEditor';
import { EngTextEditor } from './EngTextEditor';

// using styled-components to style the form
const StyledForm = styled(Form)`
    border: 3px solid black;
    background: #fff;
    padding: 25px;
    margin: 20px;
    display: flex-row;
    width: 1000px;
    
    textarea {
        font-size: 17px;
    }

    input {
        font-size: 17px;
        padding-left: 17px;
    }

    h3 {
        padding-left: 17px;
    }

    .ql-editor {
        font-size: 18px;
        color: inherit;
    }

    @media screen and (max-width: 1200px) {
        width: 100%;
    }
`;

const AddStep = () => {

    const params = useParams();
    const navigate = useNavigate();
    getData(params);

    globalVar.labID = params.lab_number;
    globalVar.taskID = params.task_number;

    const [uploadPercentage, setUploadPercentage] = useState(0);

    // console.log(globalVar);


    var newStepNum = -1;

    if (globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.taskID - 1].steps.length == 0)
        newStepNum = 1;
    else
        newStepNum = globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.taskID - 1].steps[globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.taskID - 1].steps.length - 1].step_number + 1;

    const [instEng, setInstEng] = useState('');
    const [instChi, setInstChi] = useState('這個步驟沒有中文版內容');   // default value
    const [displayImage, setDisplayImage] = useState(null);
    const [disableItem, setDisableItem] = useState(true);
    const [code, setCode] = useState('');

    // this function is used to get the code from CodeEditor.js
    const getCode = (newCode) => {
        setCode(newCode);
    }

    // this function is used to get the steps chi info from ChiTextEditor.js
    const getInstChi = (instChi) => {
        setInstChi(instChi);
        console.log('instChi', instChi);
    }

    // this function is used to get the steps eng info from EngTextEditor.js
    const getInstEng = (instEng) => {
        setInstEng(instEng);
        console.log('instEng', instEng);
    }

    const handleCheckBox = () => {
        setDisableItem(!disableItem);
    }

    /* For splitting chi name and eng name */

    const splitName = (name) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            return name.split(' | ')[0] + ' ' + name.split(' | ')[1]
        }
    }

    const splitCourseName = (name, lang) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            if (lang == 'eng') {
                return name.split(' | ')[0]
            } else {
                return name.split(' | ')[1]
            }
        }
    }

    // this function is used to upload the image to the server, called when clicking save button
    const handleUploadImage = async (event, stepID) => {

        event.preventDefault();
        const image = document.querySelector('input[type="file"]').files[0];
        const data = new FormData();

        data.append('image', image, image.name);

        const options = {
            maxWidth: 1200,
            quality: 1.0,
            success(result) {
                const formData = new FormData();
                formData.append('image', result, result.name);

                // Make an Axios request to upload the compressed file
                axios.patch('https://peanutkingeducation.com/api/admin/steps/' + stepID + '/', formData, {
                    headers: {
                        'Authorization': Cookies.get('access_token'),
                    }
                }).then(response => {
                    console.log(response.data);
                    toast.success('Image Uploaded Successfully! 圖片上載成功！');
                    toast.info('Please click the steps number list to continue! 請按步驟號碼列表以繼續！');
                })
                    .catch(error => {
                        console.error(error);
                        toast.error('Image Upload Failed! 圖片上載失敗！');
                    });
            },
            error(error) {
                console.error(error.message);
            }
        };
        new Compressor(image, options);
    }

    return (
        <div>
            <div className='center' style={{ padding: "0" }}>
                <FetchSteps />
            </div>
            <div>
                <div style={{ padding: "0" }} id='add-step-form'>
                    <StyledForm layout='vertical'>
                        <h5 style={{ textAlign: 'center' }}>{splitCourseName(params.name, 'eng')} Lab {params.lab_number} Task {params.task_number} Add New Step <h5 style={{ color: 'red', fontWeight: 'bold' }}>(Step {newStepNum})</h5> </h5>
                        <h5 style={{ textAlign: 'center' }}>為{splitCourseName(params.name, 'chi')} 實驗{params.lab_number} 任務{params.task_number}新增步驟<h5 style={{ color: 'red', fontWeight: 'bold' }}>（步驟{newStepNum}）</h5></h5>
                        <p>PLEASE DO NOT REFRESH BROWSER 請勿刷新瀏覽器</p>
                        <p style={{ color: 'red' }}>CLICK THE '＋' ON STEPS NUM LIST IF U ARE ADDING MORE STEPS.</p>
                        <p style={{ color: 'red' }}>PLEASE WAIT FOR THE NEW STEP NUMBER TO LOAD AND MAKE SURE IT IS CORRECT.</p>
                        <p style={{ color: 'red' }}>如要繼續新增步驟，請按步驟號碼列表上的'＋'，請留意新步驟號碼需要時間載入並且是否正確</p>
                        <div>
                            <Form.Item label={<label style={{ fontSize: "22px", fontWeight: "bold", paddingTop: '10px' }} rules={[{ required: true, message: "Step Details should not be empty 步驟内容（英文）不能為空白" }]}>FILL IN THE STEP DETAILS</label>}>
                                {/* <textarea rows="10" cols="112" name="instruction_eng" value={instEng} onChange={(e) => {setInstEng(e.target.value)}}/> */}
                                <EngTextEditor instEng={getInstEng} value={instEng} id={params.name + params.lab_number + params.task_number + { newStepNum } + 'eng'} />
                            </Form.Item>
                            <Form.Item label={<label style={{ fontSize: "22px", fontWeight: "bold", paddingTop: '20px' }} rules={[{ required: true, message: "Step Details should not be empty 步驟内容（中文）不能為空白" }]}>填寫任務步驟內容</label>}>
                                {/* <textarea rows="10" cols="112" name="instruction_chi" value={instChi} onChange={(e) => {setInstChi(e.target.value)}}/> */}
                                <ChiTextEditor instChi={getInstChi} value={instChi} id={params.name + params.lab_number + params.task_number + { newStepNum } + 'chi'} />
                            </Form.Item>
                            <Form.Item label={<label style={{ fontSize: "22px", fontWeight: "bold", paddingTop: '20px' }}>Code 代碼</label>} >
                                {/* <p>Highlighter: from line <input onChange={(e) => { setStartLine(e.target.value) }}></input> to line <input onChange={(e) => { setEndLine(e.target.value)} }></input></p> */}
                                <CodeEditor code={getCode} />
                            </Form.Item>
                        </div>
                        <Image style={{ paddingLeft: '17px' }} src={displayImage} width={600} height='auto'></Image>
                        <Form.Item label={<label style={{ fontSize: "22px", fontWeight: "bold" }}>Upload a New Image 上載步驟新圖片</label>}>
                            <p>Please upload a single photo with max width of 1200 pixels. Photos exceeding the limit will be compressed to width of 1200 pixels.</p>
                            <p>請上載闊度最多為 1200 像素 的一張相片，超過限制的相片會被壓縮至1200 像素闊度。</p>
                            <Checkbox onClick={handleCheckBox} style={{ fontSize: "20px" }}><input type="file" accept='image/*' disabled={disableItem} onChange={(e) => { setDisplayImage(URL.createObjectURL(e.target.files[0])) }} /></Checkbox>
                        </Form.Item>
                        <div className='center'>
                            <button className='btn btn-save' style={{ width: "750px" }} onClick={(event) => {
                                event.preventDefault();
                                var data = new FormData();

                                data.append('step_number', newStepNum);
                                data.append('instruction_chi', instChi);
                                data.append('instruction_eng', instEng);
                                data.append('code_snippet', code);
                                data.append('course', globalVar.courseData.id);
                                data.append('lab', globalVar.courseData.labs[globalVar.labID - 1].id);
                                data.append('task', globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.taskID - 1].id);

                                const options = {
                                    headers: {
                                        'Authorization': Cookies.get('access_token'),
                                    },

                                    onUploadProgress: progressEvent => {
                                        const { loaded, total } = progressEvent;
                                        let percent = Math.floor((loaded * 100) / total);
                                        if (percent < 100) {
                                            setUploadPercentage(percent);
                                        }

                                    }
                                }

                                axios.post(globalVar.serverlocation + '/api/admin/steps/', data, options
                                ).then((response) => {
                                    console.log(response);
                                    setUploadPercentage(100);

                                    setTimeout(() => {
                                        setUploadPercentage(0);
                                    }, 1000);
                                    setInstChi('這個步驟沒有中文版內容');
                                    setInstEng('');
                                    toast.success('New Step Added 新增步驟成功', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, progress: undefined });
                                    if (!disableItem) {
                                        handleUploadImage(event, response.data.id);
                                    };
                                    getData(params);
                                    var uploadedImage = document.querySelector('input[type="file"]');
                                    if (uploadedImage.files.length > 0) {
                                        uploadedImage.value = null;
                                    }
                                    setDisplayImage(null);
                                    setCode('');
                                }).catch((error) => {
                                    console.log(error);
                                    setUploadPercentage(0);
                                    toast.error('Cannot add new step 新增步驟失敗', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, progress: undefined });
                                });
                            }}>新增步驟</button>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', paddingTop: '15px' }}>
                            <Progress
                                type='circle'
                                percent={uploadPercentage}
                            />
                        </div>
                    </StyledForm>
                </div>
                {/* <ToastContainer position="top-center" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnHover={false} /> */}
            </div>
        </div>
    )
}
export default AddStep;