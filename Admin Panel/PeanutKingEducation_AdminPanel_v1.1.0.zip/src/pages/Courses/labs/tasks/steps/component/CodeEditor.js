import AceEditor from 'react-ace'
import React, { useEffect } from 'react'
import 'ace-builds/src-noconflict/mode-c_cpp'
import 'ace-builds/src-noconflict/theme-textmate'

const CodeEditor = (props) => {

  function onChange(newCode) {
    // this will pass the new code back to addStep.js / stepEditor.js
    props.code(newCode);

    if (props.value === null) {
      props.code('');
    }
  }


  return (
    <div>
      <AceEditor
        key={props.id}
        mode='c_cpp'
        theme='textmate'
        fontSize={20}
        width='100%'
        onChange={onChange}
        defaultValue=''
        value={props.value}
      />
    </div>
  )
}
export default CodeEditor;
