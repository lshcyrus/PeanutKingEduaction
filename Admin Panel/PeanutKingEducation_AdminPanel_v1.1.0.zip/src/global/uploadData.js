import { ToastContainer, toast } from "react-toastify";
import axios from "axios";
import Cookies from "js-cookie";
import globalVar from "./globalVar";
import { getCourseData } from "./getCourseData";

export function uploadData(input) {
  const model = input.model + "/";
  const dataId = Object.values(input.id)[0];
  const dataType = input.dataType + "_";

  // console.log(input);

  var data = new FormData();
  // data.append("name", input);
  if (input.data1 != null) data.append(dataType + "eng", input.data1);
  if (input.data2 != null) data.append(dataType + "chi", input.data2);
  if (input.file != null) data.append("image", input.file);
  axios
    .patch(
      globalVar.serverlocation + "/api/admin/" + model + dataId + "/",    // '/api/admin/steps/stepID/', data, 
      data,
      {
        headers: {
          Authorization: Cookies.get("access_token"),
        },
      }
    )
    .then((res) => {
      // console.log(res.request.status);
      // console.log(res.data);
      if(input.clearNewImage)
        input.clearNewImage();
      toast.success("Saved and updated! 已儲存及更新！", {
        position: "top-center",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
      getCourseData();
    })
    .catch((err) => {
      console.log(err);
      console.log("upload data");
      // toast.error("Unknown error!", {
      //   position: "top-center",
      //   autoClose: 5000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      //   progress: undefined,
      // });
    });
}

export function uploadImage(input) {
  // console.log(input.file);
var data = new FormData();
const dataId = Object.values(input.id)[0];
data.append("image", input.file);
axios
  .patch(
    globalVar.serverlocation + "/api/admin/steps/" +
    dataId +
      "/",
    data,
    {
      headers: {
        Authorization: Cookies.get("access_token"),
      },
    }
  )
  .then((res) => {
    if (res.status == 201)
      toast.success("Uploaded!", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: false,
        progress: undefined,
      });
      getCourseData();
  })
  .catch((err) => {
    console.log(err);
  //   var obj = JSON.parse(err.request.response);
  //   for (const item in obj)
  //     toast.error(`${item}: ${obj[item]}`, {
  //       position: "top-center",
  //       autoClose: 5000,
  //       hideProgressBar: false,
  //       closeOnClick: true,
  //       pauseOnHover: false,
  //       progress: undefined,
  //     });
  });
}