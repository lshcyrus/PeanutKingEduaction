import React, { useEffect, useState } from "react"
import { useParams, useNavigate, Link, Outlet } from 'react-router-dom';
import globalVar from "./globalVar"
import { getData } from "../pages/Courses/components/getData"
import { CourseEditor } from "./CourseEditor";
import axios from "axios";
import Cookies from "js-cookie";

const CourseDetails = () => {

    const params = useParams();
    const [data, setData] = useState([]);

    getData(params);
    
    useEffect(() => {
        axios.get(globalVar.serverlocation + "/api/courses/" + params.name, {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        }).then(response => {
            setData([response.data])
        }).catch(function (error) {
            console.log(error)
        })
    } , [])

    /* For splitting chi name and eng name */

    const splitName = (name) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            return name.split(' | ')[0] + ' ' + name.split(' | ')[1]
        }
    }

    const splitCourseName = (name, lang) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            if (lang == 'eng') {
                return name.split(' | ')[0]
            } else {
                return name.split(' | ')[1]
            }
        }
    }

    return (
        <div>
            <div className="center">
                <h1>{splitName(params.name)}</h1>
                <div className="tabsNav">
                    <Link to="edit">Edit Course Details 修改課程資料</Link>
                    <Link to="addlab" state={{ details: data }}>Add New Lab 新增實驗</Link>
                    <Link to="lab">Labs 實驗列表</Link>
                </div>
                <Outlet />
            </div>
        </div>

    )

}
export default CourseDetails