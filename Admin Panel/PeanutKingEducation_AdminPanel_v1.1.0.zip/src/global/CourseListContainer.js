import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import Cookies from 'js-cookie'
import "./style.css";
import globalVar from "./globalVar";
import { getCourseData } from "./getCourseData";
import { FetchData } from "../pages/Courses/components/FetchData"

export class CourseListContainer extends React.Component {

    constructor() {
        super();
        // globalVar.courseData = datad;
        // globalVar.courseList = list;
        globalVar.atFullContainer = this;
        this.state = {
            adminMode: -1000,
            isAdminPanel: false,
            gotData: false,//need to change to false in production
        }
    }
    

    componentDidMount() {
        var self = this;
        let data;
        

        axios.get(globalVar.serverlocation + "/api/get_userinfo/", {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        })
        .then(res => {
            globalVar.username = res.data.name_eng;
        })
        .catch(err => console.log(err))

        //get course list
        axios.get(globalVar.serverlocation + "/api/admin/courses/", {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        }).then(function (response) {
            // console.log(response.data);
            globalVar.courseList = response.data;
            // self.setState({gotData: 1});
            // console.log(111111111)
            // console.log(globalVar.courseList);

            getCourseData({ self: self });
        }).catch(function (error) {
            //window.alert('error');
            console.log(error)
        })

        axios.get(globalVar.serverlocation + "/api/admin/courses/", {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        }).then(res => {
            data = res.data;
            this.setState({
                details: data
            });

            //console.log('COURSE DATA GET');
        })
        .catch(err => { })
    }

    onClick(props) {
        //console.log("clicked");
        this.setState({ adminMode: props.modeNum });
    }

    render() {
        //console.log("LabID: "+globalVar.labID+"TaskID: "+globalVar.taskID);
        // if (this.state.gotData == true) {
            // console.log("render");
            // console.log(globalVar.courseData);
            // console.log("render end");
            // console.log(this.state.adminMode);
            return (
            <div>
                <FetchData />
            </div>              
            );
        // } else {
        //     return ("Loading, please wait.");
        // }
    }
}