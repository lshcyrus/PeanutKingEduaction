import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';

export function confirmMessage(props){
    return(<Modal show={props.show} onHide={()=>props.handleClose()}>
                <Modal.Header closeButton>
                <Modal.Title>Confirm Message (確認信息)</Modal.Title>
                </Modal.Header>
                <Modal.Body>Do you want to delete this task? It cannot be recovered. 你想刪除這個任務嗎？動作不可復原。</Modal.Body>
                <Modal.Footer>
                <Button variant="save" onClick={()=>props.handleClose()}>
                    Cancel
                </Button>
                <Button variant="delete" onClick={()=>{props.handleClose();props.givenFunction({jumpToLab:() => props.jumpToEditLab()});}}>
                    Confirm
                </Button>
                </Modal.Footer>
            </Modal>);
}