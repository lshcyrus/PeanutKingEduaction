export default {
    // serverlocation: "http://192.168.0.191:8000",
    serverlocation: "https://peanutkingeducation.com",
    courseList:"",
    courseData: "",
    courseID: 1,
    labID: 1,//actually this means index in the array
    taskID: 1,//same as the previous line
    language: 'eng',
    username: "User",
    atFullContainer: null,
    // access_token is for development purpose only
    access_token: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbiI6InhxczdCS1JsbVNybDhkNHllaXd4WXA2emNPV0h5SiJ9.kFIQ5mcjTpgVVE0TszHAnqDLxAUp1C--94JhANX_2Z8",
}