import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import Cookies from 'js-cookie'
import { Collapse } from "bootstrap";

import "./style.css";
import globalVar from "./globalVar";
import { TopBar } from './TopBar';
import { getCourseData } from "./getCourseData";
import { AdminSideBarContainer } from "../pages/Management/components/AdminSideBar";
import Home from "../pages/Home"
import Loading from "./Loading";

export class FullContainer extends React.Component {
    constructor() {
        super();
        // globalVar.courseData = datad;
        // globalVar.courseList = list;
        globalVar.atFullContainer = this;
        this.state = {
            adminMode: -1000,
            isAdminPanel: false,
            gotData: false,//need to change to false in production
        }
    }


    componentDidMount() {
        // get all necessary data before rendering
        var self = this;

        axios.get(globalVar.serverlocation + "/api/get_userinfo/", {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        })
            .then(res => {
                globalVar.username = res.data.name_eng;
                console.log(Cookies.get('access_token'));
            })
            .catch(err => console.log(err))

        //get course list
        axios.get(globalVar.serverlocation + "/api/admin/courses/", {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        }).then(function (response) {
            //console.log(response.data);
            globalVar.courseList = response.data;
            //self.setState({gotData: 1});
            // console.log(111111111)
            // console.log(globalVar.courseList);

            getCourseData({ self: self });
        }).catch(function (error) {
            window.alert('Please login with admin account first. If you refreshed the browser, please login again.');
            console.log(error)
        })
    }

    onClick(props) {
        //console.log("clicked");
        this.setState({ adminMode: props.modeNum });
    }

    render() {
        //console.log("LabID: "+globalVar.labID+"TaskID: "+globalVar.taskID);
        if (this.state.gotData == true) {
            // console.log("render");
            // console.log(globalVar.courseData);
            // console.log("render end");
            // console.log(this.state.adminMode);
            return (
                <div className="body min-height100">
                    <header>
                        <TopBar switchAdminPanel={page => this.setState({ isAdminPanel: page, adminMode: 0 })} />
                    </header>
                    <div>
                        <div className="col-md-3 col-lg-2 d-md-block mb-0">
                            <div>
                                {(this.state.isAdminPanel) ?
                                    <AdminSideBarContainer
                                        jumpToPage={page => { this.setState({ adminMode: page }) }}
                                        nowPage={this.state.adminMode}
                                    /> : <div></div>
                                    // <SideBarContainer
                                    //     // jumpToEditCourse={() => { this.onClick({ modeNum: 0 }) }}
                                    //     // jumpToEditLab={() => { this.onClick({ modeNum: 1 }) }}
                                    //     // jumpToEditTask={() => { this.onClick({ modeNum: 2 }) }}
                                    //     // jumpToAddTask={() => { this.onClick({ modeNum: 3 }) }}
                                    //     // jumpToAddLab={() => { this.onClick({ modeNum: 4 }) }}
                                    //     // jumpToAddCourse={() => { this.onClick({ modeNum: 5 }) }}
                                    //     // jumpToAddMaterial={() => {this.onClick({ modeNum: 6})}}
                                    //     // jumpToEditMaterial={() => {this.onClick({ modeNum: 7})}}
                                    // />
                                }
                            </div>
                        </div>
                        <div className="center pt-65">
                            <Home />
                            {/* {(this.state.isAdminPanel && this.state.adminMode == 0) ? <ManageRole /> : ""}
                                {(this.state.isAdminPanel && this.state.adminMode == 1) ? <ManageActiveness /> : ""}                                                                                                            
                                {(this.state.isAdminPanel && this.state.adminMode == 2) ? <ShowKey /> : ""}
                                {(this.state.isAdminPanel && this.state.adminMode == 3) ? <ManageKeyPair /> : ""} */}
                            {/* {(!this.state.isAdminPanel && this.state.adminMode == 0) ? <CourseEditor /> : ""}
                                {(!this.state.isAdminPanel && this.state.adminMode == 1) ? <LabEditor /> : ""}                                                                                                                         
                                {(!this.state.isAdminPanel && this.state.adminMode == 2) ? <TaskEditor courseName={globalVar.courseData.name} labNumber={globalVar.courseData.labs[globalVar.labID-1].lab_number} task={globalVar.courseData.labs[globalVar.labID-1].tasks[globalVar.taskID-1]} jumpToEditLab={() => { this.onClick({ modeNum: 1 }) }}/> : <div></div>}
                                {(!this.state.isAdminPanel && this.state.adminMode == 3) ? <AddTask appRoot={this} courseName={globalVar.courseData.name} labName={globalVar.courseData.labs[globalVar.labID-1].lab_title_eng}/> : <div></div>}
                                {(!this.state.isAdminPanel && this.state.adminMode == 4) ? <AddLab course={globalVar.courseData} /> : <div></div>}
                                {(!this.state.isAdminPanel && this.state.adminMode == 5) ? <CourseAdder /> : <div></div>}
                                {(!this.state.isAdminPanel && this.state.adminMode == 6) ? <AddMaterial /> : <div></div>}
                                {(!this.state.isAdminPanel && this.state.adminMode == 7) ? <EditMaterial appRoot={this}/> : <div></div>} */}

                            {/* <img src={"https://hacks.mozilla.org/files/2021/02/image-4-500x315.png"}></img> */}
                        </div>
                    </div>
                </div>
            );
        } else {
            return (
                <div>
                    <h2 style={{ textAlign: "center", color: "GrayText" }}>Please login again if the loading time is long.</h2>
                    <Loading />
                    <nav>
                        <div className="nav-wrapper">
                            <a href="https://peanutkingeducation.com/sign-in.html">BACK TO SIGN-IN PAGE</a>
                        </div>
                    </nav>
                </div>
            );
        }
    }
}