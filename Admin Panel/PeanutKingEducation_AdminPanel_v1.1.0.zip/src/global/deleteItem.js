
/* I don't know what is this */

export function DeleteItem(props){

}