import { useState, useEffect } from "react";
import Accordion from 'react-bootstrap/Accordion';
import { toast } from 'react-toastify';
import axios from "axios";
import Cookies from "js-cookie";

import { uploadData, uploadImage } from "./uploadData";
import { getCourseData } from "./getCourseData";
import globalVar from "./globalVar";

export function ShowOneStep(props) {
    // console.log(props.step)

    const [stepID, setStepID] = useState(props.step.id);
    const [insEng, setInsEng] = useState(props.step.instruction_eng);
    const [insChi, setInsChi] = useState(props.step.instruction_chi);
    const [file, setFile] = useState(props.step.image);
    const [width, setWidth] = useState(window.innerWidth);
    const [newImg, setNewImg] = useState(null);

    useEffect(() => {
        setStepID(props.step.id);
        setInsEng(props.step.instruction_eng);
        setInsChi(props.step.instruction_chi);
        setFile(props.step.image);
    }, [stepID, props.step.id])

    window.addEventListener('resize', () => { setWidth(window.innerWidth) });

    return (
        <div>
            {/* trigger={"Step " + props.step.step_number} */}
            <Accordion.Item className="mt-3" eventKey={stepID}>
                    <Accordion.Header className="mx-0">Step {props.stepNumber} 
                        <div className="col">
                            <button className="btn btn-delete float-end" onClick={() => { 
                                axios.delete(globalVar.serverlocation + "/api/admin/steps/" + props.step.id + "/",{
                                    headers: {
                                        'Authorization': Cookies.get('access_token'),
                                    }
                                })
                                .then(res => {
                                    toast.success('Deleted!', {position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined,});
                                    getCourseData({name: globalVar.courseData.name});
                                })
                                .catch(err => {
                                    toast.error('Error!', {position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined,});
                                })
                            }}>
                                DELETE 刪除
                            </button>
                        </div>
                    </Accordion.Header>
                    <Accordion.Body>
                        <div className="row mb-3">
                        <div className="col-6 me-0">
                            <a>Fill in step details here (English):</a>
                            <td class="field-description_eng">
                                <textarea name="form-0-description_chi" cols="40" rows="3" style={{width: width * 5 / 12 - 80}} value={insEng} id="engStep" onChange={e => { setInsEng(e.target.value) }} className="vLargeTextField b-grey pk-textarea" required/>
                            </td>
                        </div>
                        <div className="col-6">
                            <a>在下欄填寫任務步驟內容（中文）:</a>
                            <td class="field-description_eng">
                                <textarea name="form-0-description_chi" cols="40" rows="3" style={{width: width * 5 / 12 - 80}} value={insChi} id="chiStep" onChange={e => { setInsChi(e.target.value) }} className="vLargeTextField b-grey pk-textarea" required/>
                            </td>
                        </div>
                    </div>
                    <a for="formFileMultiple" id="submitStatus" style={{padding:"0px"}}>Upload Image 上傳圖片 (Upload only 1 image, of suggested ratio 3:2. 只能上載一張圖片，建議尺寸比例為3:2。) </a>
                    {props.step.image != null ? <img src={props.step.image} style={{height:'500px'}}></img> : <div></div>}    
                    <div className="d-flex align-items-end mt-3">
                        <div className="p-0 w-100">
                            <input class="form-control br-0 w-100" type="file" id={"fileUpload"+props.step.id} defaultValue={""} onChange={(e) => setNewImg(e.target.files[0])} multiple />  
                            {newImg != null ? <img src={URL.createObjectURL(newImg)} style={{height:'500px'}}></img> : <div></div>}
                        </div>
                    </div>
                    <div className="row mt-3">
                        <div className="col float-end">
                            <button className="btn btn-save float-end" onClick={() => {
                                uploadData({model:"steps",id:{stepID},dataType:"instruction",data1:insEng,data2:insChi,file:newImg,clearNewImage:setNewImg});
                            }}>
                                SAVE 儲存
                            </button>
                        </div>
                    </div>
                </Accordion.Body>
            </Accordion.Item>
        </div>
    );
}