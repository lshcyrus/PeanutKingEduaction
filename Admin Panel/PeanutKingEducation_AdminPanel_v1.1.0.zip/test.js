import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import globalVar from './src/global/globalVar';
import { Form, Popover } from 'antd';
import Button from 'react-bootstrap/Button';
import styled from 'styled-components';
import axios from 'axios';
import Cookies from 'js-cookie';
import { toast, ToastContainer } from 'react-toastify';

const EditCourse = () => {
    return (
        <div>
            
        </div>
    );
}

export default EditCourse;
