import React from "react";
import { Link, Outlet } from 'react-router-dom';
import { TopBar } from "../../global/TopBar";
import "../../global/style.css"
import "bootstrap/dist/css/bootstrap.min.css"
import { ToastContainer } from "react-toastify";

const Materials = () => {

    /* 
        This is the page for Materials.
        Here shows the router of the Materials page.
        <Link /> is for redirection.
        <Outlet /> is for nested routing and show the children (/material/add, /material/edit) in the same page.
        CSS Styles (style.css) are used to decorate the <Link /> component and turns them into tabs button.
    */

    return (
    <div>
        <TopBar />
        <div className="center">
            <h1>MATERIALS 材料</h1>
            <div className="tabsNav">
                <Link to="/"> HOME 返回主頁 </Link>
                <Link to="/materials/add"> Add New Materials 新增材料 </Link>             
                <Link to="/materials/edit"> Edit Materials 編輯材料 </Link>
            </div>
            <ToastContainer />
            <Outlet/> 
        </div>
    </div>
    )
}

export default Materials