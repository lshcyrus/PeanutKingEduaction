import { useState, useEffect } from "react";
import axios from "axios";
import Cookies from "js-cookie";
import { toast } from "react-toastify";

import globalVar from "../../../global/globalVar";

export function OneItem(props) {
    const [mid, setMID] = useState(props.item.material_id);
    const [engName, setEngName] = useState(props.item.material_name_eng);
    const [chiName, setChiName] = useState(props.item.material_name_chi);
    const [newImg, setNewImg] = useState(null);

    useEffect(() => {
        setMID(props.item.material_id);
        setEngName(props.item.material_name_eng);
        setChiName(props.item.material_name_chi);
        setNewImg(props.item.material_mg);
    }, [props.item.material_id])

    return (
        <div>
            {/* {console.log(item.id)} */}
            <div className="row g-3 stepContentText px-3 pe-0">
                <div className="col-3 square">
                    <img src={props.item.material_img}></img>
                </div>
                <div className={"col-9 "+(window.innerWidth<=810)?"":"ms-5"}>
                <label className="form-label ps-0">ID:</label><input className="form-control EditorInput form-control br-0" id={"mid" + props.item.id.toString()} type="text" value={mid} onChange={(e) => {setMID(e.target.value)}}></input>
                <label className="form-label ps-0">Name:</label><input className="form-control EditorInput form-control br-0" id={"eng" + props.item.id.toString()} type="text" value={engName} onChange={(e) => {setEngName(e.target.value)}}></input>
                <label className="form-label ps-0">名稱:</label><input className="form-control EditorInput form-control br-0" id={"chi" + props.item.id.toString()} type="text" value={chiName} onChange={(e) => {setChiName(e.target.value)}}></input>

                <label className="form-label ps-0">Upload Image 上傳圖片 (Upload only 1 image, of suggested ratio 3:2. 只能上載一張圖片，建議尺寸比例為3:2。)</label>
                <input type="file" className="form-control br-0 mb-3" onChange={(e) => {setNewImg(e.target.files[0])}}></input>
                {newImg? <img src={URL.createObjectURL(newImg)}/> : <div/>}

                <button className="btn btn-save float-end" onClick={() => {
                    //console.log(mid);
                    var data = new FormData();
                    data.append("material_id", mid);
                    data.append("material_name_eng", engName);
                    data.append("material_name_chi", chiName);
                    if (newImg)
                        data.append("material_img", newImg);
                    axios.patch(globalVar.serverlocation + "/api/admin/materials/" + props.item.id + "/", data, {
                        headers: {
                            'Authorization': Cookies.get('access_token')
                        }
                    })
                        .then(res => {
                            setNewImg(null);
                            toast.success('Updated!', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                            props.getM();
                        })
                        .catch(err => {
                            //console.log(err);
                            toast.error('Error!', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                        })
                }}>UPDATE 更新</button>

                <button className="btn btn-delete float-end" onClick={() => {
                    axios.delete(globalVar.serverlocation + "/api/admin/materials/" + props.item.id + "/", {
                        headers: {
                            'Authorization': Cookies.get('access_token')
                        }
                    })
                        .then(res => {
                            toast.success('Deleted!', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                            props.getM();
                        })
                        .catch(err => {
                            //console.log(err);
                            toast.error('Error!', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                        })
                }}>DELETE 刪除</button>
                </div>
            </div>
            <hr></hr>
        </div>
    );
}