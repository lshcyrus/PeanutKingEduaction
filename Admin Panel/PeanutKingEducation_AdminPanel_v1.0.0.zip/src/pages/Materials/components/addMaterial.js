// import { useState } from "react";
// import axios from "axios";
// import { ToastContainer, toast } from 'react-toastify';
// import Cookies from "js-cookie";

// import globalVar from "../../../global/globalVar";

// export function AddMaterial(){
//     const [engMatName, setEngMatName] = useState("");
//     const [chiMatName, setChiMatName] = useState("");
//     const [mid,setMid] = useState("");
//     const [file, setFile] = useState(null);

//     return(
//     <div className="my-3 bg-body shadow-sm">
//         <ToastContainer position="top-right" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnFocusLoss pauseOnHover/><ToastContainer />
//         <div className="bg-pkDarkBlue2">
//             <h3 className="p-3" style={{color:"white"}}>Adding New Material 增加新材料</h3>
//         </div>
//         <div className="row g-3 stepContentText p-3 pt-0">
//             <label className="form-label ps-0">ITEM ID:</label><input className="form-control EditorInput form-control br-0" type="text" id="mid" value={mid} onChange={(e) => {setMid(e.target.value)}}></input>
//             <label className="form-label ps-0">ENGLISH NAME:</label><input className="form-control EditorInput form-control br-0" type="text" id="matName_eng" value={engMatName} onChange={(e) => {setEngMatName(e.target.value)}}></input>
//             <label className="form-label ps-0">中文名稱:</label><input className="form-control EditorInput form-control br-0" type="text" id="matName_chi" value={chiMatName} onChange={(e) => {setChiMatName(e.target.value)}}></input>
//             <label className="form-label ps-0">Upload Image 上傳圖片 (Upload only 1 image, of suggested ratio 3:2. 只能上載一張圖片，建議尺寸比例為3:2。)</label>
//             <input className="form-control br-0" type="file" onChange={(e) => {
//                 // console.log(engMatName," ",chiMatName);
//                 // console.log(e.target.files);
//                 setFile(e.target.files[0])}} id="matImage"/>
//             {file ? <img src={URL.createObjectURL(file)}/> : <div></div>}

//             <button className="btn btn-outline-success" onClick={() => {
//                 var s = mid + " " +engMatName + " " +chiMatName + " " + (file? file : "not selected");
//                 if(mid=="" || engMatName=="" || chiMatName=="" || file==null){
//                     toast.error("You must fill in all information and select an image!", { position: "top-center", autoClose: 5000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined,});
//                 }else{
//                     var data = new FormData();
//                     data.append("material_id", mid);
//                     data.append("material_name_eng", engMatName);
//                     data.append("material_name_chi", chiMatName);
//                     data.append("material_img", file);
//                     axios.post(globalVar.serverlocation + "/api/admin/materials/", data, {
//                         headers: {
//                             'Authorization': Cookies.get('access_token')
//                         }
//                     })
//                     .then(res => {
//                         toast.success("Material added!", { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined,});
//                         setEngMatName("");
//                         setChiMatName("");
//                         setMid("");
//                         setFile(null);
//                         document.getElementById("matImage").value = "";
//                     })
//                     .catch(err => {
//                         toast.error("Error!", { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined,});
//                     })
//                 } 

//                 }}>Upload 上載</button>
//         </div>
//     </div>     
//     );

// }

import { Button, Form, Input, Image } from 'antd';
import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import axios from 'axios';
import Cookies from 'js-cookie';
import { ToastContainer, toast } from 'react-toastify';
import globalVar from '../../../global/globalVar';
import { useNavigate } from 'react-router-dom';
import Compressor from 'compressorjs';
import noimg from '../../../global/media/no-image.png'

const StyledForm = styled(Form)`
    border: 3px solid black;
    background-color: #fff;
    padding: 25px;
    margin: 20px;
    width: 900px;
    display: flex-row;

    h3 {
        font-size: 28px;
        text-align: center;
        padding-bottom: 20px;
    }

    Input {
        font-size: 17px;
        width: 100%;
        border: 1px solid black;
        border-radius: 0;
    }
    
    label {
        font-size: 18px;
        
    }

    TextArea {
        font-size: 17px;
        width: 100%;
        border: 1px solid black;
        border-radius: 0;
    }

    .ant-form-item-explain-error {
        font-size: 16px;
    }

    @media screen and (max-width: 900px) {
        width: fit-content;
        margin: 0;
        padding: 5;
    }

`;

// this component controls the submit button of the form, it validates the form and enables the button if the form is valid
const SubmitButton = ({ form }) => {
    const [submittable, setSubmittable] = useState(false);

    const values = Form.useWatch([], form);


    useEffect(() => {
        form.validateFields({ validateOnly: true }).then(
            () => {
                setSubmittable(true);
            },
            () => {
                setSubmittable(false);
            },
        );
    }, [values]);

    return (
        <Button className='btn btn-outline-success float-end' type='primary' htmlType='submit' disabled={!submittable}
            style={{ width: '120px', height: '50px', border: '2px solid', borderRadius: '0', padding: '5px' }}>
            UPLOAD 上載
        </Button>
    );
};

const AddMaterial = () => {
    const [form] = Form.useForm();
    const [materialID, setMaterialID] = useState('');
    const [nameEng, setNameEng] = useState('');
    const [nameChi, setNameChi] = useState('');
    const [displayImg, setDisplayImg] = useState(null);


    const navigate = useNavigate();

    function toMaterialList() {
        navigate('/materials/edit/');
    }

    const [mList, setMList] = useState([]);

    axios.get(globalVar.serverlocation + '/api/admin/materials/', {
        headers: {
            'Authorization': Cookies.get('access_token'),
        }
    }).then(res => {
        setMList(res.data);

    }).catch(err => {
        // console.log(err);
    });

    const mIDList = mList.map(m => m.material_id);

    useEffect(() => {
        for (var i = 0; i < mIDList.length; i++) {
            if (mIDList[i] == materialID) {
                toast.error(`Material ID ${mIDList[i]} already exists!`, { position: "top-center", autoClose: 5000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                toast.error(`材料編號 ${mIDList[i]}已經存在！`, { position: "top-center", autoClose: 5000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                setMaterialID("");
            }
        }
    }, [materialID]);
    

    // This function is called when the user clicks the submit button of the form, values contains all the values of the fields in the form
    const onFinish = (values) => {

        const image = document.querySelector('input[type="file"]').files[0];
        const options = {
            maxWidth: 400,
            quality: 1.0,
            success(result) {

                var data = new FormData();
                data.append('material_id', values.materialID);
                data.append('material_name_eng', values.nameEng);
                data.append('material_name_chi', values.nameChi);
                data.append('material_img', result, result.name);

                axios.post(globalVar.serverlocation + '/api/admin/materials/', data, {
                    headers: {
                        'Authorization': Cookies.get('access_token'),
                    }
                })
                    .then(res => {
                        toast.success("Material added!", { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                        setNameEng("");
                        setNameChi("");
                        setMaterialID("");
                        toMaterialList();   // navigate to material list page
                    })
                    .catch(err => {
                        toast.error("Error!", { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                    });
            },
            error(error) {
                console.error(error.message);
            }
        };

        new Compressor(image, options);
    };

    return (
        <div>
            <StyledForm form={form} onFinish={onFinish} layout='vertical'>
                <h3>ADD NEW MATERIAL 新增材料</h3>
                <Form.Item name='materialID' label={<label>Material ID 材料編號</label>} rules={[{ required: true, message: 'Material ID cannot be empty 材料編號不能為空白' }]}>
                    <Input placeholder='ENTER MATERIAL ID 請輸入材料編號' value={materialID} onChange={(e) => setMaterialID(e.target.value)} />
                </Form.Item>
                <Form.Item name='nameEng' label={<label>Material Name</label>} rules={[{ required: true, message: 'Material Name (English) cannot be empty 材料名稱 (英文) 不能為空白' }]}>
                    <Input placeholder='ENTER MATERIAL NAME (ENGLISH) 請輸入材料名稱 (英文)' value={nameEng} onChange={(e) => setNameEng(e.target.value)} />
                </Form.Item>
                <Form.Item name='nameChi' label={<label>材料名稱 (中文)</label>} rules={[{ required: true, message: 'Material Name (Chinese) cannot be empty 材料名稱 (中文) 不能為空白' }]}>
                    <Input placeholder='ENTER MATERIAL NAME (CHINESE) 請輸入材料名稱 (中文)' value={nameChi} onChange={(e) => setNameChi(e.target.value)} />
                </Form.Item>
                <Form.Item name='image' label={<label>Material Image 材料圖片</label>} rules={[{ required: true, message: 'Please upload photo for material. 請上載材料的圖片' }]}>
                    {/* <p>Requirement: at least 400 pixels in width</p><p>要求：相片闊度達400像素</p> */}
                    <input type='file' accept='image/*' onChange={(e) => setDisplayImg(URL.createObjectURL(e.target.files[0]))} style={{ border: 0 }} />
                </Form.Item>
                <Image src={displayImg} style={{ width: '400px' }} />
                <Form.Item style={{ paddingTop: '25px' }}>
                    <SubmitButton form={form} />
                </Form.Item>
            </StyledForm>
        </div>

    )
};
export default AddMaterial;
