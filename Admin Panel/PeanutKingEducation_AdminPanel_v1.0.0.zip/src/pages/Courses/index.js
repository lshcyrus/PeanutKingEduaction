import React from "react";
import "../../global/style.css"
import { TopBar } from "../../global/TopBar";
import { Link, Outlet} from 'react-router-dom';
import { ToastContainer } from 'react-toastify';

const Courses = () => {
 
    /* className specifies the css class name in style.css 
       <Link /> is a placeholder for links to other pages
       <Outlet /> is a placeholder for child routes to render its contents, only use in parent routes
       <ToastContainer /> is a placeholder for toast notifications in all child routes
    */

    return ( 
        <div className="center">
            <TopBar />
            <div className="center">
                <h1>COURSES 課程</h1>
            </div>
                <div className="tabsNav">
                    <Link to="/"> HOME 返回主頁 </Link>
                    <Link to="/courses/add"> Add New Courses 增加新課程 </Link>
                    <Link to="/courses/list"> Courses List 課程列表 </Link>
                    <ToastContainer position="top-center" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false}/>
                </div>
                <Outlet/>
        </div>

    )
}

export default Courses