import axios from 'axios';
import Cookies from 'js-cookie'

import globalVar from '../../../global/globalVar';

export function getData(props){
    //get course data
    // console.log("getting course data", props.name);
    axios.get(globalVar.serverlocation + "/api/courses/" + (props.name==null?globalVar.courseList[0].name:props.name), {
        headers: {
            'Authorization': Cookies.get('access_token'),
        }
    }).then(function (response) {
        //console.log(response.data);
        globalVar.courseData = response.data;
        // self.setState({gotData: 1});
        
        // console.log(1111111121)
        // console.log(globalVar.courseData);
    }).catch(function (error) {
        //window.alert('error');
        console.log(error)
    })
}