import axios from "axios";
import React, { useEffect, useState } from "react";
import globalVar from "../../../global/globalVar";
import Cookies from "js-cookie";
import { getCourseData } from "../../../global/getCourseData";
import { useNavigate, Link, Outlet } from 'react-router-dom';

export function FetchData () {

    const navigate = useNavigate();

    const [courseLists, setCourseLists] = useState([]);

    useEffect(() => {
        axios.get(globalVar.serverlocation + "/api/admin/courses/", {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        }).then(res => { setCourseLists(res.data) })
          .catch(function (error) {
            //window.alert('error');
            //console.log(error);
        })
    }, [])

    return (
        <div>
            <table>
                <thead>
                    <tr>
                        {/* <th>ID</th> */}
                        <th>COURSE NAME 課程名稱</th>
                        <th>DESCRIPTION 簡介</th>
                        {/* <th>Chin Description</th>
                        <th>Eng Description</th> */}
                    </tr>
                </thead>
                <tbody>
                    {courseLists.map((course) => (
                        <tr key={course.id}>
                            {/* <td>{render.id}</td> */}
                            <td onClick={() => {navigate(`/courses/${course.name}/`)}}>{course.name}</td>
                            <td onClick={() => {navigate(`/courses/${course.name}/`)}}>{course.description_eng}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}