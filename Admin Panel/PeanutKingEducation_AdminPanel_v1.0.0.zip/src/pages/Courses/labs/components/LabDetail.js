import React, { useEffect } from "react"
import { useParams, useNavigate, Link, Outlet, useLocation } from 'react-router-dom';
import globalVar from "../../../../global/globalVar";
import { getData } from "../../components/getData";
import { FetchLabNum } from "./FetchLabNum";

const LabDetail = () => {

    const params = useParams();
    const location = useLocation();
    const lab_number = params.lab_number;
    const lab_title_eng = location.state.lab_title_eng;
    const lab_title_chi = location.state.lab_title_chi;
    const lab_outcome_eng = location.state.lab_outcome_eng;
    const lab_outcome_chi = location.state.lab_outcome_chi;

    /* For splitting chi name and eng name */

    const splitName = (name) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            return name.split(' | ')[0] + ' ' + name.split(' | ')[1]
        }
    }

    globalVar.labID = lab_number;
    getData(params);        // get the data from the backend server

    return (
        <div>
            <div className="center">
                <FetchLabNum />
            </div>
            <div className="center">
                <h1>{splitName(params.name)} - Lab {params.lab_number}</h1>
                <h1>{lab_title_eng} {lab_title_chi}</h1>
            </div>
            <div className="tabsNav">
                <Link to="edit" state={{ lab_title_eng: lab_title_eng, lab_title_chi: lab_title_chi, lab_outcome_eng: lab_outcome_eng, lab_outcome_chi: lab_outcome_chi }}> Edit Lab 編輯實驗內容</Link>
                <Link to="edit-materials" state={{ lab_title_eng: lab_title_eng, lab_title_chi: lab_title_chi, lab_outcome_eng: lab_outcome_eng, lab_outcome_chi: lab_outcome_chi }}> Manage Materials 管理任務材料</Link>
                <Link to="add-task" state={{ lab_title_eng: lab_title_eng, lab_title_chi: lab_title_chi, lab_outcome_eng: lab_outcome_eng, lab_outcome_chi: lab_outcome_chi }}> Add New Task 新增任務</Link>
                <Link to="task" state={{ lab_title_eng: lab_title_eng, lab_title_chi: lab_title_chi, lab_outcome_eng: lab_outcome_eng, lab_outcome_chi: lab_outcome_chi }}>Task List 任務清單</Link>
            </div>
            <Outlet />
        </div>
    )
}
export default LabDetail;