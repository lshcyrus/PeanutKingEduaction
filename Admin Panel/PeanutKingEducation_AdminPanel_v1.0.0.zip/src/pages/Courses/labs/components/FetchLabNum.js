/* 
    This React component renders the horizontal list of current available labs of a chosen course.
*/

import axios from "axios";
import React, { useEffect, useState } from "react";
import globalVar from "../../../../global/globalVar";
import Cookies from "js-cookie";
import { useNavigate, useParams } from 'react-router-dom';

export function FetchLabNum(props) {

    const params = useParams();     // for getting the params from the url, e.g. /courses/:name, params.name returns the name
    const navigate = useNavigate();
    const [CourseDetail, setCourseDetail] = useState([]);

    /* For splitting chi name and eng name */

    const splitName = (name) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            return name.split(' | ')[0] + ' ' + name.split(' | ')[1]
        }
    }

    const splitCourseName = (name, lang) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            if (lang == 'eng') {
                return name.split(' | ')[0]
            } else {
                return name.split(' | ')[1]
            }
        }
    }


    useEffect(() => {
        axios.get(globalVar.serverlocation + "/api/courses/" + (params.name == null ? globalVar.courseList[0].name : params.name), {
            headers: {
                'Authorization': Cookies.get('access_token'),
                // 'Authorization': globalVar.access_token,
            }
        }).then(function (response) {
            setCourseDetail([response.data]);  // adding [] to make response data into an array
        }).catch(function (error) {
            console.log(error)
        })
    })

    return (
        <div>
            <table>
                <h2 style={{ textAlign: "center", textDecorationLine: "underline" }}>{splitName(params.name)}</h2>
                <h2 style={{ textAlign: "center" }}>Labs 實驗</h2>
                <tbody style={{ display: "flex", justifyContent: "center", justifyItems: "center" }}>
                    {CourseDetail.map((course) =>
                        <div key={course.id}>
                            {course.labs.map((lab) =>
                                <td style={{ color: "black", fontSize: "24px", fontWeight: "bold", width: "50px", height: "50px", backgroundColor: "ghostwhite", cursor: "pointer", padding: "10px", border: "3px solid black", textAlign: "center" }} key={lab.id} onClick={() => {
                                    navigate(`/courses/${course.name}/lab/${lab.lab_number}/task/`
                                        , { state: { name: course.name, num: lab.lab_number, lab_title_eng: lab.lab_title_eng, lab_title_chi: lab.lab_title_chi, lab_outcome_eng: lab.learning_outcome_eng, lab_outcome_chi: lab.learning_outcome_chi } })
                                }}>{lab.lab_number}</td>
                            )}
                        </div>
                    )}
                    <div>
                        <td style={{ color: "black", fontSize: "24px", fontWeight: "bold", width: "50px", height: "50px", backgroundColor: "ghostwhite", cursor: "pointer", padding: "10px", border: "3px solid black", borderLeft: "none", textAlign: "center" }} onClick={() => { navigate(`/courses/${params.name}/addlab/`) }}>＋</td>
                    </div>
                </tbody>
            </table>
        </div>
    )
}