import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import globalVar from '../../../../global/globalVar';
import { Form, Popover } from 'antd';
import styled from 'styled-components';
import axios from 'axios';
import Cookies from 'js-cookie';
import { toast } from 'react-toastify';
import { getData } from '../../components/getData';
import { EngLabEditor } from './EngLabEditor';
import { ChiLabEditor } from './ChiLabEditor';

const StyledForm = styled(Form)`
    border: 3px solid black;
    background: #fff;
    padding: 25px;
    margin: 20px;
    width: 100%;
    display: flex-row;

    h2 {
        margin-bottom: 10px;
        text-align: center;
    }

    h3 {
        margin-bottom: 20px;
        text-align: center;
    }

    label {
        font-size: 20px;
    }

    input {
        font-size: 17px;
        width: 100%;
    }

    .ql-editor {
        font-size: 18px;
        font-weight: 500;
        color: inherit;
    }

`;


const AddNewLab = () => {

    const params = useParams();
    const navigate = useNavigate();
    const location = useLocation();

    var newLabNumber = -1;
    globalVar.courseData.labs.length > 0 ? newLabNumber = globalVar.courseData.labs[globalVar.courseData.labs.length - 1].lab_number + 1 : newLabNumber = 1;
    
    const [labTitle, setLabTitle] = useState('');
    const [labTitleChi, setLabTitleChi] = useState('這個實驗沒有提供中文版名稱');
    const [labOutcome, setLabOutcome] = useState('');
    const [labOutcomeChi, setLabOutcomeChi] = useState('這個實驗沒有提供中文版學習目標');


    /* For splitting chi name and eng name */
    const splitName = (name) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            return name.split(' | ')[0] + ' ' + name.split(' | ')[1]
        }
    }

    const getLabOutcome = (newLabOutcome) => {          // This is a callback function which is passed to EngLabEditor, the props is defined as EngLabOutcome
        setLabOutcome(newLabOutcome);
        console.log(labOutcome);
    }

    const getLabOutcomeChi = (newLabOutcomeChi) => {    // This is a callback function which is passed to ChiLabEditor, the props is defined as ChiLabOutcome
        setLabOutcomeChi(newLabOutcomeChi);
        console.log(labOutcomeChi);
    }

    function redirectToLabList() {
        navigate('/courses/' + params.name + '/lab/');
    }

    return (

        <div className='center'>

            <StyledForm layout='vertical'>
                <h2>{splitName(params.name)}</h2>
                <h3>Add New Lab {newLabNumber} 新增實驗{newLabNumber}</h3>
                <p>PLEASE DO NOT REFRESH BROWSER 請勿刷新瀏覽器</p>
                <Form.Item label={<label>Lab Title</label>}>
                    <input type='text' value={labTitle} onChange={(e) => setLabTitle(e.target.value)} />
                </Form.Item>
                <Form.Item label={<label>實驗名稱</label>}>
                    <input type='text' value={labTitleChi} onChange={(e) => setLabTitleChi(e.target.value)} />
                </Form.Item>
                <Form.Item label={<label>Lab Learning Outcome</label>}>
                    <EngLabEditor EngLabOutcome={getLabOutcome} value={labOutcome} id={params.name + 'Lab' + newLabNumber + 'eng'} />
                </Form.Item>
                <Form.Item label={<label>實驗學習目標</label>} style={{ paddingTop: '20px' }}>
                    <ChiLabEditor ChiLabOutcome={getLabOutcomeChi} value={labOutcomeChi} id={params.name + 'Lab' + newLabNumber + 'chi'} />
                </Form.Item>
                <Form.Item style={{ paddingTop: '30px' }}>
                    <button
                        className="btn btn-save float-end"
                        onClick={() => {
                            var data = new FormData();          // this is essential for uploading data to the backend server

                            data.append("lab_number", newLabNumber);
                            data.append("lab_title_eng", labTitle);
                            data.append("lab_title_chi", labTitleChi);
                            data.append("learning_outcome_eng", labOutcome);
                            data.append("learning_outcome_chi", labOutcomeChi);
                            data.append("course", globalVar.courseData.id);
                            axios.post(globalVar.serverlocation + "/api/admin/labs/", data, {
                                headers: {
                                    'Authorization': Cookies.get('access_token'),
                                }
                            })
                                .then(res => {
                                    toast.success('Lab Created!', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, progress: undefined });
                                    getData(params);
                                    redirectToLabList();
                                })
                                .catch(err => {
                                    console.log(err);
                                    toast.error('Error!', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, progress: undefined });
                                });
                        }}>
                        SAVE 儲存
                    </button>
                </Form.Item>
            </StyledForm>
        </div>
    );
}

export default AddNewLab;
