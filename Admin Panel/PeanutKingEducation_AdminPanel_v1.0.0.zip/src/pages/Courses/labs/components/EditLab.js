import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import globalVar from '../../../../global/globalVar';
import Cookies from 'js-cookie';
import { Form, Popover } from 'antd';
import styled from 'styled-components';
import { toast } from 'react-toastify';
import { getData } from '../../components/getData';
import { Modal, Button } from "react-bootstrap";
import { ChiLabEditor } from './ChiLabEditor';
import { EngLabEditor } from './EngLabEditor';

const StyledForm = styled(Form)`
    border: 3px solid black;
    background: #fff;
    padding: 25px;
    width: 100%;
    display: flex-row;
    
    label {
        font-size: 20px;
    }

    input {
        font-size: 17px;
        width: 100%;
    }

    .ql-editor {
        font-size: 18px;
        font-weight: 500;
        color: inherit;
    }

`;

const EditLab = () => {

    const params = useParams();
    const navigate = useNavigate();
    const location = useLocation();
    globalVar.labID = params.lab_number;

    const [labTitle, setLabTitle] = useState(location.state.lab_title_eng);             // pass using state: ... from previous url
    const [labTitleChi, setLabTitleChi] = useState(location.state.lab_title_chi);
    const [labOutcome, setLabOutcome] = useState(location.state.lab_outcome_eng);
    const [labOutcomeChi, setLabOutcomeChi] = useState(location.state.lab_outcome_chi);

    const [show, setShow] = useState(false);

    const openModal = () => {
        setShow(true);
    }

    const closeModal = () => {
        setShow(false);
    }

    useEffect(() => {
        setLabTitle(location.state.lab_title_eng);
        setLabTitleChi(location.state.lab_title_chi);
        setLabOutcome(location.state.lab_outcome_eng);
        setLabOutcomeChi(location.state.lab_outcome_chi);
    }, [location.state.lab_title_eng, location.state.lab_title_chi, location.state.lab_outcome_eng, location.state.lab_outcome_chi]);

    const getLabOutcome = (newLabOutcome) => {          // This is a callback function which is passed to EngLabEditor, the props is defined as EngLabOutcome
        setLabOutcome(newLabOutcome);
        console.log(labOutcome);
    }

    const getLabOutcomeChi = (newLabOutcomeChi) => {    // This is a callback function which is passed to ChiLabEditor, the props is defined as ChiLabOutcome
        setLabOutcomeChi(newLabOutcomeChi);
        console.log(labOutcomeChi);
    }

    function redirectLab() {
        navigate(`/courses/${params.name}/lab/`);
    }

    function deleteLab() {
        axios.delete(`${globalVar.serverlocation}/api/admin/labs/${globalVar.courseData.labs[globalVar.labID - 1].id}/`, {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        })
            .then(res => {
                toast.success('Deleted!', { position: "top-center", autoClose: 3000, closeOnClick: true, pauseOnHover: false, progress: undefined, });
                getData(params);
                redirectLab();
            })
            .catch(err => console.log(err))
    }

    return (
        <div className='center'>
            <StyledForm layout='vertical'>
            <button style={{ display: 'grid', border: '2px solid black' }} className="btn btn-delete float-end" onClick={() => openModal()}>DELETE THIS LAB 刪除整個實驗頁面</button>
                <h2>Edit Contents of this Lab 編輯這個實驗</h2>
                <h3>Lab Number 實驗編號: {params.lab_number}</h3>
                <h6>Please select the lab from the number list if nothing is displayed.</h6>
                <h6>如果沒有顯示實驗資料，請從實驗編號列表中選擇想進行更改的實驗。</h6>
                <Form.Item label={<label>Lab Title</label>}>
                    <input type='text' value={labTitle} onChange={(e) => setLabTitle(e.target.value)} />
                </Form.Item>
                <Form.Item label={<label>實驗名稱</label>}>
                    <input type='text' value={labTitleChi} onChange={(e) => setLabTitleChi(e.target.value)} />
                </Form.Item>
                <Form.Item label={<label>Lab Learning Outcome</label>}>
                    <EngLabEditor EngLabOutcome={getLabOutcome} value={labOutcome} id={params.name + 'Lab' + params.lab_number + 'eng'} />
                </Form.Item>
                <Form.Item label={<label>實驗學習目標</label>} style={{ paddingTop: '30px' }}>
                    <ChiLabEditor ChiLabOutcome={getLabOutcomeChi} value={labOutcomeChi} id={params.name + 'Lab' + params.lab_number + 'chi'} />
                </Form.Item>
                <Form.Item style={{ paddingTop: '50px' }}>
                    <button className="btn btn-save float-end"
                        onClick={() => {

                            var data = new FormData();
                            data.append("lab_title_eng", labTitle);
                            data.append("lab_title_chi", labTitleChi);
                            data.append("learning_outcome_eng", labOutcome);
                            data.append("learning_outcome_chi", labOutcomeChi);

                            axios.patch(globalVar.serverlocation + "/api/admin/labs/" + globalVar.courseData.labs[globalVar.labID - 1].id + "/", data, {
                                headers: {
                                    'Authorization': Cookies.get('access_token')
                                }
                            })
                                .then(res => {
                                    getData(params);
                                    redirectLab();
                                    toast.success("Lab has been updated.");
                                })
                                .catch(err => console.log(err))
                        }}>SAVE 儲存</button>
                </Form.Item>
            </StyledForm>
            <Modal show={show} onHide={() => closeModal()}>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Message 確認信息</Modal.Title>
                </Modal.Header>
                <Modal.Body>Do you want to delete this lab? It cannot be recovered. 你想刪除這個實驗嗎？動作不可復原。</Modal.Body>
                <Modal.Footer>
                    <Button variant="save" onClick={() => { closeModal() }}>CANCEL 取消</Button>
                    <Button variant="delete" onClick={() => { closeModal(); deleteLab(); }}>CONFIRM 確認</Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
}

export default EditLab;
