
/* This React Component is built by Lester. */

import { useState } from "react";   // built-in React hook that allows adding state to a component
import Collapsible from "react-collapsible";
import axios from "axios";  // Javascript library to make HTTP requests from a browser
import { ToastContainer, toast } from 'react-toastify'; // React library that provides API for displaying notifications in React
import Cookies from "js-cookie";    // Javascript library for working with browser cookies
import { getCourseData } from "../../../../global/getCourseData";    // getCourseData is a function defined in getCourseData.js
import globalVar from "../../../../global/globalVar";    // globalVar contains the courses' common parameter, defined in globalVar.js
import { useParams } from "react-router-dom";

// var bridge = null;
// var mlist = null;

// function for adding new laboratory to the course
export function AddLab(props){
    const params = useParams();
    const [titleEng, setTitleEng] = useState("");   // English title
    const [titleChi, setTitleChi] = useState("這個實驗沒有中文名稱");   // Chinese title
    const [engOutcome, setEngOutcome] = useState("");   // English outcome
    const [chiOutcome, setChiOutcome] = useState("這個實驗沒有提供中文版學習目標");   // Chinese outcome
    // const [gotData,setGotData] = useState(false);
    // bridge = setGotData;

    // getMaterialList();
    
    /* 
    return() is the output of running the function AddLab.
    ToastContainer is the notification pop-up window located at the top. It is shown each time after user modification and clicked save button.
    
    */


  /* For splitting chi name and eng name, made by Cyrus */
  
  const splitName = (name) => {
    if (name.split(' | ').length == 1){
        return name
    } else {
        return name.split(' | ')[0] + ' ' + name.split(' | ')[1]
    }    
  }

  const splitCourseName = (name, lang) => {
    if (name.split(' | ').length == 1){
        return name
    } else {
        if (lang == 'eng') {
            return name.split(' | ')[0]
        } else {
            return name.split(' | ')[1]
        }
    }
  }

    return(
        <div className="editor-body">
            <ToastContainer position="top-center" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnFocusLoss={false} pauseOnHover={false}/>
            <div className="bg-pkDarkBlue2">  
                <h4 className="mb-3 p-3" style={{color:"white"}}>{splitName(params.name)} | Add New Lab 增加新實驗</h4>
            </div>
            <div className="p-3 pt-0 stepContentText row">
                <div className="col-6 mb-3"><p>Lab Title in English</p><input className="form-control EditorInput form-control br-0" type="text" id="engTitle" value={titleEng} onChange={(e) => { setTitleEng(e.target.value) }}></input></div>
                <div className="col-6 mb-3"><p>中文實驗標題</p><input className="form-control EditorInput form-control br-0" type="text" id="chiTitle" value={titleChi} onChange={(e) => { setTitleChi(e.target.value) }}></input></div>
                <div className="col-6 mb-3"><p>Learning Outcome (English)</p><input className="form-control EditorInput form-control br-0" type="text" id="engOut" value={engOutcome} onChange={(e) => { setEngOutcome(e.target.value) }}></input></div>
                <div className="col-6 mb-3"><p>學習目標（中文）</p><input className="form-control EditorInput form-control br-0" type="text" id="chiOut" value={chiOutcome} onChange={(e) => { setChiOutcome(e.target.value) }}></input></div>
                {/* <button onClick={() => {console.log(document.getElementById("engTitle").value)}}>test</button> */}
            </div>
            <div className="row p-3 pt-0">
                <div className="col">
                    <button
                    className="btn btn-save float-end" 
                    onClick={() => {
                    var data = new FormData();
                    // var newLabNumber = (globalVar.courseData.labs.length > 1) ? globalVar.courseData.labs[globalVar.courseData.labs.length - 2].lab_number + 1 : 1;
                    var newLabNumber = (globalVar.courseData.labs.length > 0) ? globalVar.courseData.labs[globalVar.courseData.labs.length - 1].lab_number + 1 : 1;

                    data.append("lab_number", newLabNumber);
                    data.append("lab_title_eng", titleEng);
                    data.append("lab_title_chi", titleChi);
                    data.append("learning_outcome_eng", engOutcome);
                    data.append("learning_outcome_chi", chiOutcome);
                    data.append("course", globalVar.courseData.id)
                    axios.post(globalVar.serverlocation + "/api/admin/labs/", data, {
                        headers: {
                            'Authorization': Cookies.get('access_token'),
                        }
                    })
                    .then(res => {
                        toast.success('Lab created!', {position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, progress: undefined});
                        getCourseData({name: globalVar.courseData.name});
                    })
                    .catch(err => {
                        console.log(err);
                        toast.error('Error!', {position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, progress: undefined});
                    });
                    }}>SAVE 儲存</button>
                </div>
            </div>
            
        </div>
    );
}