
/* This component renders the list of available labs of a chosen course. */

import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import globalVar from '../../../global/globalVar';
import Cookies from 'js-cookie';
import '../../../global/style.css';
import Loading from '../../../global/Loading';


const Labs = () => {

  const params = useParams();       // for getting the course name from the url using params.name
  const navigate = useNavigate();   // for navigation, used to navigate to other pages stated in App.js
  const [courseDetail, setCourseDetail] = useState([]);

  /* For splitting chi name and eng name */

  const splitName = (name) => {
    if (name.split(' | ').length == 1) {
      return name
    } else {
      return name.split(' | ')[0] + ' ' + name.split(' | ')[1]
    }
  }

  const splitCourseName = (name, lang) => {
    if (name.split(' | ').length == 1) {
      return name
    } else {
      if (lang == 'eng') {
        return name.split(' | ')[0]
      } else {
        return name.split(' | ')[1]
      }
    }
  }

  useEffect(() => {
    axios.get(globalVar.serverlocation + "/api/courses/" + params.name,
      {
        headers: {
          'Authorization': Cookies.get('access_token'),
        }
      }).then(response => setCourseDetail([response.data])).catch(error => console.log(error))
  }, [])


  // should be === , but it's working so... LMAO
  if (courseDetail.length == 0) {
    return (
      <Loading />
    )
  }

  // if there are no labs, display this
  if (courseDetail[0].labs.length == 0) {
    return (
      <div className='center'>
        <h5>{splitCourseName(params.name, 'eng')} does not contain any labs</h5>
        <h5>{splitCourseName(params.name, 'chi')} 沒有任何實驗</h5>
        <h5 style={{ color: "blue", textDecorationLine: "underline", cursor: "pointer" }}
          onClick={() => { navigate(`/courses/${params.name}/addlab/`) }}
        >Click here to add labs 按此開始為課程新增實驗</h5>
      </div>
    )
  }
  else {
    return (
      <div className='center'>
        <h1>{splitName(params.name)}</h1>
        <h2>LABS 實驗</h2>

        <table className='list-table'>
          <tbody>
            {courseDetail.map((course) =>
              <div key={course.id}>
                {course.labs.map((lab) =>
                  <tr key={lab.id} onClick={() => {
                    navigate(`/courses/${course.name}/lab/${lab.lab_number}/task/`,
                      { state: { name: course.name, id: lab.id, num: lab.lab_number, lab_title_eng: lab.lab_title_eng, lab_title_chi: lab.lab_title_chi, lab_outcome_eng: lab.learning_outcome_eng, lab_outcome_chi: lab.learning_outcome_chi } })
                  }}>
                    <td>{lab.lab_number}</td>
                    <td>{lab.lab_title_eng}</td>
                    <td>{lab.lab_title_chi}</td>
                    <td><div dangerouslySetInnerHTML={{ __html: lab.learning_outcome_eng }} /></td>
                    <td><div dangerouslySetInnerHTML={{ __html: lab.learning_outcome_chi }} /></td>
                  </tr>
                )}
              </div>
            )}
          </tbody>
        </table>
      </div>
    )
  }

}

export default Labs;