/* 
    This React component renders the task editor.
*/

import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import globalVar from '../../../../../global/globalVar';
import { getData } from '../../../../Courses/components/getData'
import { toast, ToastContainer } from 'react-toastify';
import { Form, Popover, Image } from 'antd';
import Button from 'react-bootstrap/Button';
import styled from 'styled-components';
import axios from 'axios';
import Cookies from 'js-cookie';
import Modal from 'react-bootstrap/Modal';
import { deleteTask } from './deleteTask';
import youtube from '../../../../../global/media/utube.png'
import { EngTaskEditor } from './EngTaskEditor';
import { ChiTaskEditor } from './ChiTaskEditor';

const StyledForm = styled(Form)`
    border: 3px solid black;
    background: #fff;
    padding: 25px;
    margin: 20px;
    width: 100%;
    display: flex-row;


    h3 {
        font-size: 28px;
    }

    input {
        font-size: 20px;
        width: 100%;
    }
    
    label {
        font-size: 20px;
        
    }

    textarea {
        font-size: 20px;
        width: 100%;
    }

    .ql-editor {
        font-size: 18px;
        font-weight: 500;
        color: inherit;
    }
`;

const TaskEditor = (props) => {

    console.log(props);

    const [taskID, setTaskID] = useState(props.task.id);
    const [engTitle, setEngTitle] = useState(props.task.title_eng);
    const [chiTitle, setChiTitle] = useState(props.task.title_chi);
    const [engBrief, setEngBrief] = useState(props.task.brief_eng);
    const [chiBrief, setChiBrief] = useState(props.task.brief_chi);
    const [video, setVideo] = useState(props.task.video);

    const params = useParams();
    const navigate = useNavigate();

    const [show, setShow] = useState(false);
    const handleShow = () => setShow(true);
    const handleClose = () => setShow(false);

    const reminder = (
        <div>
            <p>Copy and paste the video code after "youtube.com/watch?v="</p>
            <p>複製並貼上"youtube.com/watch?v="之後的影片編碼</p>
            <p>Format 格式: https://www.youtube.com/embed/qvzCmV3_12c</p>
            <Image src={youtube} />
        </div>
    );

    globalVar.labID = params.lab_number;
    globalVar.taskID = params.task_number;

    useEffect(() => {
        setTaskID(props.task.id);
        setEngTitle(props.task.title_eng);
        setChiTitle(props.task.title_chi);
        setEngBrief(props.task.brief_eng);
        setChiBrief(props.task.brief_chi);
        setVideo(props.task.video);
    }, [taskID, props.task.id])

    function redirectToTask (){
        navigate(`/courses/${params.name}/lab/${params.lab_number}/task/`, { state: { lab_title_eng: globalVar.courseData.labs[globalVar.labID - 1].lab_title_eng, lab_title_chi: globalVar.courseData.labs[globalVar.labID - 1].lab_title_chi, lab_outcome_eng: globalVar.courseData.labs[globalVar.labID - 1].learning_outcome_eng, lab_outcome_chi: globalVar.courseData.labs[globalVar.labID - 1].learning_outcome_chi } });
    }

    const getEngTaskBrief = (newEngBrief) => {
        setEngBrief(newEngBrief);
    }

    const getChiTaskBrief = (newChiBrief) => {
        setChiBrief(newChiBrief);
    }

    return (
        <div className='center'>
            <StyledForm layout='vertical'>
                <button style={{ display: "grid", border: "2px solid black" }} className="btn btn-delete float-end" onClick={() => { handleShow() }}>DELETE THIS TASK 刪除整個任務</button>
                <div style={{ display: "grid" }}>
                    <h3>{props.courseName} Lab {props.labNumber} Task {props.task.task_number}</h3>
                </div>
                <Form.Item label={<label>Task Title (English)</label>}>
                    <input type="text" value={engTitle} onChange={(e) => setEngTitle(e.target.value)} />
                </Form.Item>
                <Form.Item label={<label>任務名稱（中文）</label>}>
                    <input type="text" value={chiTitle} onChange={(e) => setChiTitle(e.target.value)} />
                </Form.Item>
                <Form.Item label={<label>Task Introduction (English)</label>}>
                    {/* <textarea rows={10} cols={100} value={engBrief} onChange={(e) => setEngBrief(e.target.value)} /> */}
                    <EngTaskEditor EngTaskBrief={getEngTaskBrief} value={engBrief} id={params.name + params.lab_number + params.task_number + 'eng'} />
                </Form.Item>
                <Form.Item label={<label>任務介紹（中文）</label>} style={{ paddingTop: '30px' }}>
                    {/* <textarea rows={10} cols={100} value={chiBrief} onChange={(e) => setChiBrief(e.target.value)} /> */}
                    <ChiTaskEditor ChiTaskBrief={getChiTaskBrief} value={chiBrief} id={params.name + params.lab_number + params.task_number + 'chi'} />
                </Form.Item>
                <Form.Item label={<label><Popover content={reminder} title='How to add a new video 如何新增影片:'><h6 style={{ textDecoration: "underline", color: 'blue' }}>Video URL 影片網址</h6></Popover></label>} style={{ paddingTop: '30px' }}>
                    <input type="url" value={video} defaultValue={'https://youtube.com/embed/'} onChange={(e) => setVideo(e.target.value)} />
                </Form.Item>
                <iframe style={{ width: '100%', height: '400px', border: '2px dotted black' }} src={props.task.video} controls></iframe>
                <Form.Item style={{ paddingTop: '30px' }}>
                    <button className='btn btn-save float-end' style={{ width: "20%" }}
                        onClick={() => {
                            var data = new FormData();              // declare a new form data type variable to store the data
                            data.append('title_eng', engTitle);     // append the data to the form data
                            data.append('title_chi', chiTitle);
                            data.append('brief_eng', engBrief);
                            data.append('brief_chi', chiBrief);
                            data.append('video', video);

                            axios.patch(globalVar.serverlocation + '/api/admin/tasks/' + globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.taskID - 1].id + '/', data, {
                                headers: {
                                    'Authorization': Cookies.get('access_token'),
                                }
                            }).then(res => {
                                toast.success('Task Updated. Refresh to see new changes on video. 任務資料已更新。刷新頁面以查看影片。');
                                getData(params);
                            }).catch(err => {
                                toast.error('Task Update Failed. 任務資料更新失敗。');
                            })

                        }}>SAVE 儲存</button>
                </Form.Item>
            </StyledForm>
            <ToastContainer position="top-center" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnHover={false} />
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Message 確認信息</Modal.Title>
                </Modal.Header>
                <Modal.Body>Do you want to delete this task? It cannot be recovered. 你想刪除這個任務嗎？動作不可復原。</Modal.Body>
                <Modal.Footer>
                    <Button variant="save" onClick={handleClose}>
                        CANCEL 取消
                    </Button>
                    <Button variant="delete" onClick={() => { deleteTask(); handleClose(); redirectToTask(); }}>
                        CONFIRM 確認
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}
export default TaskEditor;