
/* This React Component is for rendering the task adding form. */

import React, { useState } from "react";
import Cookies from "js-cookie";
import { ToastContainer, toast } from 'react-toastify';
import Switch from "react-switch";
import axios from "axios";
import globalVar from "../../../../../global/globalVar";
import { getCourseData } from "../../../../../global/getCourseData";
import { useParams } from "react-router-dom";
import youtube from "../../../../../global/media/utube.png"
import { Popover, Image } from "antd";

export function AddTask(props) {
    const [engTaskName, setEngTaskName] = useState("");
    const [chiTaskName, setChiTaskName] = useState("這個任務沒有中文名稱");
    const [engBrief, setEngBrief] = useState("");
    const [chiBrief, setChiBrief] = useState("這個任務沒有中文簡介");
    const [submitChi, setSubmitChi] = useState("");
    const [submitEng, setSubmitEng] = useState("");
    const [check, setCheck] = useState(false);
    const [file, setFile] = useState(null);
    const params = useParams();

    /* For splitting chi name and eng name */

    const splitName = (name) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            return name.split(' | ')[0] + ' ' + name.split(' | ')[1]
        }
    }

    const splitCourseName = (name, lang) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            if (lang == 'eng') {
                return name.split(' | ')[0]
            } else {
                return name.split(' | ')[1]
            }
        }
    }

    // popover content to display when users hover to the specified location
    const reminder = (
        <div>
            <p>Copy and paste the video code after "youtube.com/watch?v="</p>
            <p>複製並貼上"youtube.com/watch?v="之後的影片編碼</p>
            <p>Format 格式: https://www.youtube.com/embed/qvzCmV3_12c</p>
            <Image src={youtube} />
        </div>
    );

    return (
        <div className="editor-body">
            <ToastContainer position="top-center" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnFocusLoss={false} pauseOnHover={false} />
            <div className="bg-pkDarkBlue2 ">
                <h4 className="mb-3 p-3" style={{ color: "white" }}>{splitName(params.name)} | Lab {params.lab_number} | Add New Task 增加新任務</h4>
            </div>

            <div className="p-3 pt-0 stepContentText row">
                <div className="col-6"><p>Task Title (English):</p>
                    <input className="form-control EditorInput form-control br-0" type="text" id="taskName_eng" value={engTaskName} onChange={(e) => { setEngTaskName(e.target.value) }}></input>
                </div>
                <div className="col-6"><p>任務名稱（中文）：</p>
                    <input className="form-control EditorInput form-control br-0" type="text" id="taskName_chi" value={chiTaskName} onChange={(e) => { setChiTaskName(e.target.value) }}></input>
                    <p></p>
                </div>
                <div className="col-6"><p>Task Introduction:</p>
                    <input className="form-control EditorInput form-control br-0" type="text" id="brief_eng" value={engBrief} onChange={(e) => { setEngBrief(e.target.value) }}></input>
                </div>
                <div className="col-6"><p>任務介紹：</p>
                    <input className="form-control EditorInput form-control br-0" type="text" id="brief_chi" value={chiBrief} onChange={(e) => { setChiBrief(e.target.value) }}></input>
                    <p></p>
                </div>
                <br></br>
                <br />
                {file == null ? <div></div> : <iframe style={{ width: '70%', height: '400px' }} src={file} controls></iframe>}
                <br />
                <label for="formFileMultiple" id="submitStatus" class="form-label"><Popover content={reminder} title='How to add a new video 如何新增影片:'><h6 style={{ textDecoration: "underline" }}>Video URL 影片網址</h6></Popover></label>
                <input className="form-control br-0" type="url" id="fileUpload" defaultValue={"https://www.youtube.com/embed/"} onChange={(e) => setFile(e.target.value)} multiple />

                <p>Request students to submit assignment 要求學生遞交習作</p><Switch onChange={(e) => { setCheck(e); console.log(e); }} checked={check} />
                {check ?
                    <div>
                        <p>Submission requirement:</p><input type="text" value={submitEng} onChange={(e) => { setSubmitEng(e.target.value) }}></input>
                        <p>提交要求：</p><input type="text" value={submitChi} onChange={(e) => { setSubmitChi(e.target.value) }}></input>
                        {/* <button onClick={() => console.log(submitChi, " ", submitEng)}>test</button> */}
                    </div>
                    : <div></div>}

                <br></br>
                <div className="col">
                    <button className="btn btn-save float-end" onClick={() => {
                        var data = new FormData();
                        var newTaskNumber = (globalVar.courseData.labs[globalVar.labID - 1].tasks.length > 0) ? (globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.courseData.labs[globalVar.labID - 1].tasks.length - 1].task_number + 1) : 1;
                        // if(globalVar.courseData.labs[globalVar.labID-1].tasks.length != 1){
                        //     // newTaskNumber = globalVar.courseData.labs[globalVar.labID-1].tasks[globalVar.courseData.labs[globalVar.labID-1].tasks.length-2].task_number+1;
                        //     // console.log(globalVar.courseData.labs[globalVar.labID-1].tasks);
                        // }

                        console.log("submitting ", globalVar.courseData.labs)
                        console.log("submitting ", globalVar.labID - 1)
                        console.log("submitting ", globalVar.courseData.labs[globalVar.labID - 1].id)

                        data.append("task_number", newTaskNumber);
                        data.append("title_eng", engTaskName);
                        data.append("title_chi", chiTaskName);
                        data.append("brief_eng", engBrief);
                        data.append("brief_chi", chiBrief);
                        data.append("course", globalVar.courseData.id);//course id 
                        data.append("lab", globalVar.courseData.labs[globalVar.labID - 1].id);//lab id


                        /* 
                            this function is kept because I am not sure if we need it in the future 
                            I believe this boolean variable can act as a paramter for recording whether this is the last task in the lab,
                            if so, a button can be added to student panel and ask students whether they have finished the task or not.
                            After clicking the button, the backend server can record the progress of student, 
                            and hence the dashboard and progress bar function might be achievable.
                        */

                        data.append("submission_required", check);    
                        if (file != null)
                            data.append("video", file);
                        if (check) {
                            data.append("submission_requirements_eng", submitEng);
                            data.append("submission_requirements_chi", submitChi);
                        }
                        axios.post(globalVar.serverlocation + "/api/admin/tasks/", data, {
                            headers: {
                                'Authorization': Cookies.get('access_token')
                            }
                        }
                        )
                            .then(res => {
                                // console.log(res);
                                if (res.status == 201) {
                                    toast.success('Task added!', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, progress: undefined });
                                    getCourseData({ self: props.appRoot, name: globalVar.courseData.name })
                                }
                            })
                            .catch(err => {
                                //console.log(err.request);
                                var obj = JSON.parse(err.request.response);
                                for (const item in obj)
                                    toast.error(`${item}: ${obj[item]}`, { position: "top-center", autoClose: 5000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, progress: undefined });
                            })
                        // console.log(data);
                    }}>SAVE 儲存</button>
                </div>
                {/* <button onClick={() => {console.log(file)}}>test upload</button> */}

                <ToastContainer position="top-center" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnFocusLoss={false} pauseOnHover={false} />

                <br></br>
                <br></br>
            </div>

        </div>

    );
}