import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import globalVar from '../../../../../../global/globalVar';
import { getData } from '../../../../components/getData';
import FetchSteps from './FetchSteps';
import { Form, Image } from 'antd';
import Button from 'react-bootstrap/Button';
import styled from 'styled-components';
import axios from 'axios';
import Cookies from 'js-cookie';
import { ToastContainer, toast } from 'react-toastify';
import { getCourseData } from '../../../../../../global/getCourseData'
import { LazyLoadImage } from 'react-lazy-load-image-component';
import Loading from '../../../../../../global/Loading';
import Compressor from 'compressorjs';
import CodeEditor from './CodeEditor';
import { ChiTextEditor } from './ChiTextEditor';
import { EngTextEditor } from './EngTextEditor';


const StyledForm = styled(Form)`
    border: 3px solid black;
    background: #fff;
    padding: 25px;
    margin: 20px;
    display: flex-row;
    width: 1000px;
    
    textarea {
        font-size: 17px;
    }

    input {
        font-size: 17px;
        padding-left: 17px;
    }

    
    .ql-editor {
        font-size: 18px;
        font-weight: 500;
        color: inherit;
    }

    @media screen and (max-width: 1200px) {
        width: 100%;
    }
`;

const StepEditor = (props) => {

    const params = useParams();
    const navigate = useNavigate();
    const step_number = params.step_number;
    globalVar.labID = params.lab_number;
    globalVar.taskID = params.task_number;

    console.log(props);

    getData(params);

    const [stepID, setStepID] = useState(props.steps.id);
    const [instEng, setInstEng] = useState(props.steps.instruction_eng);
    const [instChi, setInstChi] = useState(props.steps.instruction_chi);
    const [image, setImage] = useState(props.steps.image);
    const fileInput = useRef(null);
    const [code, setCode] = useState(props.steps.code_snippet);
    const [displayImage, setDisplayImage] = useState(null);

    // image_alt_text is not used for anything else, so i use it to store the start and end line of the code snippet highlighter

    // const [startLine, setStartLine] = useState(props.steps.image_alt_text.split(' to ')[0]);
    // const [endLine, setEndLine] = useState(props.steps.image_alt_text.split(' to ')[1]);



    useEffect(() => {
        setStepID(props.steps.id);
        setInstEng(props.steps.instruction_eng);
        setInstChi(props.steps.instruction_chi);
        setImage(props.steps.image);
        setCode(props.steps.code_snippet);

    }, [props.steps.instruction_eng, props.steps.instruction_chi, props.steps.image, props.steps.code_snippet]);

    const getCode = (newCode) => {
        setCode(newCode);
    }

    const getInstChi = (instChi) => {
        setInstChi(instChi);
        console.log('instChi', instChi);
    }

    const getInstEng = (instEng) => {
        setInstEng(instEng);
        console.log('instEng', instEng);
    }

    // this function is for uploading image, called when uploading a new image, not when saving the step
    const handleUploadImage = async () => {

        const newImage = document.querySelector('input[type="file"]').files[0];
        const data = new FormData();

        data.append('image', newImage, newImage.name);

        const options = {
            maxWidth: 1200,
            quality: 1.0,
            success(result) {
                const formData = new FormData();
                formData.append('image', result, result.name);

                // Make an Axios request to upload the compressed file
                axios.patch('https://peanutkingeducation.com/api/admin/steps/' + stepID + '/', formData, {
                    headers: {
                        'Authorization': Cookies.get('access_token'),
                    }
                }).then(response => {
                    console.log(response.data);
                    toast.success('Image Uploaded Successfully! 圖片上載成功！');
                    toast.info('Please click SAVE to complete the modification. 請按「儲存」以完成步驟更改流程。');
                })
                    .catch(error => {
                        console.error(error);
                        toast.error('Image Upload Failed! 圖片上載失敗！');
                    });
            },
            error(error) {
                console.error(error.message);
            }
        };
        new Compressor(newImage, options);
    }

    /* For deleting step photo, I have tried PATCH and DELETE method but both not working. 
       The current method is using https://peanutkingeducation.com/admin/ Django Management Page and find the corresponding step.
       And then choose CLEAR photo. */


    /* For splitting chi name and eng name */
    const splitCourseName = (name, lang) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            if (lang == 'eng') {
                return name.split(' | ')[0]
            } else {
                return name.split(' | ')[1]
            }
        }
    }

    return (
        <div>
            <div className='center' style={{ padding: "0" }}>
                <FetchSteps />
            </div>

            <div className='center' style={{ paddingTop: 0 }}>
                <StyledForm layout='vertical' id='step-editor'>
                    <button className="btn btn-delete float-end" style={{ padding: "10px", border: "2px solid black" }} onClick={() => {
                        axios.delete(globalVar.serverlocation + "/api/admin/steps/" + props.steps.id + "/", {
                            headers: {
                                'Authorization': Cookies.get('access_token'),
                            }
                        })
                            .then(res => {
                                toast.success('Step Deleted!', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                                getData({ name: globalVar.courseData.name });

                            })
                            .catch(err => {
                                toast.error('Error!', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                            })
                    }}>
                        DELETE THIS STEP 刪除這個步驟
                    </button>
                    <div style={{ display: "grid", marginTop: "80px", textAlign: "center" }}>
                        <h5>{splitCourseName(params.name, 'eng')} Lab {params.lab_number} Task {params.task_number} Step {params.step_number}</h5>
                        <h5>{splitCourseName(params.name, 'chi')} 實驗{params.lab_number} 任務{params.task_number} 步驟{params.step_number}</h5>
                    </div>
                    <div>
                        <Form.Item label={<label style={{ fontSize: "22px", fontWeight: "bold" }}>FILL IN THE STEP DETAILS</label>}>
                            <EngTextEditor instEng={getInstEng} value={instEng} id={params.name + params.lab_number + params.task_number + params.step_number + 'eng'} />
                        </Form.Item>
                        <Form.Item label={<label style={{ fontSize: "22px", fontWeight: "bold", paddingTop: '20px' }}>填寫任務步驟內容</label>}>
                            <ChiTextEditor instChi={getInstChi} value={instChi} id={params.name + params.lab_number + params.task_number + params.step_number + 'chi'} />
                        </Form.Item>
                    </div>
                    <Form.Item label={<label style={{ fontSize: "22px", fontWeight: "bold", paddingTop: '20px' }}>Code 代碼</label>} >
                        <CodeEditor code={getCode} value={code} id={stepID} />
                    </Form.Item>
                    <div>
                        <Form.Item label={<label style={{ fontSize: "22px", fontWeight: "bold", paddingTop: '20px' }}>Uploaded Image 已上載圖片</label>}>
                            <Image key={stepID} src={image} width={600} height='auto' />
                        </Form.Item>
                    </div>
                    <Form.Item label={<label style={{ fontSize: "22px", fontWeight: "bold", paddingTop: '10px' }}>Upload a New Image 上載步驟新圖片</label>}>
                        <p style={{ paddingLeft: '17px' }}>Please upload a single photo with max width of 1200 pixels. Photos exceeding the limit will be compressed to width of 1200 pixels.</p>
                        <p style={{ paddingLeft: '17px' }}>請上載闊度最多為 1200 像素 的一張相片，超過限制的相片會被壓縮至1200 像素闊度。</p>
                        <input type="file" ref={fileInput} accept='image/*' onChange={(e) => { setDisplayImage(URL.createObjectURL(e.target.files[0])); handleUploadImage(); }} multiple />
                        <Image src={displayImage} width={600} height='auto' />
                    </Form.Item>
                    <div className='center'>
                        <button className="btn btn-save" style={{ width: "750px" }}
                            onClick={(event) => {
                                event.preventDefault();
                                var data = new FormData();
                                data.append('instruction_chi', instChi);
                                data.append('instruction_eng', instEng);
                                data.append('code_snippet', code);

                                axios.patch(globalVar.serverlocation + "/api/admin/steps/" + stepID + "/", data, {
                                    headers: {
                                        'Authorization': Cookies.get('access_token'),
                                    }
                                })
                                    .then(res => {
                                        toast.success('Steps info saved! 步驟資料已儲存！', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                                        setDisplayImage(null);
                                        getData({ name: globalVar.courseData.name });
                                        var uploadedImage = document.querySelector('input[type="file"]');
                                        if (uploadedImage.files.length > 0) {
                                            uploadedImage.value = null;
                                        }
                                    })
                                    .catch(err => {
                                        toast.error('Error!', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, draggable: false, progress: undefined, });
                                    })
                            }}>SAVE 儲存</button>
                    </div>
                </StyledForm>
            </div>
            {/* <ToastContainer position="top-center" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnHover={false} /> */}
        </div>
    );

}

export default StepEditor;
