import React from 'react'
import 'quill/dist/quill.snow.css'
import ReactQuill from 'react-quill'

/* How to use the rich text viewer 
1. npm install react-quill 
2. css:
    .ql-editor {
        font-size: 18px;
        color: inherit;
      }
    
    .ql-container {
        border: none !important;
    }
*/


export const EngTextViewer = (props) => {
    var modules = {
        toolbar: false,
    };

    var formats = [
        'bold', 'italic', 'underline', 'strike', 'blockquote',
        'color', 'background',
        'list', 'bullet',
        'align',
    ];

    const handleContentChange = (content) => {
        // console.log(content);
        props.instEng(content);
    }

    return (
        <div style={{ display: 'grid', justifyContent: 'center' }}>
            <ReactQuill
                key={props.id}
                theme="snow"
                modules={modules}
                // onChange={handleContentChange}
                value={props.engValue}
                style={{ height: "500px" }}
                readOnly={true}
            >
            </ReactQuill>
        </div>
    )
}
