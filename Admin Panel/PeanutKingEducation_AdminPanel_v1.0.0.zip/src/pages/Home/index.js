
/* This React component renders the homepage of admin panel. */

import React, { useState } from 'react';
import { useHref, useNavigate } from 'react-router-dom';
import "../../global/style.css"
import { Button } from 'antd';
import '../../global/media/materials.png';
import { FullContainer } from '../../global/FullContainer';
import { TopBar } from '../../global/TopBar';
import Nav from 'react-bootstrap/Nav';
import materiallogo from '../../global/media/materials.png';
import courselogo from '../../global/media/courses.png';
import managelogo from '../../global/media/admin.png';
import keylogo from '../../global/media/key.png';
import Modal from 'react-modal';
import FindKey from '../Management/components/findKey';

const Home = () => {
    const navigate = useNavigate();
    const [searchQuery, setSearchQuery] = useState("");     // search query for searching redemption keys

    // pop-up window for searching redemption keys
    const [modalIsOpen, setModalIsOpen] = useState(false);
    const handleOpenModal = () => {
        //console.log("clicked");
        setModalIsOpen(true);
        document.body.style.overflow = 'hidden';
    }

    const handleCloseModal = () => {
        setModalIsOpen(false);
        document.body.style.overflow = 'auto';
    }

    return (
        <div className='center'>
            <h1>ADMIN CONSOLE 管理員頁面 </h1>
            <div className='container'>
                <div className='card' onClick={() => navigate("/materials/edit")}> {/* navigate to materials page */}
                    <div className='img-box'>
                        <img src={materiallogo}></img>
                    </div>
                    <div className='content'>
                        <h2>Materials 材料</h2>
                        <p>ADD NEW MATERIALS 新增材料</p>
                        <p>EDIT MATERIALS 修改材料</p>
                    </div>
                </div>

                <div className='card' onClick={() => navigate("/courses/list")}> {/* navigate to courses page */}
                    <div className='img-box'>
                        <img src={courselogo}></img>
                    </div>
                    <div className='content'>
                        <h2>Courses 課程</h2>
                        <p>ADD NEW COURSES 新增課程</p>
                        <p>EDIT COURSES DETAILS 修改課程資料</p>
                        <p>DELETE COURSES 刪除課程</p>
                    </div>
                </div>

                <div className='card' onClick={() => navigate("/manage")}> {/* navigate to admin settings page */}
                    <div className='img-box'>
                        <img src={managelogo}></img>
                    </div>
                    <div className='content'>
                        <h2>Admin Setting 管理員設定</h2>
                        <p>MANAGE USER PERMISSIONS 管理用戶權限</p>
                        <p>MANAGE ALL ACCOUNTS 管理所有賬戶</p>
                        <p>MANAGE REDEMPTION KEYS 管理課程兌換代碼</p>
                        <p>MANAGE USER-TO-KEY PAIRS 管理用戶與對應兌換代碼</p>
                    </div>
                </div>

                <div className='card' onClick={handleOpenModal}>        {/* open pop-up window for searching redemption keys */}
                    <div className='img-box'>
                        <img src={keylogo}></img>
                    </div>
                    <div className='content'>
                        <h2>Search Key 搜尋代碼</h2>
                        <p>SEARCH USER WITH KEY 搜尋代碼對應用戶</p>
                    </div>
                </div>
                <div className='Home'>
                    <Modal isOpen={modalIsOpen} className='key-modal' overlayClassName='key-modal-overlay'>
                        <div className='key-modal__header'>
                            <Button type='primary float-end' danger style={{ width: "12%", height: "40px", borderRadius: "0", border: "2px solid black", backgroundColor: "#c71e1e" }} onClick={() => handleCloseModal()}>CLOSE 關閉</Button>
                        </div>
                        <div className='key-modal__content'>
                            <h3 style={{ textAlign: "center" }}>Enter a redemption key to search for user-to-key pairs</h3>
                            <h3 style={{ textAlign: "center" }}>輸入一個兌換代碼以搜尋代碼對應的用戶</h3>
                            <div className='center'>
                                <h6>Copy and paste a redemption key and check its users</h6>
                                <h6>複製及貼上一個兌換代碼以檢查其對應的用戶</h6>
                                <input style={{ border: "2px bold solid black", height: "70px", background: "transparent", borderRadius: "15px", padding: "20px" }}
                                    type="text" value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)} placeholder='REDEMPTION KEY 代碼'></input>
                            </div>
                            <FindKey rkey={searchQuery} />
                        </div>
                    </Modal>
                </div>
            </div>
        </div>
    );
}

export default Home;