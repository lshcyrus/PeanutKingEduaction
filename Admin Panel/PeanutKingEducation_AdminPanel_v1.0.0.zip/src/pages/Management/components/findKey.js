/*
    This component is used to find the corresponding key inputted by users in the database and display the key information with the user information
*/

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Cookies from 'js-cookie';
import globalVar from '../../../global/globalVar';

const FindKey = (props) => {
    const [keyData, setKeyData] = useState([]);

    // this function is to split the date into a readable format
    const splitDate = (date) => { return date.split('T')[0] + ' | ' + date.split('T')[1].split('.')[0].split('+')[0] }

    useEffect(() => {
        axios.get(globalVar.serverlocation + "/api/admin/redemptionpairs/", {
            headers: {
                'Authorization': Cookies.get('access_token')
            }
        })
            .then(res => {
                setKeyData(res.data);
                console.log(typeof keyData);
                console.log(keyData);
            })
            .catch(error => {
                console.log(error);
            })
    });


    const filteredData = keyData.filter((keys) => keys.key.key === props.rkey);

    if (filteredData.length == 0) {
        return (
            <div style={{ color: "GrayText" }} className='center'>
                <h5>Key {props.rkey} does not exist or have not yet been redeemed</h5>
                <h5>代碼 {props.rkey} 並不存在或這個兌換代碼並未被任何用戶兌換</h5>
                <h6>Check if there are any additional 'space' character before or after the key</h6>
                <h6>Redemption key should be in the following format</h6>
                <h6>兌換代碼格式</h6>
                <h5 style={{ fontStyle: "italic" }}>0JAP8FT636</h5>
            </div>
        );
    }
    else return (
        <div className='center'>
            <table className='key-table'>
                <tbody>
                    {filteredData.map((keys) =>
                        <tr key={keys.id}>
                            <div>
                                <th>Redemption Key 兌換代碼</th> <td style={{ display: "flex", justifyContent: "center", alignContent: "center" }}>{keys.key.key}</td>
                            </div>
                            <th></th>
                            <div>
                                <th style={{ display: "inline" }}>User 用戶</th> <td style={{ display: "inline" }}>{keys.user.name_eng} ({keys.user.username})</td>
                            </div>
                            <div>
                                <th style={{ display: "inline" }}>Course 課程</th> <td style={{ display: "inline" }}>{keys.key.course.name}</td>
                            </div>
                            <div>
                                <th style={{ display: "inline" }}>Date Created 創建日期</th> <td style={{ display: "inline" }}>{splitDate(keys.key.date_created)}</td>
                            </div>
                            <div>
                                <th style={{ display: "inline" }}>Expiry Date 失效日期</th> <td style={{ display: "inline" }}>{splitDate(keys.key.date_expired)}</td>
                            </div>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
}

export default FindKey;
