import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import Cookies from 'js-cookie'
import "../../../global/style.css";
import globalVar from "../../../global/globalVar";
import Table from 'react-bootstrap/Table';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export function ManageRole() {
    const [error, setError] = useState(null);
    const [isLoaded, setIsLoaded] = useState(false);
    const [roleList, setRoleList] = useState([]);
    const [items, setItems] = useState([]);
    const [myInfo, setMyInfo] = useState([]);

    function popToast(status, message) {
        if (status === "success") {
            return toast.success(message, {
                position: "top-center",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: false,
                progress: undefined,
            });
        }

        return toast.error(`Error: ${message}`, {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            progress: undefined,
        });

    }

    function handleChangeRole(user, role) {
        axios.post(`${globalVar.serverlocation}/api/admin/update_usergroup/`, { user: user.id, groups: role }, {
            headers: {
                'Authorization': Cookies.get('access_token')
            }
        })
            .then(res => {
                user.groups[0].name = role;
                setItems(items.slice(0, items.length + 1));
                popToast("success", "Changes updated! 變更已更新！");
            })
            .catch(error => {
                setError(error);
            })
    }

    useEffect(() => {
        let endpoints = [
            "/api/admin/groups_list/",
            "/api/admin/users/",
            "/api/get_userinfo/"
        ];

        axios.all(endpoints.map((endpoint) =>
            axios.get(`${globalVar.serverlocation}${endpoint}`, {
                headers: {
                    'Authorization': Cookies.get('access_token')
                }
            })
        ))
            .then(
                result => {
                    setIsLoaded(true);
                    setRoleList(result[0].data.map(role => role.name));
                    console.log(result[1].data)
                    setItems(result[1].data);
                    setMyInfo(result[2].data);
                }
            )
            .catch(error => {
                setIsLoaded(true);
                setError(error);
            });

    }, [])

    if (error) {
        popToast("error", error.message);
        return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
        return <div>Loading...</div>;
    } else {
        var pageTitle = "Manage User Permissions 管理用戶權限";
        var colName = ["#", "EMAIL 電郵", "ENGLISH NAME", "中文姓名", "ACCOUNT STATUS 賬戶狀態", "PERMISSIONS 權限"];

        var tableHead = colName.map((col, index) => <th scope="col" key={`col_${index}`}>{col}</th>);
        var filteredItems = items.filter(item => item.groups.length);

        var tableBody = filteredItems.map((user, index) => (
            <tr key={`user_${user.id}`}>
                <th scope="row">{index + 1}</th>
                <td>{user.email}</td>
                <td>{user.name_eng}</td>
                <td>{user.name_chi}</td>
                <td>{user.is_active ? "Active" : "Inactive"}</td>
                <td>{
                    (user.id === myInfo.id) ?
                        (<div style={{ margin: "0.5em" }}>ADMIN 管理員</div>) :
                        (
                            <div className="dropdown">
                                <button className="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                    {(user.groups[0].name === "Tutors") ? "ADMIN 管理員" : "STUDENT 學生"}
                                </button>
                                <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton1"> {
                                    roleList.map(thisRole => (
                                        <li key={`role_option_${thisRole}`}>
                                            <a
                                                className={`dropdown-item ${(thisRole === user.groups[0].name) ? "disabled" : ""}`}
                                                onClick={() => handleChangeRole(user, thisRole)}
                                            >
                                                {(thisRole === "Tutors") ? "ADMIN 管理員" : "STUDENT 學生"}
                                            </a>
                                        </li>
                                    ))
                                }
                                </ul>
                            </div>
                        )
                }
                </td>
            </tr>
        ))

        return (
            <div>
                <ToastContainer
                    position="top-center"
                    autoClose={5000}
                    hideProgressBar={false}
                    newestOnTop={false}
                    closeOnClick rtl={false}
                    pauseOnFocusLoss
                    draggable
                    pauseOnHover
                />
                <h4 className="mb-3">{pageTitle}</h4>
                <Table striped hover responsive className="table-light caption-top align-middle text-center">
                    <caption>
                        You may assign permissions to all users. 你可以指派不同權限予所有用戶。<br />
                        Admins have full access to Admin Console. 管理員身份可存取整個管理員界面。<br />
                        Assign ADMIN to tutors ONLY. No students are allowed. 只可指派系統管理員予導師，不可指派予學生。
                    </caption>
                    <thead><tr>{tableHead}</tr></thead>
                    <tbody>{tableBody}</tbody>
                </Table>
            </div>
        );
    }
}