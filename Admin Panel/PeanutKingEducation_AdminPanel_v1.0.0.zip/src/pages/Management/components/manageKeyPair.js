import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import Cookies from 'js-cookie'
import "../../../global/style.css";
import globalVar from "../../../global/globalVar";

export function ManageKeyPair() {
    const [error, setError] = useState(null);
    const [isLoaded, setIsLoaded] = useState(false);
    const [items, setItems] = useState([]);

    useEffect(() => {
        axios.get(globalVar.serverlocation + "/api/admin/redemptionpairs/", {
            headers: {
                'Authorization': Cookies.get('access_token')
            }
        })
            .then(result => {
                setIsLoaded(true);
                setItems(result.data);
            })
            .catch(error => {
                setIsLoaded(true);
                setError(error);
            })
    }, [])

    if (error) {
        return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
        return <div>Loading...</div>;
    } else {
        var pageTitle = "Manage User-to-Key Pairs 管理用戶兌換代碼";
        var tableCaption = "Redemption Key Pairs";
        var colName = ["#", "USERNAME 用戶名稱", "EMAIL 電郵", "COURSE 課程", "KEY 代碼", "STATUS 狀態"];

        var tableHead = colName.map((col, index) => <th scope="col" key={"col_" + index}>{col}</th>);

        var tableBody = items.map((keyPair, index) => (
            <tr key={"key_pair_" + keyPair.id}>
                <th scope="row">{index + 1}</th>
                <td>{keyPair.user.username}</td>
                <td>{keyPair.user.email}</td>
                <td>{keyPair.key.course.name}</td>
                <td>{keyPair.key.key}</td>
                <td>{(Date.parse(keyPair.key.date_expired) > Date.now() && keyPair.key.active) ? "Active" : "Deactivated"}</td>
            </tr>
        ))

        return (
            <div>
                <h4 className="mb-3">{pageTitle}</h4>
                <div className="table-responsive">
                    <table className="table table-light table-striped table-hover caption-top align-middle text-center">
                        <caption>{tableCaption}</caption>
                        <thead><tr>{tableHead}</tr></thead>
                        <tbody>{tableBody}</tbody>
                    </table>
                </div>
            </div>
        );
    }
}