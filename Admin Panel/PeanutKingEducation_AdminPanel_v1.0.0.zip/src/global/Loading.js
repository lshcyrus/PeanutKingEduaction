/* 
    Returns a loading animation when called.
    Made by: Cyrus 
*/

const Loading = () => {
    return(
        <div className="center">
            <div className="loader"></div>
        </div>
    )
}
export default Loading;