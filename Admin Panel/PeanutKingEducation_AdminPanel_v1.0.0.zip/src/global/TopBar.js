import React from "react";
import axios from "axios";
import Cookies from "js-cookie";

import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Button from 'react-bootstrap/Button';
import 'bootstrap/dist/css/bootstrap.min.css';

import './style.css'
import './TopBar.css'
import globalVar from "./globalVar";
import logo from "./media/logo.png"
import { EditUserInfo } from "../pages/Management/components/editUserInfo"
import NavbarCollapse from "react-bootstrap/esm/NavbarCollapse";
import { useNavigate } from "react-router-dom";

export class TopBar extends React.Component {
    constructor(props) {
        super(props);
        this.state = { switchAdminPanel: props.switchAdminPanel, editUserShow: false };
    }

    handleClickUser() {
        this.setState({ editUserShow: true });
    }

    handleLogout() {
        var data = new FormData();
        data.append("client_id", "UQNAJUVzANBZd9QQ9CvrZ1Rq582S2frV2vqoxU07");
        axios.post(globalVar.serverlocation + "/auth/invalidate-sessions", data, {
            headers: {
                'Authorization': Cookies.get('access_token'),
                "client_id": "UQNAJUVzANBZd9QQ9CvrZ1Rq582S2frV2vqoxU07",
            },
        })
            .then((response) => {
                Cookies.remove("access_token");
                window.location = globalVar.serverlocation + "/";
            })
            .catch((err) => {
                console.log(err);
            });
    }

    navToHome() {
        const navigate = useNavigate();
        navigate('/')
    }
    render() {
        return (
            <Navbar id="navbar" className="text-pkWhite bg-pkDarkBlue2" expand="md" fixed="top">
                {this.state.editUserShow && <EditUserInfo handleClose={() => this.setState({ editUserShow: false })} />}
                <Container fluid>
                    <Navbar.Brand href="../dashboard/index.html" id="logo" className="ms-3"><img src={logo} alt="company logo" width="45" height="55" /></Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="me-auto mb-0 mb-md-0">
                            <Nav.Link href="../dashboard/index.html">STUDENT CONSOLE 學生頁面</Nav.Link>
                            <Nav.Link href="index.html">ADMIN CONSOLE 管理員頁面</Nav.Link>
                            {/* <Nav.Link href="https://peanutkingeducation.com/admin" target="_blank">DJANGO BACKEND 後端伺服器</Nav.Link> */}
                            {/* <Nav.Link href="#" onClick={() => this.state.switchAdminPanel(true)}>ADMIN SETTING 管理員設定</Nav.Link> */}
                            {/* <NavDropdown title="ADMIN CONSOLE 管理員界面" id="basic-nav-dropdown">
                                <NavDropdown.Item href="#" onClick={() => this.state.switchAdminPanel(false)}>EDIT COURSES 編輯課程</NavDropdown.Item>
                                <NavDropdown.Item href="#" onClick={() => this.state.switchAdminPanel(true)}>ADMIN SETTING 管理員設定</NavDropdown.Item>
                            </NavDropdown> */}
                        </Nav>
                        <Nav className="me-3">
                            <Nav.Link href="#" onClick={() => this.handleClickUser()}>&nbsp;&nbsp;{`Hello, ${globalVar.username}!`}&nbsp;&nbsp;</Nav.Link>
                            <Button variant="outline-success" onClick={() => this.handleLogout()}>SIGN OUT 登出</Button>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
        );
    }
}