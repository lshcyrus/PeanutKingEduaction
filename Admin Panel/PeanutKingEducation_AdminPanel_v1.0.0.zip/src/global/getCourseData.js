import axios from 'axios';
import Cookies from 'js-cookie'

import globalVar from './globalVar';

export function getCourseData(props){
    //get course data
    // console.log("getting course data", props.name);
    axios.get(globalVar.serverlocation + "/api/courses/" + (props.name==null?globalVar.courseList[0].name:props.name), {
        headers: {
            'Authorization': Cookies.get('access_token'),
        }
    }).then(function (response) {
        //console.log(response.data);
        globalVar.courseData = response.data;
        // self.setState({gotData: 1});
        
        // console.log(1111111121)
        // console.log(globalVar.courseData);
        if(props.self != null)//try not to use global variable
            props.self.setState({gotData: true});
        else
            globalVar.atFullContainer.setState({gotData: true});
    }).catch(function (error) {
        // window.alert('error');
        console.log(error)
    })
}