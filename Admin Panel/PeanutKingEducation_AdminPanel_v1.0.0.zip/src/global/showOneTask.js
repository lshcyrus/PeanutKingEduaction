import { useState } from "react";
import React, { Component } from "react";
import Collapsible from 'react-collapsible';
import Switch from "react-switch";
import globalVar from "./globalVar";
import { ShowOneStep } from "./showOneStep";

function submit() {
    window.alert("not implemented");
}

export function ShowOneTask(props) {

    //     "submission_requirements_chi":"aaa",
    //     "submission_requirements_eng":"Bbb",
    //     "steps":[]

    const [engTaskTitle, setEngTaskTitle] = useState(props.task.title_eng);
    const [chiTaskTitle, setChiTaskTitle] = useState(props.task.title_chi);
    const [check, setCheck] = useState(props.task.submission_required);
    //for adding a new step
    const [insEng, setInsEng] = useState("");
    const [insChi, setInsChi] = useState("");

    var stepList = props.task.steps.map((item) => (item.task_number!=999? <ShowOneStep step={item} /> : <div></div>))

    return (
        <div>
            <h4>Task {props.task.task_number}:</h4>
            <div className="row">
                <div className="col-6"><a>Title:</a><input className="EditorInput form-control br-0" type="text" id="engTaskTitle" value={engTaskTitle} onChange={(e) => { setEngTaskTitle(e.target.value) }}></input></div>
                <div className="col-6"><a>名稱：</a><input className="EditorInput form-control br-0" type="text" id="chiTaskTitle" value={chiTaskTitle} onChange={(e) => { setChiTaskTitle(e.target.value) }}></input></div>
            </div>
            <button className="btn btn-save" onClick={() => { console.log(document.getElementById("engTaskTitle").value, document.getElementById("chiTaskTitle").value) }}>Save</button>

            <h1 className="seperateLine"/>
        </div>
    );
}