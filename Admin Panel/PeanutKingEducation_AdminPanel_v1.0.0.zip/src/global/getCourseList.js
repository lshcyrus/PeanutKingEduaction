import axios from 'axios';
import Cookies from 'js-cookie'
import { getCourseData } from './getCourseData';
import globalVar from './globalVar';

export function getCourseList(props){
    axios.get(globalVar.serverlocation + "/api/admin/courses/", {
        headers: {
            'Authorization': Cookies.get('access_token'),
        }
    }).then(function (response) {
        //console.log(response.data);
        globalVar.courseList = response.data;
        //self.setState({gotData: 1});
        // console.log(111111111)
        // console.log(globalVar.courseList);
        // console.log(props.self );
        getCourseData();
    }).catch(function (error) {
        // window.alert('error');
        console.log(error)
    })
}