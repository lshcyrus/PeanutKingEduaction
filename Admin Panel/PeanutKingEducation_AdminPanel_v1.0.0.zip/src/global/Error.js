import React from 'react';
import { Link, useNavigate } from 'react-router-dom';


const Error = () => {

    const navigate = useNavigate();

    return (
        <div>
            <h1>404 Not Found</h1>
            <Link to="/" onClick={() => navigate('/')}>Go Back To Home</Link>
        </div>
    );
}

export default Error;
