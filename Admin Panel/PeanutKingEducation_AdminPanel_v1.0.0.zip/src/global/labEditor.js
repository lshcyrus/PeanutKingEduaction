import React from "react";
import Collapsible from 'react-collapsible';    // React component for creating collapsible element 
import globalVar from "./globalVar"
import { ToastContainer, toast } from 'react-toastify'; // React component for displaying toast notifications (small messages appear on the screen to nofity users about an action or event)
/* ToastContainer: a component wraps the toast notifications inside application and provides a container for displaying the noti.
   toast         : a function that displaying a toast notification. This function is called with message and options for toast noti. */
import axios from "axios";
import Cookies from "js-cookie";
import 'react-toastify/dist/ReactToastify.css';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';

import { ShowOneTask } from "./showOneTask";
import { getCourseData } from "./getCourseData";

export class LabEditor extends React.Component {
    constructor(props) {
        super(props);
        var currLab = globalVar.courseData.labs[globalVar.labID - 1];
        this.state = ({
            engLabName: currLab.lab_title_eng,
            chiLabName: currLab.lab_title_chi,
            engLearnOutcome: currLab.learning_outcome_eng,
            chiLearnOutcome: currLab.learning_outcome_chi,
            pre: globalVar.labID,
            show: false,

            updateList: 1,
            materialList: null,
            materialList4Backend: null,

            error: null,
            isLoaded: false,

            appRoot: props.appRoot,
        });
    }

    handleClose = () => this.setState({ show: false });
    handleShow = () => this.setState({ show: true });

    componentDidMount() {
        this.getMaterialList();
    }

    getMaterialList() {
        axios.get(`${globalVar.serverlocation}/api/admin/get_materialrequirements/${globalVar.courseData.labs[globalVar.labID - 1].id}/`, {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        })
            .then(res => {
                // console.log(res.data);
                this.setState({ isLoaded: true, materialList: res.data });
            })
            .catch(err => {
                console.log(err);
                this.setState({
                    isLoaded: true,
                    err
                });
            })
    }

    updateMaterialList() {
        axios.post(globalVar.serverlocation + "/api/admin/amend_materialrequirements/" + globalVar.courseData.labs[globalVar.labID - 1].id + "/", this.state.materialList4Backend, {
            headers: {
                'Authorization': Cookies.get('access_token'),
            }
        })
            .then(res => {
                // console.log(res.data);
                toast.success('Saved and updated! 已儲存及更新！', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, progress: undefined, });
                this.getMaterialList();
            })
            .catch(err => console.log(err));
    }

    updateField() {
        if (this.state.pre != globalVar.labID) {
            console.log("updating");
            var currLab = globalVar.courseData.labs[globalVar.labID - 1];
            this.getMaterialList();
            this.setState({
                pre: globalVar.labID,
                engLabName: currLab.lab_title_eng,
                chiLabName: currLab.lab_title_chi,
                engLearnOutcome: currLab.learning_outcome_eng,
                chiLearnOutcome: currLab.learning_outcome_chi,
            });
        }
    }

    
    showMaterial(props) {
        // console.log(props);
        var materialList = props;
        this.state.materialList4Backend = materialList.map(item => ({ "material": item.id, "required": item.required }));

        return (materialList.map((item, index) =>
            //one row of in list of choosing material
            <div className="row materialListBlock" key={`material_${index}`}>
                <input type="checkbox" id={"0000" + index.toString()} checked={item.required}
                    onClick={() => {
                        // console.log(materialList[parseInt("0000" + index.toString())]);
                        item.required = !item.required;
                        this.state.materialList4Backend[parseInt("0000" + index.toString())].required = !this.state.materialList4Backend[parseInt("0000" + index.toString())].required;
                        this.setState({ updateList: 1 })
                    }}
                    style={{ width: "20px" }}>

                </input>
                <div className="col-2">
                    <img src={item.material_img} />
                </div>
                <div className="col-5">
                    <p>{`Material Name(English):  ${item.material_name_eng}`}</p>
                    <p>{`材料名稱（中文）： ${item.material_name_chi}`}</p>
                </div>
            </div>
        ))
    }

    // INSIDE render(), return the content of the webpage (rendering the webpage after user clicking the redirect url)
    render() {
        const { error, isLoaded, materialList } = this.state;
        if (error) {
            return <div>Error: {error.message}</div>;
        } else if (!isLoaded) {
            return <div>Loading...</div>;
        } else {
            this.updateField();

            // if (materialList) console.log("mlist ", materialList);


            return (
                <div className="my-3 bg-body shadow-sm ">
                    <div className="bg-pkDarkBlue2 row m-0">
                        <h3 className=" p-3 col-8" style={{ color: "white" }}>Choose Materials For this Lab 為此實驗選擇材料</h3>
                        <div className="col-4">
                            <button onClick={() => { this.handleShow(); }} className="btn btn-delete float-end m-3">DELETE THIS LAB 刪除整個實驗頁面</button>
                        </div>
                    </div>

                    <div className="p-3">
                        {/* <div className="row mb-3 stepContentText">
                            <div className="col-6"><a>Lab Title (English):</a><input className="EditorInput form-control br-0" type="text" id="labName_eng" value={this.state.engLabName} onChange={(e) => { this.setState({ engLabName: e.target.value }) }}></input></div>
                            <div className="col-6"><a>實驗名稱（中文）:</a><input className="EditorInput form-control br-0" type="text" id="labName_chi" value={this.state.chiLabName} onChange={(e) => { this.setState({ chiLabName: e.target.value }) }}></input></div>
                        </div>

                        <div className="row mb-3 stepContentText">
                            <div className="col-6">
                                <a>Learning Outcome (English):</a>
                                <input
                                    className="EditorInput form-control br-0"
                                    type="text"
                                    id="learnOutcome_eng"
                                    value={this.state.engLearnOutcome}
                                    onChange={(e) => { this.setState({ engLearnOutcome: e.target.value }) }}
                                ></input>
                            </div>
                            <div className="col-6"><a>學習目標（中文）：</a><input className="EditorInput form-control br-0" type="text" id="learnOutcome_chi" value={this.state.chiLearnOutcome} onChange={(e) => { this.setState({ chiLearnOutcome: e.target.value }) }}></input></div>
                        </div> */}

                        <div className="row" style={{ paddingBottom: '20px'}}>
                            <h5>Please do not refresh this page. 請勿刷新此頁面。</h5>
                            <div className="col float-end">
                                <button className="btn btn-save float-end"
                                    onClick={() => {
                                        this.updateMaterialList();
                                    }}>SAVE 儲存</button>
                            </div>
                        </div>

                        {this.showMaterial(materialList)}
                        <ToastContainer position="top-center" autoClose={5000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnFocusLoss draggable pauseOnHover />

                    </div>
                    <Modal show={this.state.show} onHide={() => this.handleClose()}>
                        <Modal.Header closeButton>
                            <Modal.Title>Confirm Message 確認信息</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>Do you want to delete this lab? It cannot be recovered. 你想刪除這個實驗嗎？動作不可復原。</Modal.Body>
                        <Modal.Footer>
                            <Button variant="save" onClick={() => { this.handleClose() }}>CANCEL 取消</Button>
                            <Button variant="delete" onClick={() => { this.handleClose(); this.deleteLab(); }}>CONFIRM 確認</Button>
                        </Modal.Footer>
                    </Modal>

                </div>
            );
        }
    }
}
