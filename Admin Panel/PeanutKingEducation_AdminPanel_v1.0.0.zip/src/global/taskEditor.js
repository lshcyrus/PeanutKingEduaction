import { useState, useEffect } from "react";
import Switch from "react-switch";
import { ToastContainer, toast } from 'react-toastify';
import { Accordion } from "react-bootstrap";
import Cookies from "js-cookie";
import axios from "axios";
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import globalVar from "./globalVar";
import { ShowOneStep } from "./showOneStep";
import { getCourseData } from "./getCourseData";
import { useParams, useNavigate } from "react-router-dom"
import youtube from "../global/media/utube.png"

export function deleteTask(props) {

    // console.log("djdjdjd ",globalVar.courseData.labs[globalVar.labID])
    axios.delete(globalVar.serverlocation + "/api/admin/tasks/" + globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.taskID - 1].id + '/', {
        headers: {
            'Authorization': Cookies.get('access_token'),
        }
    })
        .then(res => {
            toast.success('Deleted! Please check the updated task list.', { position: "top-center", autoClose: 3000, closeOnClick: true, pauseOnHover: false, progress: undefined, });
            axios.get(globalVar.serverlocation + "/api/admin/courses/", {
                headers: {
                    'Authorization': Cookies.get('access_token'),
                }
            })
                .then(function (response) {
                    //console.log(response.data);
                    // globalVar.courseList = response.data;
                    //self.setState({gotData: 1});
                    // console.log(111111111)
                    // console.log(globalVar.courseList);
                    getCourseData({ name: globalVar.courseData.name });
                    //props.jumpToLab();
                
                }).catch(function (error) {
                    window.alert('error task editor');
                    console.log(error);
                })
        })
        .catch(err => console.log(err))
}

export function TaskEditor(props) {
    // console.log("Called Task Editor")
    // console.log(props.task.title_eng)
    console.log(props);
    console.log(props.task);

    const [taskID, setTaskID] = useState(props.task.id);
    const [engTaskTitle, setEngTaskTitle] = useState(props.task.title_eng);
    const [chiTaskTitle, setChiTaskTitle] = useState(props.task.title_chi);
    const [check, setCheck] = useState(props.task.submission_required);
    const [engBrief, setEngBrief] = useState(props.task.brief_eng);
    const [chiBrief, setChiBrief] = useState(props.task.brief_chi);
    const [file, setFile] = useState(props.task.video);
    const [submitChi, setSubmitChi] = useState(props.task.submission_requirements_eng);
    const [submitEng, setSubmitEng] = useState(props.task.submission_requirements_eng);
    
    //for adding a new step
    const [insEng, setInsEng] = useState("");
    const [insChi, setInsChi] = useState("");
    const [img, setImg] = useState(null);
    const [show, setShow] = useState(false);
    const [width, setWidth] = useState(window.innerWidth);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    useEffect(() => {
        // When title or name changed will render
        setEngTaskTitle(props.task.title_eng);
        setChiTaskTitle(props.task.title_chi);
        setCheck(props.task.submission_required);
        setTaskID(props.task.id);
        setCheck(props.task.submission_required);
        setEngBrief(props.task.brief_eng);
        setChiBrief(props.task.brief_chi);
    }, [taskID, props.task.id])
    window.addEventListener('resize', () => { setWidth(window.innerWidth) });
    // console.log(taskID)

    if (props.task == null)
        return (<div></div>);
    var stepCount = 0;
    var stepList = props.task.steps.map((item) => (item.task_number != 999 ? <ShowOneStep step={item} stepNumber={++stepCount} /> : <div></div>))

    if (props.task == null) { return (<div></div>) };
    return (
        <div className="my-3 bg-body shadow-sm ">
            <div className="bg-pkDarkBlue2 row m-0">
                <h4 className="p-3 col-8" style={{ color: "white" }}>{props.courseName} | Lab {props.labNumber < 10 ? '0' + props.labNumber : props.labNumber} | Task {props.task.task_number}</h4>
                <div className="col-4">
                    <button className="btn btn-delete float-end m-3" onClick={() => { handleShow() }}>DELETE THIS TASK 刪除整個任務</button>
                </div>
            </div>

            <div className="p-3 stepContentText">
                <div className="row">
                    <div className="col-lg-6 col-md-12"><a>Task Title (English):</a><input className="EditorInput form-control br-0" type="text" id="engTaskTitle" value={engTaskTitle} onChange={(e) => { setEngTaskTitle(e.target.value) }}></input></div>
                    <div className="col-lg-6 col-md-12"><a>任務名稱（中文）：</a><input className="EditorInput form-control br-0" type="text" id="chiTaskTitle" value={chiTaskTitle} onChange={(e) => { setChiTaskTitle(e.target.value) }}></input></div>
                    <div className="col-lg-6 col-md-12"><a>Task Introduction (English):</a>
                        <td class="field-description_eng">
                            <textarea name="form-0-description_chi" cols="40" rows="3" style={{ width: width * 5 / 12 - ((width > 810) ? 60 : -185) }} value={engBrief} id="engTaskBrief" onChange={e => { setEngBrief(e.target.value) }} className="vLargeTextField b-grey pk-textarea" required />
                        </td>
                    </div>
                    <div className="col-lg-6 col-md-12"><a>任務簡介（中文）：</a>
                        <td class="field-description_eng">
                            <textarea name="form-0-description_chi" cols="40" rows="3" style={{ width: width * 5 / 12 - ((width > 810) ? 60 : -185) }} value={chiBrief} id="chiTaskBrief" onChange={e => { setChiBrief(e.target.value) }} className="vLargeTextField b-grey pk-textarea" required />
                        </td>
                    </div>
                    {/* <div className="col-6"><a>Task Introduction (English):</a><input className="EditorInput form-control br-0" type="text" id="engTaskBrief" value={engBrief} onChange={(e) => { setEngBrief(e.target.value) }}></input></div> */}
                    {/* <div className="col-6"><a>任務簡介（中文）：</a><input className="EditorInput form-control br-0" type="text" id="chiTaskBrief" value={chiBrief} onChange={(e) => { setChiBrief(e.target.value) }}></input></div> */}
                </div>
                <br />
                <a>Video:</a>
                <br />
                {props.task.video == null ? <div></div> : <iframe style={{ width: '70%', height: '400px' }} src={props.task.video} controls></iframe>}
                <br />
                <label for="formFileMultiple" id="submitStatus" class="form-label">Upload a New Video. Need embedded youtube link. For example: https://www.youtube.com/embed/qvzCmV3_12c</label>
                <img src={youtube} style={{width:"465px", height:"65px"}}></img>
                <input className="form-control br-0" type="url" id="fileUpload" defaultValue={"https://www.youtube.com/embed/"} onChange={(e) => setFile(e.target.value)} multiple />
                <br />
                {/* value from switch is not saved not */}
                <a>Do students need to submit assignment? 同學是否需要遞交習作？</a>
                <br />
                <Switch onChange={(e) => { setCheck(e); props.task.submission_required = !props.task.submission_required }} checked={check} />
                {props.task.submission_required ?
                    <div className="b-pkDarkBlue row p-3 px-0 pt-0">
                        <div className="col"><a>Submission requirement:</a><input className="EditorInput form-control br-0 mt-2" type="text" value={submitEng} onChange={(e) => { setSubmitEng(e.target.value) }}></input></div>
                        <div className="col"><a className>提交要求：</a><input className="EditorInput form-control br-0 mt-2" type="text" value={submitChi} onChange={(e) => { setSubmitChi(e.target.value) }}></input></div>
                    </div>
                    : <div></div>}
                <div className="row mt-3">
                    <div className="col">
                        <button className="btn btn-save float-end" onClick={() => {
                            var data = new FormData();
                            data.append("video", file);
                            data.append("submission_required", check);
                            data.append("title_eng", engTaskTitle);
                            data.append("title_chi", chiTaskTitle);
                            data.append("brief_eng", engBrief);
                            data.append("brief_chi", chiBrief);
                            if (check) {
                                data.append("submission_requirements_eng", submitEng);
                                data.append("submission_requirements_chi", submitChi);
                            }
                            axios.patch(globalVar.serverlocation + "/api/admin/tasks/" + globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.taskID - 1].id + "/", data, {
                                headers: {
                                    'Authorization': Cookies.get('access_token')
                                }
                            }
                            )
                                .then(res => {
                                    toast.success('Saved and updated! 已儲存及更新!', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, progress: undefined });
                                    getCourseData({ name: globalVar.courseData.name })
                                })
                                .catch(err => {
                                    // console.log(err.request.response);
                                    var obj = JSON.parse(err.request.response);
                                    for (const item in obj)
                                        toast.error(`${item}: ${obj[item]}`, { position: "top-center", autoClose: 5000, hideProgressBar: false, closeOnClick: true, pauseOnHover: false, progress: undefined });
                                })

                        }}>
                            SAVE 儲存
                        </button>
                    </div>
                </div>

                <Accordion className="accordion-flush" defaultActiveKey={taskID}>
                    {stepList}
                </Accordion>

                <Accordion className="mt-3 accordion-flush" defaultActiveKey={"add" + taskID}>
                    <Accordion.Item eventKey={"addd" + taskID}>
                        <Accordion.Header>Add a New Step.</Accordion.Header>
                        <Accordion.Body>
                            <div className="row">
                                <div className="col-6">
                                    <a>Fill in step details here (English):</a>
                                    <td class="field-description_eng">
                                        <textarea name="form-0-description_chi" cols="40" rows="3" style={{ width: width * 5 / 12 - 80 }} value={insEng} id="engStep" onChange={e => { setInsEng(e.target.value) }} className="vLargeTextField b-grey pk-textarea" required />
                                    </td>
                                </div>
                                <div className="col-6">
                                    <a>在下欄填寫任務步驟內容（中文）:</a>
                                    <td class="field-description_eng me-3">
                                        <textarea name="form-0-description_chi" cols="40" rows="3" style={{ width: width * 5 / 12 - 80 }} value={insChi} id="chiStep" onChange={e => { setInsChi(e.target.value) }} className="vLargeTextField b-grey pk-textarea" required />
                                    </td>
                                </div>
                            </div>
                            <label for="formFileMultiple" id="submitStatus" class="form-label">Upload Image 上傳圖片 (Upload only 1 image, of suggested ratio 3:2. 只能上載一張圖片，建議尺寸比例為3:2。)</label>
                            <input class="form-control" type="file" id={"newStepImage" + '_' + globalVar.courseData.labs[globalVar.labID - 1].id + '_' + props.task.id} defaultValue={""} onChange={(e) => { setImg(e.target.files[0]) }} multiple />
                            {img != null ? <img src={URL.createObjectURL(img)} /> : <div></div>}
                            {/* <button onClick={() => {console.log("newStepImage"+props.labid+props.task.id)}}>aaaaa</button> */}
                            <button className="btn btn-save mt-3" onClick={() => {
                                // window.alert("aaaaaaaaaaaaaaaa")
                                var data = new FormData();

                                var newStepNum = -1;
                                if (globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.taskID - 1].steps.length == 0)
                                    newStepNum = 1;
                                else
                                    newStepNum = globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.taskID - 1].steps[globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.taskID - 1].steps.length - 1].step_number + 1;

                                data.append("step_number", newStepNum);
                                data.append("instruction_eng", insEng);
                                data.append("instruction_chi", insChi);
                                data.append("course", globalVar.courseData.id);
                                data.append("lab", globalVar.courseData.labs[globalVar.labID - 1].id);
                                data.append("task", globalVar.courseData.labs[globalVar.labID - 1].tasks[globalVar.taskID - 1].id);
                                if (img) data.append("image", img);
                                
                                axios.post(globalVar.serverlocation + "/api/admin/steps/", data, {
                                    headers: {
                                        'Authorization': Cookies.get('access_token'),
                                    }
                                }).then(res => {
                                    setInsEng("");
                                    setInsChi("");
                                    setImg(null);
                                    document.getElementById("newStepImage" + '_' + globalVar.courseData.labs[globalVar.labID - 1].id + '_' + props.task.id).value = "";
                                    toast.success('Saved and updated! 已儲存及更新!', { position: "top-center", autoClose: 3000, hideProgressBar: false, closeOnClick: true, progress: undefined });
                                    getCourseData({ name: globalVar.courseData.name });
                                }).catch(err => { toast.error('Unknown error!', { position: "top-center", autoClose: 5000, hideProgressBar: false, closeOnClick: true, progress: undefined }); console.log(err) })

                            }}>SUBMIT 上載內容</button>
                        </Accordion.Body>
                    </Accordion.Item>
                </Accordion>

                {/* <br></br> */}
                <div className="mt-1">
                    <h1 className="seperateLine" />
                </div>

                <ToastContainer position="top-center" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnHover={false} />
            </div>
            {/* {confirmMessage({show:show,handleClose: handleClose(),givenFunction: deleteTask({jumpToLab:() => props.jumpToEditLab()})})} */}
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Message 確認信息</Modal.Title>
                </Modal.Header>
                <Modal.Body>Do you want to delete this task? It cannot be recovered. 你想刪除這個任務嗎？動作不可復原。</Modal.Body>
                <Modal.Footer>
                    <Button variant="save" onClick={handleClose}>
                        CANCEL 取消
                    </Button>
                    <Button variant="delete" onClick={() => { handleClose(); deleteTask(); }}>
                        CONFIRM 確認
                    </Button>
                </Modal.Footer>
            </Modal>

        </div>
    );
}