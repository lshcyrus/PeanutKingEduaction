import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
// import { Collapse } from "bootstrap";

import globalVar from "./globalVar";
import "./style.css";
import { arabicToChinese } from "./arabicToChinese";
// import { LabEditor } from "./labEditor";
import { getCourseData } from "./getCourseData";

export class LabContainer extends React.Component {
  constructor(props) {
    //console.log("before showing sidebar");
    //console.log(globalVar.courseData);

    super(props);
    this.state = {
      sideBarTitle: globalVar.courseData.name,
      allLabs: globalVar.courseData.labs,
      onClick: props.onClick,
      jumpToEditCourse: props.jumpToEditCourse,
      jumpToEditLab: props.jumpToEditLab,
      jumpToEditTask: props.jumpToEditTask,
      jumpToAddTask: props.jumpToAddTask,
      jumpToAddLab: props.jumpToAddLab,
      jumpToAddCourse: props.jumpToAddCourse,
      jumpToAddMaterial: props.jumpToAddMaterial,
      jumpToEditMaterial: props.jumpToEditMaterial,
      activeTask: null,
      refresh: false,
      firstRender: false
    };
    //console.log(222);
    //console.log(this.state.sideBarTitle);
  }


  render() {
    this.state.allLabs = globalVar.courseData.labs;

    // console.log(123);
    // console.log(this.state.allLabs);
    var listS;///Lab
    var listXS;//Task
    var listXXS;

    var taskNumber = 0;
    var labNumber = 1;

    const str = "a";
    const labText = globalVar.language === "eng" ? "Lab " : "實驗";
    const taskText = globalVar.language === "eng" ? "Task " : "任務";

    // Lab List
    listS = this.state.allLabs.map((thisLab) => (
      <div key={thisLab.lab_number}>
        <div
          taskNumber={taskNumber = 0}
          data-bs-toggle={thisLab.lab_number < 999 ? "collapse" : ""}
          data-bs-target={"#" + str + thisLab.lab_number}
          aria-expanded="false"
          id={"LabHeadBar"+thisLab.lab_number}
          value={labNumber}
          // this.addAddTask({num:document.getElementById("LabHeadBar"+thisLab.lab_number).value}) 
          onClick={() => { (thisLab.lab_number < 999 ? console.log("") : this.state.jumpToAddLab()); }}
        >
          {
            thisLab.lab_number < 999 ?
              ("") :
              (
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" className="bi bi-plus-square before" viewBox="0 0 16 16" >
                  <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                </svg>
              )
          }
          {
            thisLab.lab_number < 999 ?
              (labText +
                // (thisLab.lab_number < 10 ? "0" : "") +
                // thisLab.lab_number +
                (thisLab.lab_number < 10 ? "0" : "") +
                thisLab.lab_number +
                " " + (globalVar.language === "eng"? thisLab.lab_title_eng: thisLab.lab_title_chi)): 
                (globalVar.language === "eng"? thisLab.lab_title_eng : thisLab.lab_title_chi)
            }
        </div>
        <div id={str + thisLab.lab_number}>
          <div className="btn-toggle-nav list-unstyled fw-normal pb-1 small">
            <div
              className=
              {
                "list-item " +
                (`Lab${globalVar.labID}Task${globalVar.taskID}` ===
                `Lab${thisLab.lab_number}Task999`?"active" : "")
              }
              id={"EditLab" + thisLab.lab_number}
              value={labNumber++}
              onClick={() => { globalVar.labID = document.getElementById("EditLab" + thisLab.lab_number).value; this.state.jumpToEditLab();globalVar.taskID = 999;}}
            >
              <a href="#" className="link-white d-inline-flex text-decoration-none rounded" >
                Edit this lab 編輯這個實驗
              </a>
            </div>
            {
              // Task List
              listXS = thisLab.tasks.map((task) =>
              (
                <div className={"list-item " + (`Lab${globalVar.labID}Task${globalVar.taskID}` === `Lab${labNumber - 1}Task${taskNumber+1}` ? "active" : "")}
                  id={`Lab${thisLab.lab_number}Task${task.task_number}`}
                  key={`Lab${thisLab.lab_number}Task${task.task_number}`}
                  value={(labNumber - 1) * 10000 + (++taskNumber)}
                  data = {thisLab.lab_number.toString()+'a'+task.task_number.toString()}
                  // value=
                  onClick={() => {
                    globalVar.labID = (document.getElementById("Lab" + thisLab.lab_number + "Task" + task.task_number).value - document.getElementById("Lab" + thisLab.lab_number + "Task" + task.task_number).value % 100) / 10000;
                    globalVar.taskID = document.getElementById("Lab" + thisLab.lab_number + "Task" + task.task_number).value % 100;

                    ((task.task_number < 999) ? (this.state.jumpToEditTask()) : this.state.jumpToAddTask());
                  }}
                >
                  <a
                    href="#"
                    className="link-white d-inline-flex text-decoration-none rounded align-items-center"
                  >
                    {task.task_number < 999 ?
                      ("") : (
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" className="bi bi-plus-square before" viewBox="0 0 16 16">
                          <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                          <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                        </svg>
                      )}

                    {(task.task_number < 999) ? (taskText +
                      (globalVar.language === "eng"
                        ? (taskNumber) + " " + task.title_eng
                        : arabicToChinese(taskNumber) +
                        "：" +
                        task.title_chi)) : (globalVar.language === "eng"
                          ? task.title_eng : task.title_chi)}
                  </a>
                </div>
              ))
            }
          </div>
        </div>
      </div>
    ));

    return (
      <div>
        <div>
          <div>
            <button type="button" className="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed h4" data-bs-toggle="collapse" data-bs-target="#material" aria-expanded="false" style={{margin:0}}>View Material 瀏覽材料</button>
              <div id="material">
                  <div>
                      <div className= "list-item " onClick={() => {this.state.jumpToAddMaterial()}}>
                          <a href="#/materials/add" className="link-white d-inline-flex text-decoration-none rounded align-items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square me-1" viewBox="0 0 16 16">
                            <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                            <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                          </svg>
                            Add New Item 增加新材料
                          </a>
                      </div>
                      <div onClick={() => {this.state.jumpToEditMaterial()}}>
                          <a href="#/materials/edit" className="link-white d-inline-flex text-decoration-none rounded align-items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-square me-1" viewBox="0 0 16 16">
                              <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                              <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                          </svg>
                            Edit Items 編輯內容
                          </a>
                      </div>
                  </div>
            </div>
          </div>
          <div class="border-bottom mb-3"></div>
          
          <div>
            <button type="button" className="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed h4" data-bs-toggle="collapse" data-bs-target="#course" aria-expanded="false" style={{margin:0}}>View Course 瀏覽課程</button>
            <div className="collapse" id="course">
            
                <ul className="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                    { 
                        listXXS = globalVar.courseList.map((course)=>(
                        <li className= "list-item " onClick={() => {getCourseData({name:course.name});this.state.jumpToEditCourse()}}>
                            <a href="#/courses/edit" className="link-white d-inline-flex text-decoration-none rounded align-items-center" >
                            {course.name}
                            </a>
                        </li>
                        ))
                    }
                    <li className= "list-item " onClick={()=>{this.state.jumpToAddCourse();globalVar.courseID=999}}>
                        <a href="#/courses/add" className="link-white d-inline-flex text-decoration-none rounded align-items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-plus-square before" viewBox="0 0 16 16">
                            <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                            <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                        </svg>
                          Add Course 增加新課程
                        </a>
                    </li>
                </ul>
            </div>
            <div className="border-bottom my-3"></div>
          </div>
          <a className="link-white d-inline-flex text-decoration-none rounded align-items-center h4">&nbsp; {globalVar.courseData.name}</a>
          {listS}
        </div>
      </div>
    );
  }
}