import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
import { ToastContainer, toast } from 'react-toastify';
import { Collapse } from "bootstrap";
import { Modal, Button } from "react-bootstrap";
import axios from "axios";
import Cookies from "js-cookie";

import { getCourseData } from "./getCourseData";
import globalVar from "./globalVar";

export class CourseEditor extends React.Component
// export function CourseEditor() 
{
  constructor() {
    super();
    this.state = {
      refresh: false,
      width: window.innerWidth,
      name: globalVar.courseData.name,
      des_eng: globalVar.courseData.description_eng,
      des_chi: globalVar.courseData.description_chi,
      pre: globalVar.courseID,
      show: false
    }
  }

  uploadData() {
    var data = new FormData();
    data.append("name", this.state.name);
    data.append("description_eng", this.state.des_eng);
    data.append("description_chi", this.state.des_chi);
    axios.patch(globalVar.serverlocation + "/api/admin/courses/" + globalVar.courseData.id + "/", data, {
      headers: {
        'Authorization': Cookies.get('access_token')
      }
    })
      .then(res => {
        // console.log(res.request.status);
        // console.log(res.data);
        toast.success('Saved and updated! 已儲存及更新！', {
          position: "top-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      })
      .catch(err => {
        //console.log(err)
        console.log(err);
        toast.error('Unknown error!', {
          position: "top-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      })
  }

  updateDimensions = () => {
    this.setState({ width: window.innerWidth, height: window.innerHeight });
  };
  componentDidMount() {
    window.addEventListener('resize', this.updateDimensions);
  }
  componentWillUnmount() {
    window.removeEventListener('resize', this.updateDimensions);
  }

  updateFields() {//only change text when switching to another course
    if (this.state.pre != globalVar.courseData.id) {
      this.setState({
        name: globalVar.courseData.name,
        des_eng: globalVar.courseData.description_eng,
        des_chi: globalVar.courseData.description_chi,
        pre: globalVar.courseData.id
      });
    }
  }

  deleteCourse() {
    axios.delete(globalVar.serverlocation + "/api/admin/courses/" + globalVar.courseData.id + '/', {
      headers: {
        'Authorization': Cookies.get('access_token'),
      }
    })
      .then(res => {
        toast.success('Deleted!', { position: "top-center", autoClose: 3000, closeOnClick: true, pauseOnHover: false, progress: undefined, });
        axios.get(globalVar.serverlocation + "/api/admin/courses/", {
          headers: {
            'Authorization': Cookies.get('access_token'),
          }
        })
          .then(function (response) {
            //console.log(response.data);
            globalVar.courseList = response.data;
            //self.setState({gotData: 1});
            // console.log(111111111)
            // console.log(globalVar.courseList);
            getCourseData({ name: globalVar.courseList[0].name });
          }).catch(function (error) {
            window.alert('error');
            console.log(error)
          })
      })
      .catch(err => console.log(err))
  }

  handleShow() {
    this.setState({ show: true });
  }

  handleClose() {
    this.setState({ show: false });
  }

  render() {
    // console.log("Course Editor render");
    // console.log(globalVar.courseData.id, " ", this.state.pre)
    // this.state = {name: globalVar.courseData.name};
    // var [name, setName] = useState(globalVar.courseData.name);
    this.updateFields();

    return (
      <div class="mt-3 bg-body shadow-sm">
        <div className="bg-pkDarkBlue2 row m-0 p-3">
          <h3 className="col" style={{ color: "white" }}>{`${globalVar.courseData.name} | Edit Course Details 修改課程資料`}</h3>
          <div className="col-5 col-xl-4 float-end pe-0">
            <button className="btn btn-delete float-end px-3" onClick={() => this.handleShow()}>DELETE THIS COURSE 刪除整個課程頁面</button>
          </div>
        </div>

        <div className="row g-3 stepContentText p-3 pt-3">
          <div className="col-12">
            <label for="email" className="form-label">Course Name 課程名稱</label>
            <p style={{ fontSize: '14px' }}>Please do not remove " | " (Space|Space) if the course name have both English and Chinese version.</p>
            <p style={{ fontSize: '14px' }}>如果課程名稱有中英文版本，請勿刪除 " | " (空格|空格) </p>
            <input className="form-control EditorInput form-control br-0" value={this.state.name} onChange={e => { this.setState({ name: e.target.value }) }} />
          </div>

          <div className="col-12">
            <label for="email" className="form-label">Course Description In English</label>
            <td className="field-description_chi">
              <textarea value={this.state.des_eng} onChange={e => { this.setState({ des_eng: e.target.value }) }} name="form-0-description_chi" cols="40" rows="5" className="vLargeTextField b-grey" id="id_form-0-description_chi" style={{ width: window.innerWidth*0.815-64}} />
              {/* <textarea value={this.state.des_eng} onChange={e => { this.setState({ des_eng: e.target.value }) }} name="form-0-description_chi" cols="40" rows="5" className="vLargeTextField b-grey" id="id_form-0-description_eng" style={{ width: window.innerWidth * ((window.innerWidthh > 1465) ? 0.516 : 0.5) }} /> */}
            </td>
          </div>

          <div class="col-12">
            <label for="email" class="form-label">
              課程簡介（中文版內容）
            </label>
            <td class="field-description_eng">
              <textarea value={this.state.des_chi} onChange={e => { this.setState({ des_chi: e.target.value }) }} name="form-0-description_chi" cols="40" rows="5" className="vLargeTextField b-grey" id="id_form-0-description_chi" style={{ width: window.innerWidth*0.815-64}} />
            </td>
          </div>
          <ToastContainer position="top-center" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} />
        </div>

        <div className="row">
          <div className="col">
            <button className="col btn btn-save float-end m-3 mt-0" onClick={() => this.uploadData()}>SAVE 儲存</button>
          </div>
        </div>

        <Modal show={this.state.show} onHide={() => this.handleClose()}>
          <Modal.Header closeButton>
            <Modal.Title>Confirm Message 確認信息</Modal.Title>
          </Modal.Header>
          <Modal.Body>Do you want to delete this course? It cannot be recovered. 你想刪除整個課程嗎？動作不可復原。</Modal.Body>
          <Modal.Footer>
            <Button variant="save" onClick={() => { this.handleClose() }}>CANCEL 取消</Button>
            <Button variant="delete" onClick={() => { this.handleClose(); this.deleteCourse(); }}>CONFIRM 確認</Button>
          </Modal.Footer>
        </Modal>

      </div>
    );
  }
}
