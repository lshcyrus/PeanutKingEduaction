import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Cookies from "js-cookie";
import axios from "axios";
import "./style.css";
import { ToastContainer, toast } from 'react-toastify';
import {getCourseList} from "./getCourseList";
import { Collapse } from "bootstrap";
import globalVar from "./globalVar";
import { useLocation, useNavigation } from "react-router-dom";


export class CourseAdder extends React.Component {
  constructor() {
    super();
    this.state={
        refresh: false,
        name: "",
        des_eng: "",
        des_chi: "",
        width: window.innerWidth,
        gotData: 0,
    }
  }

  uploadData(props){
    var data = new FormData();
    data.append("name", this.state.name);
    data.append("description_eng", this.state.des_eng);
    data.append("description_chi", this.state.des_chi);
    axios.post(globalVar.serverlocation + "/api/admin/courses/", data, {
      headers: {
        'Authorization': Cookies.get('access_token')
      }
    })
      .then(res => {
        // console.log(res.request.status);
        // console.log(res.data);
        toast.success('Saved and updated! 已儲存及更新！', {
          position: "top-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
        getCourseList({self:this});
      })
      .catch(err => {
        console.log(err)
        // console.log(err.response.data.name[0]);
        // toast.error(err.response.data.name[0], {
        //   position: "top-center",
        //   autoClose: 5000,
        //   hideProgressBar: false,
        //   closeOnClick: true,
        //   pauseOnHover: true,
        //   draggable: true,
        //   progress: undefined,
        // });
      })
  }
  
  updateDimensions = () => {
    this.setState({ width: window.innerWidth, height: window.innerHeight });
  };
  componentDidMount() {
    window.addEventListener('resize', this.updateDimensions);
  }
  componentWillUnmount() {
    window.removeEventListener('resize', this.updateDimensions);
  }
  
  render() {
    return (
      <div class="my-3 bg-body shadow-sm row">
        <div className="bg-pkDarkBlue2">
                <h3 className="p-3 mb-0" style={{color:"white"}}>Add New Course 增加新課程</h3>
        </div>

          <div class="row g-3 stepContentText p-3 pt-0 pe-0">
            <div class="col-12">
              <label for="email" className="form-label">
                Course Name
              </label>
              <input type="email" className="form-control EditorInput form-control br-0" value={this.state.name} onChange={e => { this.setState({ name: e.target.value }) }}/>
              {/* <div class="invalid-feedback">
                Please enter a valid email address for shipping updates.
              </div> */}
            </div>

            <div className="col-6">
              <label for="email" class="form-label">
              Course Description (English)
              </label>
              <td class="field-description_chi">
                <textarea name="form-0-description_chi" cols="40" rows="10" value={this.state.des_eng} onChange={e => { this.setState({ des_eng: e.target.value }) }} className="vLargeTextField b-grey" id="id_form-0-description_chi" style={{width: this.state.width*((this.state.width>1465)?0.394:0.5)}} required/>
              </td>
              {/* <div class="invalid-feedback">
                Please enter a valid email address for shipping updates.
              </div> */}
            </div>

            <div class="col-6">
              <label for="email" class="form-label">
              課程簡介（中文）
              </label>
              <td class="field-description_eng">
              <textarea name="form-0-description_chi" cols="40" rows="10" value={this.state.des_chi} onChange={e => { this.setState({ des_chi: e.target.value }) }} className="vLargeTextField b-grey" id="id_form-0-description_chi" style={{width: this.state.width*((this.state.width>1465)?0.394:0.5)}} required/>
              </td>
              {/* <div class="invalid-feedback">
                Please enter a valid email address for shipping updates.
              </div> */}
            </div>

            <div className="col float-end">
              <button class="btn btn-save float-end" onClick={() => {this.uploadData()}}>SAVE 儲存</button>
              {/* console.log(this.state.name," ",this.state.des_eng," ",this.state.des_chi) */}
            </div>
            <ToastContainer position="top-center" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false}/>
          </div>
      </div>
    );
  }
}
