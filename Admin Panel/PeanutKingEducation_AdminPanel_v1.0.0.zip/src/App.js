
/* You should be able to track and find all the components the website has been using on this page. */

import { HashRouter as Router, Route, Routes } from "react-router-dom"
import { FullContainer } from "./global/FullContainer"
import Materials from "./pages/Materials"     // index.js inside Materials folder is the default page for Materials
import Courses from "./pages/Courses";        // index.js inside Courses folder is the default page for Courses
import Management from "./pages/Management";  // index.js inside Management folder is the default page for Management
import React from "react";
import AddMaterial from "./pages/Materials/components/addMaterial";
import EditMaterial from "./pages/Materials/components/editMaterial";  // built by Lester, not in use anymore
import { CourseEditor } from "./global/CourseEditor";                  // built by Lester, not in use anymore
import CourseDetail from "./global/CourseDetail";
import { LabEditor } from "./global/labEditor";                        // in fact this is built by Lester, I only keep the choosing material part
// import { AddLab } from "./pages/Courses/labs/components/addLab";    // built by Lester, not in use anymore
import AddNewLab from "./pages/Courses/labs/components/AddNewLab";      
import CourseList from "./pages/Courses/components/courseList";
import Labs from "./pages/Courses/labs";
import LabDetail from "./pages/Courses/labs/components/LabDetail";
import Tasks from "./pages/Courses/labs/tasks";
// import { AddTask } from "./pages/Courses/labs/tasks/components/addTask";
import AddNewTask from "./pages/Courses/labs/tasks/components/AddNewTask";
import TaskDetail from "./pages/Courses/labs/tasks/components/TaskDetail";
import StepEditor from "./pages/Courses/labs/tasks/steps/component/stepEditor";
import AddStep from "./pages/Courses/labs/tasks/steps/component/addStep";
import AddCourse from "./pages/Courses/components/addCourse";
import ShowMaterial from "./pages/Materials/components/showMaterial";
import EditCourse from "./pages/Courses/components/editCourse";
import EditLab from "./pages/Courses/labs/components/EditLab";

function App() {

  return (
    /*  This is the home page for starting the frontend of website.
        Here shows the router of the website.
        You can check the routes and redirection here. */

    <Router>
        <Routes>
          <Route path="/" element={<FullContainer />} />
          <Route path="/materials" element={<Materials />}>   
            <Route path="add" element={<AddMaterial />} />
            <Route path="edit" element={<ShowMaterial />} />
          </Route>
          <Route path="/courses" element={<Courses />}>
            <Route path="add" element={<AddCourse />} />
            <Route path="list" element={<CourseList />} />
            <Route path=":name" element={<CourseDetail />}>
              <Route path="edit" element={<EditCourse />} />
              <Route path="addlab" element={<AddNewLab />}/>
              <Route path="lab" element={<Labs />}/>
              <Route path="lab/:lab_number" element={<LabDetail />}>
                <Route path="edit" element={<EditLab />}/>
                <Route path="edit-materials" element={<LabEditor />}/> 
                <Route path="add-task" element={<AddNewTask />}/>
                <Route path="task" element={<Tasks />} />
                <Route path="task/:task_number" element={<TaskDetail />}>
                  <Route path="steps/:step_number" element={<StepEditor />} />
                  <Route path="steps/add" element={<AddStep />} />
                </Route>
              </Route>
            </Route>
          </Route>
          <Route path="/manage" element={<Management />} />
        </Routes>
      </Router> 
  )
}

export default App;