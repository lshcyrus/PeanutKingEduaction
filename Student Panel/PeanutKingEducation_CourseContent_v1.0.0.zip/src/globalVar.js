export default {
    // serverlocation: "http://192.168.0.191:8000",
    serverlocation: "https://peanutkingeducation.com",
    courseData: "",
    courseList:"",
    courseID: 1,
    labID: 1,
    taskID: 0,
    userName: "", 
    language: 'eng',
    isTutor: false,
    access_token: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbiI6ImltUG80MmZiVXE1c0dWa1oxZUY3M2lrSTlHYnRZTyJ9.s_f64LPrWMnGhTch2xes8XTIwEQFT_VC75VV3CuVeYo"
}