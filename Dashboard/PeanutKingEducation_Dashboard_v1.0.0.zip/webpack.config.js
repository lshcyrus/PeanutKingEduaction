const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
  mode: 'development',
  entry: './src/index.js', // webpack 打包的起始檔案
  output: {
    path: 'C:/Users/Admin/Desktop/AWS_TESTING/PeanutKingEducation_Dashboard-master/webpack-test', // output to a folder called webpack
    filename: 'PKE_Dashboard_v1.0.0.js' // output file name, change the version no. can update the website instantly after refreshing browser 
  },
  module: {
    rules: [
      {
        test: /\.?js$/,
        // exclude: /node_modules/,
        use: {
          loader: "babel-loader",
          options: {
            presets: ['@babel/preset-env', ['@babel/preset-react', {"runtime": "automatic"}]]
          },
        }
      },
      {
        test: /\.css$/i,
        use: ["style-loader", "css-loader"],
      },
      {
        test: /\.(jpe?g|png|gif|svg)$/i,
        loader: 'file-loader',
      },
      {
        test: /\.svg$/,
        loader: 'svg-inline-loader'
      },
    ]
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: path.join(__dirname, "public", "index.html"),
    }),
  ],
}