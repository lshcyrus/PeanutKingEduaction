import axios from "axios";
import Cookies from "js-cookie";

import globalVar from "./globalVar";
import { HandleError } from "./HandleError";

export function getRedeemedCourse(props) {
  axios.get(globalVar.serverlocation + '/api/student/redeemed_courses/', {
    headers: {
      'Authorization': Cookies.get('access_token'),
    }
  })
    .then(function (response) {
      //console.log(response);
      globalVar.courseList = response.data;
      // console.log("111111");
      // console.log(globalVar.courseList);
      if (props.self != null)
        props.self.setState({ gotData: 1 });
      //console.log(self.state.gotData);
    }).catch(function (error) {
      HandleError(error);
    })
}