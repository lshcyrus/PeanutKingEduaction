import 'bootstrap/dist/css/bootstrap.min.css';
import "./style.css"

import React from 'react';
import Cookies from 'js-cookie';
import globalVar from './globalVar';
import axios from 'axios';
// import { ToastContainer, toast } from 'react-toastify';

import { Dashboard_Container } from './dashboard';
import { Dashboard_Sidebar } from './dashboardSidebar';
import { HandleError } from './HandleError.js';
import { getRedeemedCourse } from './getRedeemedCourse';
import { getUserInfo } from './getUserInfo';
import { TopBar } from './TopBar';

export class App extends React.Component {
  constructor(props) {
    super(props);
    //getCourseList();
    this.state = {
      gotData: 0,
      gotName: 1,
      gotSchool: 0,
      forceRefreash: 0,
      seen: false
    }
  }

  refreshApp() {
    this.setState({ forceRefreash: !this.state.forceRefreash });
    //console.log("try to refresh");
  }

  componentDidMount() {
    if (Cookies.get("language") == null)//default language: english
      Cookies.set("language", "eng");
    else
      globalVar.language = Cookies.get("language");

    var self = this;
    getRedeemedCourse({ self: this });

    axios.get(globalVar.serverlocation + '/api/organizations/', {
      headers: {
        'Authorization': Cookies.get('access_token'),
      }
    })
      .then(function (response) {
        globalVar.schoolList = response.data;
        self.setState({ gotSchool: 1 });
        //console.log(self.state.gotData);
      }).catch(function (error) {
        HandleError(error);
      })

    getUserInfo({ self: this });

  }
  // componentDidMount(){ //only use this when backend is down
  //   globalVar.courseList = [{id:1, name:"EDUKit"},{id:2, name:"Test Course"}];
  //   this.setState({gotData:1});
  // }

  render() {
    if (this.state.gotData + this.state.gotName + this.state.gotSchool === 3) {
      return (
        <div className='body min-height100' id="dashboardroot">

          <header>
            <TopBar refresh={() => this.refreshApp()} />
          </header>
          <div className='container-fluid'>
            {/* <ToastContainer containerId={"a"} position="top-center" autoClose={5000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnFocusLoss pauseOnHover/> */}
            <div className='row'>
              {/* <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-pkDarkBlue3 sidebar collapse">
                <Dashboard_Sidebar language={globalVar.language} />
              </nav> */}
              <main class="ms-sm-auto px-md-4">
                {/* {console.log("app root", globalVar.language)} */}
                <Dashboard_Container appRoot={this} redeemed={globalVar.courseList} language={globalVar.language} />
              </main>
            </div>
          </div>
        </div>
      );
    }
  }
}

export default App;
