import axios from "axios";
import Cookies from "js-cookie";

import globalVar from "./globalVar";
import { HandleError } from "./HandleError";

export function getUserInfo(props) {
  console.log("get user info", props)
  axios.get(globalVar.serverlocation + '/api/get_userinfo/', {
    headers: {
      'Authorization': Cookies.get('access_token'),
    }
  })
    .then(function (response) {
      // console.log(response.data);
      //console.log(response.data);
      if (response.data.name_eng == "")
        globalVar.userName = response.data.username;
      else
        globalVar.userName = response.data.name_eng;
      // console.log(response.data.sex);
      globalVar.firstLogin = true;//true: first time login
      // globalVar.firstLogin = (response.data.sex=="" && response.data.organization==null);//true: first time login

      var idgroups = response.data.groups;
      for (var i = 0; i < idgroups.length; i++) {
        if (idgroups[i]["name"] == "Tutors")
          globalVar.isTutor = true;
        break;
      }
      if (props.self) props.self.setState({ gotName: 1 });
      //console.log(self.state.gotData);
    }).catch(function (error) {
      HandleError(error);
    })
}