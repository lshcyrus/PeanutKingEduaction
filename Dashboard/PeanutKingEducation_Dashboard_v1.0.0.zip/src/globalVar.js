export default {
    serverlocation: "https://peanutkingeducation.com",
    // serverlocation: "http://192.168.0.191:8000",
    courseData: "",
    courseID: 1,
    labID: 1,
    taskID: 0,
    language: 'eng',
    courseList: "",
    userName: "",
    firstLogin: "",
    schoolList: null,
    isTutor: false,
}