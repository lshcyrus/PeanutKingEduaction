import React from 'react';

import globalVar from './globalVar.js';
import { gotoCourse } from './gotoCourse.js';

export function Dashboard_Sidebar(props) {

    const splitCourseName = (name) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            if (globalVar.language == 'eng') {
                return name.split(' | ')[0]
            } else {
                return name.split(' | ')[1]
            }
        }
    }

    var listXs = globalVar.courseList.map((course) =>
        <button class="nav-link pb-0 ps-4 d-flex text_align_left" style={{
            background: "none",
            // color: "inherit",
            border: "none",
            // padding: 0,
            font: "inherit",
            cursor: "pointer",
            outline: "inherit",
        }}
            onClick={() => { gotoCourse(course.name) }}
        >
            <a className='dashboard_sidebar'>
                <span data-feather="file-text" class="align-text-bottom"></span>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right-circle" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8zm15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z" />
                </svg>
                {" " + splitCourseName(course.name)}
            </a>
        </button>

    );
    return (
        <div class="position-sticky pt-3 ps-3">
            {/* <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="#">
                                <span data-feather="home" class="align-text-bottom"></span>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="#">
                                <span data-feather="home" class="align-text-bottom"></span>
                                Profile
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="#">
                                <span data-feather="home" class="align-text-bottom"></span>
                                Setting
                            </a>
                        </li>
                    </ul> */}

            <h6 class="d-flex justify-content-between align-items-left px-2 mb-1 text-muted text-uppercase text-lightcolor" style={{ color: "#a8b6c3 !important" }}>
                <span>{props.language == "eng" ? "Courses" : "課程"}</span>
                <a class="link-secondary" aria-label="Add a new report">
                    <span data-feather="plus-circle" class="align-text-bottom"></span>
                </a>
            </h6>
            <ul class="nav flex-column mb-2">
                <li class="nav-item">
                    {listXs}
                </li>
            </ul>
        </div>
    );

}