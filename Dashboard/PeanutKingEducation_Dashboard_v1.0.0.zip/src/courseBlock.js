import React from 'react';
import { gotoCourse } from './gotoCourse.js';
import PKEIcon from './logo_only.png'
import globalVar from './globalVar.js';
import { Card } from 'antd';
import { styled } from 'styled-components';

const { Meta } = Card;

const StyledCard = styled(Card)`
    width: 650px;
    margin: 20px;
    border-radius: 0;
    box-shadow: 0 0 10px 0 rgba(0,0,0,0.2);
    transition: all 0.3s ease-in-out;

    &:hover {
        cursor: pointer;
        transform: scale(1.05);
    }

    .ant-card-meta-title {
        font-size: 18px;
        font-weight: 500;
        color: #000;
    }

    .ant-card-meta-description {
        font-size: 14px;
        font-weight: 400;
        line-height: 1.5;
        color: #000;
    }

    .ant-card-meta-description p {
        font-size: 14px;
        font-weight: 400;
        line-height: 1.5;
        color: #000;
    }

    .ant-card-body #course-image {
        flex: 0 0 200px;
    }

    @media screen and (max-width: 1550px) {
        width: 500px;

        .ant-card-meta-title {
            font-size: 16px;
            overflow: hidden;
            overflow-wrap: break-word;
            white-space: wrap;
        }

        .ant-card-meta-description {
            font-size: 12px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: wrap;
        }

        .ant-card-meta-description p {
            font-size: 12px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: wrap;
        }
    }

    @media screen and (max-width: 768px) {
        width: 80%;
        margin: 20px 0;

        .ant-card-meta-title {
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            font-weight: bold;
            overflow: hidden;
            overflow-wrap: break-word;
            white-space: wrap;
        }

        .ant-card-meta-description {
            display: none;
        }

        .ant-card-meta-description p {
            display: none;
        }

        .ant-card-body #course-image {
            flex: 0 0 100px;
        }
    }
`;

const CourseBlock = (props) => {

    const splitCourseName = (name) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            if (globalVar.language == 'eng') {
                return name.split(' | ')[0]
            } else {
                return name.split(' | ')[1]
            }
        }
    }

    return (
        <StyledCard hoverable onClick={() => { gotoCourse(props.courseName) }}>
            <div style={{ display: 'flex' }}>
                <div id='course-image'>
                    <img src={PKEIcon} alt="Course Image" style={{ width: '100%', height: 'auto' }} />
                </div>
                <div style={{ flex: '1', padding: '0 15px' , overflow: 'hidden'}}>
                    <Meta
                        title={splitCourseName(props.courseName)}
                        description={globalVar.language === 'eng' ? <div dangerouslySetInnerHTML={{ __html: props.courseDesc }} /> : <div dangerouslySetInnerHTML={{ __html: props.courseDescChi }} />}
                    />
                </div>
            </div>
        </StyledCard>
    );
}

export default CourseBlock;
