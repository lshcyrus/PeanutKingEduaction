import axios from "axios";
import Cookies from "js-cookie";

import globalVar from "./globalVar";
import { HandleError } from "./HandleError";

export function gotoCourse(name) {
    //console.log("cookei");
    Cookies.set('courseName', name)
    //console.log(Cookies.get("courseName"))
    axios.get(globalVar.serverlocation + '/api/courses/' + Cookies.get('courseName'), {
        headers: {
            'Authorization': Cookies.get('access_token'),
        }
    })
        .then(function (response) {
            window.location = "https://peanutkingeducation.com/coursecontent/index.html"
            //console.log(self.state.gotData);
        }).catch(function (error) {
            HandleError(error);
        })

}