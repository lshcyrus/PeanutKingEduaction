import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import axios from 'axios';
import Cookies from 'js-cookie';
import { isMobile } from 'react-device-detect';

import globalVar from './globalVar.js';
import { FirstLogin } from './firstLogin.js';
import { getRedeemedCourse } from './getRedeemedCourse.js';
import { MobileRedeemedCourses } from './mobileRedeemedCourses.js';
import CourseBlock from './courseBlock.js';

const userData = {
    username: "Dickson",
    latest_course_id: 1,
    latest_progress: 0
}

const color = ["bg-pkPink", "bg-pkYellow", "bg-pkGreen", "bg-info", "bg-pkPurple"];

export function Dashboard_Container(props) {
    return (
        <div id="dashboardroot">

            {globalVar.firstLogin ? <FirstLogin appRoot={props.appRoot} /> : <div></div>}
            <div>

                <UserIntroBlock appRoot={props.appRoot} />
                {/* isMobile ? <MobileRedeemedCourses redeemed={props.redeemed} language={props.language} /> : */}
                <div>
                    {globalVar.language === 'eng' ? <h1 style={{ textAlign: 'center', color: 'rgb(23, 43, 76)' }}>REDEEMED COURSES</h1> : <h1 style={{ textAlign: 'center', color: 'rgb(23, 43, 76)' }}>已兌換課程</h1>}
                    <hr />
                    {globalVar.courseList.length === 0 ? <div className='center'><h4 style={{ textAlign: 'center', color: 'rgb(23, 43, 76)' }}>{globalVar.language === 'eng' ? 'REDEEM A COURSE TO GET STARTED!' : '兌換課程以開始你的學習之旅！'}</h4></div> :
                        <div className='center'>

                            {//<StudentProgressBlock /> <TaskProgressBlock /> 
                            }

                            {globalVar.courseList.map((course) => (
                                <CourseBlock key={course.id} courseName={course.name} courseDesc={course.description_eng} courseDescChi={course.description_chi} />
                            ))}
                        </div>
                    }
                </div>
            </div>
        </div>
    );
}

// class ApexChart extends React.Component {
//     constructor(props) {
//         super(props);

//         this.state = {
//             series: [userData.latest_progress],
//             options: {
//                 chart: {
//                     height: 280,
//                     type: "radialBar"
//                 },
//                 plotOptions: {
//                     radialBar: {
//                         hollow: {
//                             margin: 15,
//                             size: "70%"
//                         },

//                         dataLabels: {
//                             showOn: "always",
//                             name: {
//                                 offsetY: -10,
//                                 show: false,
//                                 color: "#888",
//                                 fontSize: "13px"
//                             },
//                             value: {
//                                 color: "#111",
//                                 fontSize: "30px",
//                                 show: true
//                             }
//                         }
//                     }
//                 },

//                 stroke: {
//                     lineCap: "round",
//                 },
//                 labels: ["Progress"]
//             }
//         };
//     }

//     render() {
//         return (
//             <div>
//                 <div id="chart">
//                     <ReactApexChart options={this.state.options} series={this.state.series} type="radialBar" height={330} />
//                     <div className="text-end">
//                         <a type="button" className ="btn btn-third" href="course_content.html"><i class="bi bi-caret-right-fill"></i>Continue</a>
//                     </div>
//                 </div>
//                 <div id="html-dist"></div>
//             </div>
//         );
//     }
// }


// function TaskProgressBlock(props) {
//     return (
//         <div className="col-12 col-xl-6">
//             <div className="box">
//                 <div className="box-header with-border">
//                     <h4 className="box-title">Task Completion</h4>
//                 </div>
//                 <div className="box-body" style={{ position: 'relative' }}>
//                     <ApexChart progress={50}/>
//                 </div>
//             </div>
//         </div>
//     );
// }

function StudentProgressBlock(props) {

    var i = 0;

    const studentData = {
        "student": [
            {
                "name": "Amelia",
                "progress": 75
            },
            {
                "name": "Johen",
                "progress": 70
            },
            {
                "name": "Anson87",
                "progress": 55
            },
            {
                "name": "Alex",
                "progress": 45
            },
            {
                "name": "Neudeutsche Schule",
                "progress": 25
            }
        ]
    }

    var listS = studentData.student.map(
        (data) =>
            <div className="d-flex align-items-center mb-30 gap-items-3 justify-content-between" key={i}>
                <div className="d-flex align-items-center fw-500">
                    <div className="me-3 d-table" style={{ width: '48px' }}>
                        <img src="img/testIcon.jpg"
                            className="avatar avatar-lg rounded10 bg-primary-light" alt="" />
                    </div>
                    <div>
                        <a href="#"
                            className="text-dark hover-primary d-block fs-16">{data.name}</a>
                        <div className="w-300">
                            <div className="progress progress-sm mb-0">
                                <div className={"progress-bar progress-bar-primary progress-bar-striped progress-bar-animated " + color[i]}
                                    role="progressbar" aria-valuenow="75" aria-valuemin="0"
                                    aria-valuemax="100" style={{ width: data.progress + '%' }}>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="text-end">
                    <h5 className={"fw-600 mb-0 badge badge-pill badge-primary " + color[i++]}>{data.progress + "%"}</h5>
                </div>
            </div>
    );

    return (
        <div className="col-12 col-xl-6">
            <div className="box">
                <div className="box-header with-border">
                    <h4 className="box-title">Other Students' Progress </h4>
                </div>
                <div className="box-body" style={{ position: 'relative' }}>
                    {listS}
                </div>
            </div>
        </div>
    );
}

function UserIntroBlock(props) {
    const [show, setShow] = useState(false);
    const handleClose = () => { setShow(false) };
    const handleShow = () => setShow(true);
    const [showButton, setShowButton] = useState(true);

    const splitCourseName = (name) => {
        if (name.split(' | ').length == 1) {
            return name
        } else {
            if (globalVar.language == 'eng') {
                return name.split(' | ')[0]
            } else {
                return name.split(' | ')[1]
            }
        }
    }

    // const engTxt = ["Welcome back, ","You have completed "," of the tasks.","Progress is "," very good!","Get a new course."];
    // const chTxt = ["歡迎回來, ","你完成了","的任務。","進度","十分良好！","獲取新的課程"];
    const engTxt = ["Hello, ", "Please enter your Course Redemption Key here. (You may find the key in Course Registration Email)", "REDEEM A COURSE"];
    const chTxt = ["你好, ", "輸入課程兌換代碼（可以在課程訂購電郵找到）", "獲取新課程"];
    const showTxt = (globalVar.language === "eng") ? engTxt : chTxt;

    var i = 0;

    return (
        <div>
            <div>
                <div className="box-body d-flex px-0">
                    <div className="flex-grow-1 p-30 flex-grow-1 bg-img dask-bg bg-none-md"
                    /* style="background-position: right bottom; background-size: auto 100%; background-image: url(../images/svg-icon/color-svg/custom-1.svg)"*/>
                        <div className="row" style={{ color: '#172b4c' }}>
                            <div>
                                <h2 className='mb-3' style={{ textAlign: 'center' }}>{showTxt[i++] + (globalVar.isTutor ? globalVar.language === "eng" ? "Tutor " : "導師 " : "")} <strong>{globalVar.userName}!</strong></h2>

                                {/* <p className="text-dark my-10 fs-16">
                                {showTxt[i++]} <strong className="text-highlight">{userData.latest_progress + "%"}</strong> {showTxt[i++]}
                                </p>
                                <p className="text-dark my-10 fs-16">
                                {showTxt[i++]}<strong className="text-highlight">{showTxt[i++]}</strong>
                                </p> */}

                                <Modal
                                    show={show}
                                    onHide={handleClose}
                                    backdrop="static"
                                    keyboard={false}
                                >
                                    <Modal.Header>
                                        {/* closeButton */}
                                        <Modal.Title>{showTxt[i++]}</Modal.Title>
                                    </Modal.Header>
                                    <Modal.Body>
                                        <input id="keyinput" style={{ width: '100%' }}></input>
                                        <p id="response"></p>
                                    </Modal.Body>
                                    <Modal.Footer>
                                        {
                                            (showButton == true) ?
                                                <Button variant="btn btn-outline-success" onClick={() => {
                                                    var inputed = document.getElementById("keyinput").value;
                                                    if (inputed == '91751781')
                                                        document.getElementById("response").innerHTML = "Call us to get discount.";
                                                    else {
                                                        var form_Data = new FormData();
                                                        form_Data.append("redemption_key", inputed);
                                                        axios.post(globalVar.serverlocation + '/api/student/redemptions/', form_Data, {
                                                            headers: {
                                                                'Authorization': Cookies.get('access_token')
                                                            }
                                                        })
                                                            .then(res => {
                                                                //console.log(res.request.status);
                                                                //console.log(res.data);
                                                                setShowButton(false);
                                                                document.getElementById("response").innerHTML = (globalVar.language === "eng") ? ('✅Redemption successful! Please close this window to view course: ' + splitCourseName(res.data.course) + '.') : '✅兌換成功！請關閉對話框瀏覽課程：' + splitCourseName(res.data.course) + '。';
                                                                getRedeemedCourse({ self: props.appRoot });
                                                            })
                                                            .catch(err => {
                                                                //console.log(err)
                                                                document.getElementById("response").innerHTML = (globalVar.language === "eng") ? '❌Redemption failed. Please enter the key again.' : '❌兌換失敗！請重新輸入代碼。';
                                                            })
                                                    }
                                                }}>
                                                    {globalVar.language === 'eng' ? 'SUBMIT' : '遞交'}
                                                </Button> : ""
                                        }
                                        <Button variant="btn btn-outline-secondary" onClick={handleClose}>{globalVar.language === 'eng' ? 'CLOSE' : '關閉'}</Button>
                                    </Modal.Footer>
                                </Modal>

                            </div>
                            <div className="col-12 col-xl-5"></div>
                        </div>
                        <div class="row">
                            <div style={{ display: 'flex', alignContent: 'center', justifyContent: 'center', marginTop: '50px' }}>
                                <input id="keyinput" style={{ width: '40%' }} placeholder='Enter Your Course Redemption Key Here'></input>
                                <Button style={{ width: '20%', marginLeft: '20px' }} variant="btn btn-outline-moses" onClick={() => {
                                    var inputed = document.getElementById("keyinput").value;
                                    if (inputed == '91751781')
                                        document.getElementById("response").innerHTML = "Call us to get discount.";
                                    else {
                                        var form_Data = new FormData();
                                        form_Data.append("redemption_key", inputed);
                                        axios.post(globalVar.serverlocation + '/api/student/redemptions/', form_Data, {
                                            headers: {
                                                'Authorization': Cookies.get('access_token')
                                            }
                                        })
                                            .then(res => {
                                                //console.log(res.request.status);
                                                //console.log(res.data);
                                                // setShowButton(false);
                                                document.getElementById("response").innerHTML = (globalVar.language === "eng") ? ('✅Redemption successful! You can now view course: ' + splitCourseName(res.data.course) + '.') : '✅兌換成功！你現在可以瀏覽課程：' + splitCourseName(res.data.course) + '。';
                                                getRedeemedCourse({ self: props.appRoot });
                                            })
                                            .catch(err => {
                                                //console.log(err)
                                                document.getElementById("response").innerHTML = (globalVar.language === "eng") ? '❌Redemption failed. Please check and enter the key again.' : '❌兌換失敗！請檢查並重新輸入代碼。';
                                            })
                                    }
                                }}>
                                    {showTxt[i++]}
                                </Button>
                            </div>
                        </div>
                        <h5 id="response" style={{ display: 'flex', alignContent: 'center', justifyContent: 'center', marginTop: '30px' }}></h5>
                    </div>
                </div>
            </div>
        </div>
    );
}